//
// Created by zeen on 10/13/25.
//

#ifndef RAKNET_TYPES_H
#define RAKNET_TYPES_H

#include <stdint.h>
#include "binarystream.h"

typedef enum {
    CONNECTION_STATE_UNCONNECTED,
    CONNECTION_STATE_CONNECTING,
    CONNECTION_STATE_CONNECTED,
    CONNECTION_STATE_DISCONNECTED
} connection_state_t;

typedef enum {
    FAILED_COOKIE_DUPLICATE,
    PASSED_COOKIE_DUPLICATE,
    FAILED_ORDERED_CONNECTION_REQUEST,
    FAILED_NEED_B_AND_AS_REQUEST,
    FAILED_DATAGRAM_ALL_4,
    FAILED_DATAGRAM_ALL_C,
    FAILED_NEW_INCOMING_ADDRESS,
    FAILED_PACKET_ERROR,
} packet_violation_t;

typedef struct {
    binary_stream_t        raw_packet;
    int8_t                 reliability;
} queue_packet_t;

typedef struct {
    queue_packet_t         packet;
} queue_encoded_packet_t;

#endif //RAKNET_TYPES_H
