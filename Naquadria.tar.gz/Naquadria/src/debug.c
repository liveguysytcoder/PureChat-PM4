//
// Created by zeen on 1/20/26.
//

#include "debug.h"

void debug_byte_buffer(const uint8_t *data, const size_t size) {
    if (!size) return;
    printf("           +-------------------------------------------------+\n");
    printf("  Hex View |  0  1  2  3  4  5  6  7  8  9  A  B  C  D  E  F |   ASCII View\n");
    printf("+----------+-------------------------------------------------+----------------+\n");
    for (size_t i = 0; i < size; i += 16) {
        printf("| %08zX | ", i);
        for (int j = 0; j < 16; j++) {
            if (i + j < size) {
                if (isprint(data[i + j])) printf("\033[32m");
                else printf("\033[31m");
                printf("%02X\033[0m ", data[i + j]);
            } else printf("\033[33m--\033[0m ");
        }
        printf("|");
        for (int j = 0; j < 16; j++) {
            if ( i + j < size) {
                const char c = (int8_t) data[i + j];
                if (isprint(c)) {
                    printf("\033[34m%c\033[0m", c);
                    continue;
                }
                printf(".");
            } else printf(" ");
        }
        printf("|\n");
    }
    printf("+----------+-------------------------------------------------+----------------+\n");
}