//
// Created by kani on 6/29/25.
//

#ifndef DEBUG_H
#define DEBUG_H

#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <ctype.h>

void debug_byte_buffer(const uint8_t *data, const size_t size);

static void print_uint8_base2_debug(const uint8_t in, const bool print){
    if(print){
        printf("0b");
    }
    printf("%d%d%d%d%d%d%d%d",
    (in & 0b10000000) > 0,
    (in & 0b01000000) > 0,
    (in & 0b00100000) > 0,
    (in & 0b00010000) > 0,
    (in & 0b00001000) > 0,
    (in & 0b00000100) > 0,
    (in & 0b00000010) > 0,
    (in & 0b00000001) > 0);
}

static void print_uint16_base2_debug(const uint16_t in, bool print){
    print_uint8_base2_debug((uint8_t)(in >> 8) & 0xFF, print);
    print = false;
    print_uint8_base2_debug((uint8_t)in & 0xFF, print);
}

static void print_uint32_base2_debug(const uint32_t in, bool print){
    print_uint16_base2_debug((uint16_t)(in >> 16) & 0xFFFF, print);
    print = false;
    print_uint16_base2_debug((uint16_t)in & 0xFFFF, print);
}

static void print_uint64_base2_debug(const uint64_t in, bool print){
    print_uint32_base2_debug((uint32_t)(in >> 32) & 0xFFFFFFFF, print);
    print = false;
    print_uint32_base2_debug((uint32_t)in & 0xFFFFFFFF, print);
}

#endif //DEBUG_H
