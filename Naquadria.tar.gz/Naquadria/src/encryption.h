//
// Created by kani on 6/12/25.
//

#ifndef ENCRYPTION_H
#define ENCRYPTION_H

// #define WOLFSSL


#ifdef WOLFSSL
#include <wolfssl/options.h>
#include <wolfssl/wolfcrypt/settings.h>
#include <wolfssl/wolfcrypt/ecc.h>
#include <wolfssl/wolfcrypt/aes.h>
#include <wolfssl/wolfcrypt/sha256.h>
#include <wolfssl/wolfcrypt/sha512.h>
#include <wolfssl/wolfcrypt/random.h>
#include <wolfssl/wolfcrypt/error-crypt.h>
#include <wolfssl/wolfcrypt/rsa.h>
#include <wolfssl/wolfcrypt/asn_public.h>
#include <wolfssl/wolfcrypt/coding.h>
#else
#include <openssl/pem.h>
#include <openssl/err.h>
#endif
#include <cjson/cJSON.h>

#include "binarystream.h"
#include "base64.h"
#include "str_util.h"
#include <assert.h>

#define MOJANG_PUBLIC_KEY "MHYwEAYHKoZIzj0CAQYFK4EEACIDYgAECRXueJeTDqNRRgJi/vlRufByu/2G0i2Ebt6YMar5QX/R0DIIyrJMcUpruK4QveTfJSTp3Shlq4Gk34cD/4GUWwkv0DVuzeuB+tXija7HBxii03NHDbPAD0AKnLr2wdAp"

#define BEDROCK_SIGNING_KEY_CURVE_NAME "secp384r1"
typedef struct {
    string_t        raw_jwt;
    size_t          part1_end;
    size_t          part2_end;
} jwt_data_t;

typedef struct {
    int64_t         encrypt_block_counter;
    int64_t         decrypt_block_counter;
#ifdef WOLFSSL
    ecc_key         *server_key;
    Aes             *encrypt_block;
    Aes             *decrypt_block;
#else
    EVP_PKEY        *server_key;
    EVP_CIPHER_CTX  *encrypt_block;
    EVP_CIPHER_CTX  *decrypt_block;
#endif
    size_t          shared_secret_size;
    uint8_t         *shared_secret;
    uint8_t         *key;
    uint8_t         *salt;
    bool            enabled;
} player_cipher_block_t;

typedef enum {
    CLIENT_IDENTITY,
    CLIENT_DATA
} jwt_chain_type_t;

void generate_server_keypair(
#ifdef WOLFSSL
    ecc_key **server_key
#else
    EVP_PKEY **server_key
#endif
    );

void cleanup_aes_256_ctr(player_cipher_block_t *cipher);

bool init_aes_256_ctr(uint8_t *key, uint8_t *iv, player_cipher_block_t *cipher);

bool setup_encryption(uint8_t **player_key, int64_t key_size, player_cipher_block_t *cipher);

int64_t calculate_checksum(int64_t block_counter, uint8_t **key, const uint8_t *input_buffer, size_t input_size);

bool encrypt_packet_buffer(const uint8_t *input_buffer, size_t input_size, uint8_t **output_buffer, size_t *output_size, player_cipher_block_t *cipher);

bool decrypt_packet_buffer(const uint8_t *input_buffer, size_t input_size, uint8_t **output_buffer, size_t *output_size, player_cipher_block_t *cipher);

jwt_data_t jwt_decode_segments(char *jwt_buffer, size_t jwt_size);

bool phd_send_encryption_request(player_cipher_block_t *cipher_block);

bool phd_check_jwt_data(const jwt_data_t *jwt_data, uint8_t **current_public_key, int8_t chain_id);
#endif //ENCRYPTION_H
