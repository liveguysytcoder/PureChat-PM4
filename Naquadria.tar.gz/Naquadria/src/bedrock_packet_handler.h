//
// Created by zeen on 10/8/25.
//

#ifndef BEDROCK_PACKET_HANDLER_H
#define BEDROCK_PACKET_HANDLER_H

#include "bedrock_net_serializer.h"
#include "bedrock_packet_ids.h"
#include "bedrock_player_data.h"

typedef struct bedrock_player_data bedrock_player_data_t;

void push_packet_to_queue(const pck_packet_t* packet, bedrock_player_data_t* player_data);

bool is_valid_c2p_packet(uint16_t packet_id, bedrock_player_play_state_t state);

void handle_c2p_no_functionality_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_not_implemented_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_forward_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_login_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_client_to_server_handshake_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_resource_pack_client_response_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_text_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_move_player_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_actor_event_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_inventory_transaction_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_mob_equipment_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_mob_armor_equipment_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_interact_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_block_pick_request_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_actor_pick_request_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_player_action_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_set_actor_data_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_set_actor_motion_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_set_actor_link_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_animate_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_respawn_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_container_close_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_player_hotbar_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_gui_data_pick_item_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_block_actor_data_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_set_difficulty_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_set_player_game_type_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_simple_event_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_map_info_request_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_request_chunk_radius_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_show_credits_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_command_request_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_command_block_update_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_resource_pack_chunk_request_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_structure_block_update_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_purchase_receipt_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_player_skin_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_sub_client_login_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_book_edit_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_npc_request_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_modal_form_response_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_server_settings_response_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_set_default_game_type_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_network_stack_latency_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_level_sound_event_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_lectern_update_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_client_cache_status_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_map_create_locked_copy_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_structure_template_data_request_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_client_cache_blob_status_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_emote_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_multiplayer_settings_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_settings_command_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_player_auth_input_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_item_stack_request_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_emote_list_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_position_tracking_d_b_client_request_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_debug_info_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_packet_violation_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_create_photo_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_sub_chunk_request_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_script_message_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_change_mob_property_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_request_ability_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_request_permissions_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_editor_network_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_request_network_settings_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_game_test_request_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_open_sign_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_player_toggle_crafter_slot_request_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_set_player_inventory_options_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_serverbound_loading_screen_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_serverbound_diagnostics_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_client_camera_aim_assist_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_client_movement_prediction_sync_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_update_client_options_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
void handle_c2p_serverbound_pack_setting_change_packet(pck_packet_t *packet, bedrock_player_data_t* player_data);
// void handle_c2p__packet(pck_packet_t *packet, bedrock_player_data_t* player_data);

typedef void (*packet_handler_func)(pck_packet_t *packet, bedrock_player_data_t *player_data);

void decode_games_packets(pck_packet_t* packet, bedrock_player_data_t* player_data);

void decode_batches_packet(binary_stream_t batch, bedrock_player_data_t* player_data);

void encode_batches_packets(bedrock_player_data_t* player_data);

void* player_packet_precessing_thread(void* arg);

#endif //BEDROCK_PACKET_HANDLER_H
