//
// Created by zeen on 9/20/25.
//
#include "bedrock_nbt.h"
#include "binarystream.h"
#include <string.h>

int8_t nbt_read_byte_tag(pck_packet_t* packet){
	return pck_read_int8(packet);
}

int16_t nbt_read_short_tag(pck_packet_t* packet, const uint8_t endianness) {
	int16_t value = 0;
	switch (endianness) {
		case E_BIG_ENDIAN:
			value = io_read_int16(packet->stream.buffer + packet->cursor, io_big_endian);
			packet->cursor += 2;
			break;
		case E_LITTLE_ENDIAN:
		case E_NETWORK_ENDIAN:
			value = pck_read_int16(packet);
		default:
			break;
	}
	return value;
}

int32_t nbt_read_int_tag(pck_packet_t* packet, const uint8_t endianness) {
	int32_t value = 0;
	switch (endianness) {
		case E_BIG_ENDIAN:
			value = io_read_int32(packet->stream.buffer + packet->cursor, io_big_endian);
			packet->cursor += 4;
			break;
		case E_LITTLE_ENDIAN:
			value = pck_read_int32(packet);
			break;
		case E_NETWORK_ENDIAN:
			value = pck_read_var_int(packet);
		default:
			break;
	}
	return value;
}

int64_t nbt_read_long_tag(pck_packet_t* packet, const uint8_t endianness) {
	int64_t value = 0;
	switch (endianness) {
		case E_BIG_ENDIAN:
			value = io_read_int64(packet->stream.buffer + packet->cursor, io_big_endian);
			packet->cursor += 8;
			break;
		case E_LITTLE_ENDIAN:
			value = pck_read_int64(packet);
			break;
		case E_NETWORK_ENDIAN:
			value = pck_read_var_long(packet);
			break;
		default:
			break;
	}
	return value;
}

float nbt_read_float_tag(pck_packet_t* packet, const uint8_t endianness) {
	float value = 0;
	switch (endianness) {
		case E_BIG_ENDIAN:
			value = io_read_float32(packet->stream.buffer + packet->cursor, io_big_endian);
			packet->cursor += 4;
			break;
		case E_LITTLE_ENDIAN:
		case E_NETWORK_ENDIAN:
			value = pck_read_float32(packet);
		default:
			break;
	}
	return value;
}

double nbt_read_double_tag(pck_packet_t* packet, const uint8_t endianness) {
	double value = 0;
	switch (endianness) {
		case E_BIG_ENDIAN:
			value = io_read_double64(packet->stream.buffer + packet->cursor, io_big_endian);
			packet->cursor += 4;
			break;
		case E_LITTLE_ENDIAN:
		case E_NETWORK_ENDIAN:
			value =  pck_read_float64(packet);
		default:
			break;
	}
	return value;
}

nbt_byte_array_t nbt_read_byte_array_tag(pck_packet_t* packet, const uint8_t endianness) {
	nbt_byte_array_t byte_array;
	byte_array.size = nbt_read_int_tag(packet, endianness);
	byte_array.data = (int8_t *) malloc(byte_array.size);
	for (int32_t i = 0; i < byte_array.size; ++i) {
		byte_array.data[i] = nbt_read_byte_tag(packet);
	}
	return byte_array;
}

char *nbt_read_string_tag(pck_packet_t* packet, const uint8_t endianness){
	uint32_t length = 0;
	switch (endianness) {
		case E_BIG_ENDIAN:
			length = io_read_int16(packet->stream.buffer + packet->cursor, io_big_endian);
			packet->cursor += 2;
		break;
        case E_LITTLE_ENDIAN:
			length = pck_read_int16(packet);
		break;
        case E_NETWORK_ENDIAN:
            length = pck_read_var_int(packet);
		break;
		default:
            break;
	}
	auto const result = (char *) malloc(length + 1);
	uint32_t i;
	for (i = 0; i < length; ++i) {
		result[i] = nbt_read_byte_tag(packet);
	}
	result[i] = 0;
	return result;
}

nbt_multi_t nbt_read_multi_tag(pck_packet_t* packet, const int8_t tag_id, const uint8_t endianness) {
	nbt_multi_t tag;
	switch (tag_id) {
		case BYTE_TAG:
			tag.byte_tag = nbt_read_byte_tag(packet);
			break;
		case SHORT_TAG:
			tag.short_tag = nbt_read_short_tag(packet, endianness);
			break;
		case INT_TAG:
			tag.int_tag = nbt_read_int_tag(packet, endianness);
			break;
		case LONG_TAG:
			tag.long_tag = nbt_read_long_tag(packet, endianness);
			break;
		case FLOAT_TAG:
			tag.float_tag = nbt_read_float_tag(packet, endianness);
			break;
		case DOUBLE_TAG:
			tag.double_tag = nbt_read_double_tag(packet, endianness);
			break;
		case BYTE_ARRAY_TAG:
			tag.byte_array_tag = nbt_read_byte_array_tag(packet, endianness);
			break;
		case STRING_TAG:
			tag.string_tag = nbt_read_string_tag(packet, endianness);
			break;
		case LIST_TAG:
			tag.list_tag = nbt_read_list_tag(packet, endianness);
			break;
		case COMPOUND_TAG:
			tag.compound_tag = nbt_read_compound_tag(packet, endianness);
			break;
		case INT_ARRAY_TAG:
			tag.int_array_tag = nbt_read_int_array_tag(packet, endianness);
			break;
		case LONG_ARRAY_TAG:
			tag.long_array_tag = nbt_read_long_array_tag(packet, endianness);
			break;
		default:
			break;
	}
	return tag;
}

nbt_list_t nbt_read_list_tag(pck_packet_t* packet, const uint8_t endianness) {
	nbt_list_t list;
	list.tag_id = nbt_read_byte_tag(packet);
	list.size = nbt_read_int_tag(packet, endianness);
	list.data = (nbt_multi_t *) malloc(list.size * sizeof(nbt_multi_t));
	for (int32_t i = 0; i < list.size; ++i) {
		list.data[i] = nbt_read_multi_tag(packet, list.tag_id, endianness);
	}
	return list;
}

nbt_compound_t nbt_read_compound_tag(pck_packet_t* packet, const uint8_t endianness) {
	nbt_compound_t compound;
	compound.size = 0;
	compound.tag_ids = (int8_t *) malloc(0);
	compound.names = (char **) malloc(0);
	compound.data = (nbt_multi_t *) malloc(0);
	while (packet->cursor < packet->stream.size) {
		const int8_t tag_id = nbt_read_byte_tag(packet);
		if (tag_id == 0)
			break;
		++compound.size;
		compound.tag_ids = (int8_t *) reallocarray(compound.tag_ids, compound.size, sizeof(uint8_t));
		compound.names = (char **) reallocarray(compound.names, compound.size, sizeof(char *));
		compound.data = (nbt_multi_t *) reallocarray(compound.data, compound.size, sizeof(nbt_multi_t));
		compound.tag_ids[compound.size - 1] = tag_id;
		compound.names[compound.size - 1] = nbt_read_string_tag(packet, endianness);
		compound.data[compound.size - 1] = nbt_read_multi_tag(packet, tag_id, endianness);
	}
	return compound;
}

nbt_int_array_t nbt_read_int_array_tag(pck_packet_t* packet, const uint8_t endianness) {
	nbt_int_array_t int_array = {
		.size = nbt_read_int_tag(packet, endianness),
	};
	int_array.data = (int32_t *) malloc(int_array.size * sizeof(int32_t));
	for (int32_t i = 0; i < int_array.size; ++i)
		int_array.data[i] = nbt_read_int_tag(packet, endianness);
	return int_array;
}

nbt_long_array_t nbt_read_long_array_tag(pck_packet_t* packet, const uint8_t endianness) {
	nbt_long_array_t long_array = {
		.size = nbt_read_int_tag(packet, endianness)
	};
	long_array.data = (int64_t *) malloc(long_array.size * sizeof(int64_t));
	for (int32_t i = 0; i < long_array.size; ++i) {
		long_array.data[i] = nbt_read_long_tag(packet, endianness);
	}
	return long_array;
}

nbt_named_t nbt_read_named_tag(pck_packet_t* packet, const uint8_t endianness) {
	nbt_named_t tag = {
		.tag_id = nbt_read_byte_tag(packet)
	};
	if (tag.tag_id != END_TAG) {
		tag.name = nbt_read_string_tag(packet, endianness);
		tag.data = nbt_read_multi_tag(packet, tag.tag_id, endianness);
	}
	return tag;
}

void nbt_write_byte_tag(pck_packet_t* packet, const int8_t value) {
	pck_write_int8(packet, value);
}

void nbt_write_short_tag(pck_packet_t* packet, const int16_t value, const uint8_t endianness) {
	switch (endianness) {
		case E_BIG_ENDIAN:
			io_write_int16(packet->stream.buffer + packet->cursor, value, io_big_endian);
			packet->cursor += 2;
			break;
		case E_LITTLE_ENDIAN:
		case E_NETWORK_ENDIAN:
			pck_write_int16(packet, value);
			break;
		default:
			break;
	}
}

void nbt_write_int_tag(pck_packet_t* packet, const int32_t value, const uint8_t endianness){
	switch (endianness) {
		case E_BIG_ENDIAN:
			io_write_int32(packet->stream.buffer + packet->cursor, value, io_big_endian);
			packet->cursor += 4;
			break;
		case E_LITTLE_ENDIAN:
			pck_write_int32(packet, value);
			break;
		case E_NETWORK_ENDIAN:
			pck_write_var_int(packet, value);
			break;
		default:
			break;
	}
}

void nbt_write_long_tag(pck_packet_t* packet, const int64_t value, const uint8_t endianness){
	switch (endianness) {
		case E_BIG_ENDIAN:
			io_write_int64(packet->stream.buffer + packet->cursor, value, io_big_endian);
			packet->cursor += 8;
			break;
		case E_LITTLE_ENDIAN:
			pck_write_int64(packet, value);
			break;
		case E_NETWORK_ENDIAN:
			pck_write_var_long(packet, value);
			break;
		default:
			break;
	}
}

void nbt_write_float_tag(pck_packet_t* packet, const float value, const uint8_t endianness){
	switch (endianness) {
		case E_BIG_ENDIAN:
			io_write_float32(packet->stream.buffer + packet->cursor, value, io_big_endian);
			packet->cursor += 4;
			break;
		case E_LITTLE_ENDIAN:
		case E_NETWORK_ENDIAN:
			pck_write_float32(packet, value);
			break;
		default:
			break;
	}
}

void nbt_write_double_tag(pck_packet_t* packet, const double value, const uint8_t endianness){
	switch (endianness) {
		case E_BIG_ENDIAN:
			io_write_double64(packet->stream.buffer + packet->cursor, value, io_big_endian);
			packet->cursor += 8;
			break;
		case E_LITTLE_ENDIAN:
		case E_NETWORK_ENDIAN:
			pck_write_float64(packet, value);
			break;
		default:
			break;
	}
}

void nbt_write_byte_array_tag(pck_packet_t* packet, const nbt_byte_array_t value, const uint8_t endianness){
	nbt_write_int_tag(packet, value.size, endianness);
	for (int32_t i = 0; i < value.size; ++i) {
		nbt_write_byte_tag(packet, value.data[i]);
	}
}

void nbt_write_string_tag(pck_packet_t* packet, const char *value, const uint8_t endianness){
	switch (endianness) {
		case E_BIG_ENDIAN:
			io_write_int16(packet->stream.buffer + packet->cursor, strlen(value), io_big_endian);
			packet->cursor += 2;
			break;
		case E_LITTLE_ENDIAN:
			pck_write_int16(packet, strlen(value));
			break;
		case E_NETWORK_ENDIAN:
			pck_write_var_int(packet, strlen(value));
			break;
		default:
			break;
	}
	for (uint32_t i = 0; i < strlen(value); ++i) {
		nbt_write_byte_tag(packet, value[i]);
	}
}

void nbt_write_multi_tag(pck_packet_t* packet, const nbt_multi_t value, const int8_t tag_id, const uint8_t endianness){
	switch (tag_id) {
		case BYTE_TAG:
			nbt_write_byte_tag(packet, value.byte_tag);
			break;
		case SHORT_TAG:
			nbt_write_short_tag(packet, value.short_tag, endianness);
			break;
		case INT_TAG:
			nbt_write_int_tag(packet, value.int_tag, endianness);
			break;
		case LONG_TAG:
			nbt_write_long_tag(packet, value.long_tag, endianness);
			break;
		case FLOAT_TAG:
			nbt_write_float_tag(packet, value.float_tag, endianness);
			break;
		case DOUBLE_TAG:
			nbt_write_double_tag(packet, value.double_tag, endianness);
			break;
		case BYTE_ARRAY_TAG:
			nbt_write_byte_array_tag(packet, value.byte_array_tag, endianness);
			break;
		case STRING_TAG:
			nbt_write_string_tag(packet, value.string_tag, endianness);
			break;
		case LIST_TAG:
			nbt_write_list_tag(packet, value.list_tag, endianness);
			break;
		case COMPOUND_TAG:
			nbt_write_compound_tag(packet, value.compound_tag, endianness);
			break;
		case INT_ARRAY_TAG:
			nbt_write_int_array_tag(packet, value.int_array_tag, endianness);
			break;
		case LONG_ARRAY_TAG:
			nbt_write_long_array_tag(packet, value.long_array_tag, endianness);
			break;
		default:
			break;
	}
}

void nbt_write_list_tag(pck_packet_t* packet, const nbt_list_t value, const uint8_t endianness){
	nbt_write_byte_tag(packet, value.tag_id);
	nbt_write_int_tag(packet, value.size, endianness);
	int32_t i;
	for (i = 0; i < value.size; ++i) {
		nbt_write_multi_tag(packet, value.data[i], value.tag_id, endianness);
	}
}

void nbt_write_compound_tag(pck_packet_t* packet, const nbt_compound_t value, const uint8_t endianness){
	for (size_t i = 0; i < value.size; ++i) {
		if (value.tag_ids[i] == END_TAG) {
			break;
		}
		nbt_write_byte_tag(packet, value.tag_ids[i]);
		nbt_write_string_tag(packet, value.names[i], endianness);
		nbt_write_multi_tag(packet, value.data[i], value.tag_ids[i], endianness);
	}
	nbt_write_byte_tag(packet, END_TAG);
}

void nbt_write_int_array_tag(pck_packet_t* packet, const nbt_int_array_t value, const uint8_t endianness){
	nbt_write_int_tag(packet, value.size, endianness);
	int32_t i;
	for (i = 0; i < value.size; ++i) {
		nbt_write_int_tag(packet, value.data[i], endianness);
	}
}

void nbt_write_long_array_tag(pck_packet_t* packet, const nbt_long_array_t value, const uint8_t endianness){
	nbt_write_int_tag(packet, value.size, endianness);
	int32_t i;
	for (i = 0; i < value.size; ++i) {
		nbt_write_long_tag(packet, value.data[i], endianness);
	}
}

void nbt_write_named_tag(pck_packet_t* packet, const nbt_named_t value, const uint8_t endianness){
	nbt_write_byte_tag(packet, value.tag_id);
	if (value.tag_id != END_TAG) {
		nbt_write_string_tag(packet, value.name, endianness);
		nbt_write_multi_tag(packet, value.data, value.tag_id, endianness);
	}
}

void destroy_nbt_list(const nbt_list_t value){
	for (int32_t i = 0; i < value.size; ++i) {
		switch (value.tag_id) {
		case STRING_TAG:
			free(value.data[i].string_tag);
			break;
		case BYTE_ARRAY_TAG:
			free(value.data[i].byte_array_tag.data);
			break;
		case INT_ARRAY_TAG:
			free(value.data[i].int_array_tag.data);
			break;
		case LONG_ARRAY_TAG:
			free(value.data[i].long_array_tag.data);
			break;
		case LIST_TAG:
			destroy_nbt_list(value.data[i].list_tag);
			break;
		case COMPOUND_TAG:
			destroy_nbt_compound(value.data[i].compound_tag);
			break;
		default:
			break;
		}
	}
	free(value.data);
}

void destroy_nbt_compound(const nbt_compound_t value){
	for (size_t i = 0; i < value.size; ++i) {
		free(value.names[i]);
		switch (value.tag_ids[i]) {
			case STRING_TAG:
				free(value.data[i].string_tag);
				break;
			case BYTE_ARRAY_TAG:
				free(value.data[i].byte_array_tag.data);
				break;
			case INT_ARRAY_TAG:
				free(value.data[i].int_array_tag.data);
				break;
			case LONG_ARRAY_TAG:
				free(value.data[i].long_array_tag.data);
				break;
			case LIST_TAG:
				destroy_nbt_list(value.data[i].list_tag);
				break;
			case COMPOUND_TAG:
				destroy_nbt_compound(value.data[i].compound_tag);
				break;
			default:
				break;
		}
	}
	free(value.data);
	free(value.names);
	free(value.tag_ids);
}

void destroy_nbt_named(const nbt_named_t value){
	free(value.name);
	switch (value.tag_id) {
		case STRING_TAG:
			free(value.data.string_tag);
			break;
		case BYTE_ARRAY_TAG:
			free(value.data.byte_array_tag.data);
			break;
		case INT_ARRAY_TAG:
			free(value.data.int_array_tag.data);
			break;
		case LONG_ARRAY_TAG:
			free(value.data.long_array_tag.data);
			break;
		case LIST_TAG:
			destroy_nbt_list(value.data.list_tag);
			break;
		case COMPOUND_TAG:
			destroy_nbt_compound(value.data.compound_tag);
			break;
		default:
			break;
	}
}
