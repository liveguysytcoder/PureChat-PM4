//
// Created by zeen on 9/7/25.
//
#include "raknet_packet_handler.h"

#include "bedrock_player_data.h"
#include "raknet_types.h"
#include "debug.h"
#include "raknet_server.h"

bool has_raknet_context_connection(const non_connected_t* non_connected, const server_context_t *server) {
    for (size_t i = 0; i < server->clients_size; i++)
        if (non_connected->hash == server->clients[i].basic_info.hash)
            return true;
    return false;
}

void add_raknet_connection(const non_connected_t* non_connected, const int16_t mtu_size, server_context_t *server) {
    if (!has_raknet_context_connection(non_connected, server)) {
        const int64_t current_time_ms = get_current_time_ms();
        const non_connected_t basic = {
            .raw_packets_queues = (binary_stream_t *) malloc(0),
            .raw_packets_queues_size = 0,
            .hash = non_connected->hash,
            .address = non_connected->address
        };
        const client_context_t client_context = {
            .basic_info = basic,
            .mtu = mtu_size,
            .last_ping_time = current_time_ms,
            .last_receive_time = current_time_ms,
            .next_sequence_number = 0,
            .next_message_index = 0,
            .expected_sequence_number = 0,
            .packet_violation = 0,
            .ack_queue = (uint32_t *) malloc(0),
            .ack_queue_size = 0,
            .nack_queue = (uint32_t *) malloc(0),
            .nack_queue_size = 0,
            .segmented_id = 0,
            .segmented_datagram_packets_queue_size = 0,
            .segmented_datagram_packets_queue = (rak_message_t *) malloc(0),
            .encoded_datagram_send_packets_queue.datagram_packets_count = 0,
            .encoded_datagram_send_packets_queue.datagram_packets = (rak_message_t *) malloc(0),
            .next_order_index = 0,
            .retransmission = resend_map_create(),
        };
        server->clients_size++;
        server->clients = (client_context_t *) reallocarray(server->clients, server->clients_size, sizeof(client_context_t));
        server->clients[server->clients_size - 1] = client_context;
    }
}

client_context_t *get_raknet_connection(const non_connected_t* non_connected, const server_context_t *server) {
    for (size_t i = 0; i < server->clients_size; i++)
        if (non_connected->hash == server->clients[i].basic_info.hash)
			return (&(server->clients[i]));
	return nullptr;
}

void raknet_cleanup_client_resources(client_context_t *client) {
    if (client->ack_queue) {
        free(client->ack_queue);
        client->ack_queue = nullptr;
        client->ack_queue_size = 0;
    }
    if (client->nack_queue) {
        free(client->nack_queue);
        client->nack_queue = nullptr;
        client->nack_queue_size = 0;
    }
    for (uint32_t i = 0; i < client->segmented_datagram_packets_queue_size; i++)
        if (client->segmented_datagram_packets_queue[i].payload)
            free(client->segmented_datagram_packets_queue[i].payload);
    if (client->segmented_datagram_packets_queue) {
        free(client->segmented_datagram_packets_queue);
        client->segmented_datagram_packets_queue = nullptr;
    }
    client->segmented_datagram_packets_queue_size = 0;

    for (uint32_t i = 0; i < client->encoded_datagram_send_packets_queue.datagram_packets_count; i++)
        if (client->encoded_datagram_send_packets_queue.datagram_packets[i].payload)
            free(client->encoded_datagram_send_packets_queue.datagram_packets[i].payload);
    if (client->encoded_datagram_send_packets_queue.datagram_packets) {
        free(client->encoded_datagram_send_packets_queue.datagram_packets);
        client->encoded_datagram_send_packets_queue.datagram_packets = nullptr;
    }
    client->encoded_datagram_send_packets_queue.datagram_packets_count = 0;
    if (client->retransmission) {
        resend_map_free(client->retransmission);
        client->retransmission = nullptr;
    }
    for (size_t i = 0; i < client->basic_info.raw_packets_queues_size; i++)
        if (client->basic_info.raw_packets_queues[i].buffer) {
            free(client->basic_info.raw_packets_queues[i].buffer);
            client->basic_info.raw_packets_queues[i].buffer = nullptr;
        }
    if (client->basic_info.raw_packets_queues) {
        free(client->basic_info.raw_packets_queues);
        client->basic_info.raw_packets_queues = nullptr;
    }
    client->basic_info.raw_packets_queues_size = 0;
}

void remove_raknet_connection(const client_context_t* client_context, server_context_t *server) {
    if (server->clients_size <= 1) {
        free(server->clients);
        server->clients = malloc(0);
        server->clients_size = 0;
        return;
    }

    client_context_t *clients = malloc((server->clients_size - 1) * sizeof(client_context_t));
    size_t clients_count = 0;

    for (size_t i = 0; i < server->clients_size; i++) {
        if (client_context->basic_info.hash != server->clients[i].basic_info.hash) {
            clients[clients_count] = server->clients[i];
            clients_count++;
        }
    }

    free(server->clients);
    server->clients = clients;
    server->clients_size--;
}

bool is_in_ack_queue(const client_context_t *client_context, const uint32_t sequence_number) {
    for (uint16_t i = 0; i < client_context->ack_queue_size; i++)
        if (client_context->ack_queue[i] == sequence_number)
            return true;
    return false;
}

static void add_to_ack_queue(client_context_t *client_context, const uint32_t sequence_number) {
    if (is_in_ack_queue(client_context, sequence_number))
        return;
    client_context->ack_queue = (uint32_t *) reallocarray(client_context->ack_queue, (client_context->ack_queue_size + 1), sizeof(uint32_t));
    client_context->ack_queue[client_context->ack_queue_size++] = sequence_number;
}

bool is_in_nack_queue(const client_context_t *client_context, const uint32_t sequence_number) {
    for (uint16_t i = 0; i < client_context->nack_queue_size; i++)
        if (client_context->nack_queue[i] == sequence_number)
            return true;
    return false;
}

static void add_to_nack_queue(client_context_t *client_context, const uint32_t sequence_number) {
    if (is_in_nack_queue(client_context, sequence_number))
        return;
    client_context->nack_queue = (uint32_t *) reallocarray(client_context->nack_queue, (client_context->nack_queue_size + 1), sizeof(uint32_t));
    client_context->nack_queue[client_context->nack_queue_size++] = sequence_number;
}

void deduct_raknet_nack_queue(client_context_t *client_context, const uint32_t sequence_number) {
    if (is_in_nack_queue(client_context, sequence_number)) {
        auto const nack_queue = (uint32_t *) malloc((client_context->nack_queue_size - 1) * sizeof(uint32_t));
        uint16_t nack_queue_size = 0;
        for (uint16_t i = 0; i < client_context->nack_queue_size; i++)
            if (client_context->nack_queue[i] != sequence_number) {
                nack_queue[nack_queue_size] = client_context->nack_queue[i];
                nack_queue_size++;
            }
        free(client_context->nack_queue);
        client_context->nack_queue = nack_queue;
        client_context->nack_queue_size--;
    }
}

bool is_in_raknet_segmented_datagram_queue(const client_context_t *client_context, const uint16_t segmented_id, const uint32_t segmented_index) {
    for (uint32_t i = 0; i < client_context->segmented_datagram_packets_queue_size; i++)
        if (client_context->segmented_datagram_packets_queue[i].segmented_id == segmented_id && client_context->segmented_datagram_packets_queue[i].segmented_index == segmented_index)
            return true;
    return false;
}

void append_raknet_segmented_datagram_queue(client_context_t *client_context, const rak_message_t segmented_datagram){
    if (!is_in_raknet_segmented_datagram_queue(client_context, segmented_datagram.segmented_id, segmented_datagram.segmented_index)) {
        client_context->segmented_datagram_packets_queue_size++;
        client_context->segmented_datagram_packets_queue = (rak_message_t *) reallocarray(client_context->segmented_datagram_packets_queue, client_context->segmented_datagram_packets_queue_size, sizeof(rak_message_t));
        client_context->segmented_datagram_packets_queue[client_context->segmented_datagram_packets_queue_size - 1] = segmented_datagram;
    }
}

uint32_t get_raknet_segmented_size(const client_context_t *client_context, const uint16_t segmented_id) {
    uint32_t size = 0;
    for (uint32_t i = 0; i < client_context->segmented_datagram_packets_queue_size; i++)
        if (client_context->segmented_datagram_packets_queue[i].segmented_id == segmented_id)
            size++;
    return size;
}

rak_message_t pop_raknet_segmented_datagram_entry(client_context_t *client_context, const uint16_t segmented_id, const uint32_t segmented_index) {
    rak_message_t output_frame = {nullptr};
    if (is_in_raknet_segmented_datagram_queue(client_context, segmented_id, segmented_index)) {
        auto const frame_holder = (rak_message_t *) malloc((client_context->segmented_datagram_packets_queue_size - 1) * sizeof(rak_message_t));
        uint32_t frame_holder_size = 0;
        for (uint32_t i = 0; i < client_context->segmented_datagram_packets_queue_size; i++)
            if (client_context->segmented_datagram_packets_queue[i].segmented_id != segmented_id || client_context->segmented_datagram_packets_queue[i].segmented_index != segmented_index) {
                frame_holder[frame_holder_size] = client_context->segmented_datagram_packets_queue[i];
                ++frame_holder_size;
            } else {
                output_frame = client_context->segmented_datagram_packets_queue[i];
            }
        free(client_context->segmented_datagram_packets_queue);
        client_context->segmented_datagram_packets_queue = frame_holder;
        client_context->segmented_datagram_packets_queue_size--;
    }
    return output_frame;
}

void append_raknet_encoded_datagram_resend_packets_queue(const client_context_t *client_context, const packet_datagrams_t packet_datagrams) {
    resend_map_add(client_context->retransmission, packet_datagrams.sequence_number, packet_datagrams);
}

void deduct_raknet_encoded_datagram_resend_packets_queue(const client_context_t *client_context, const uint32_t sequence_number) {
    packet_datagrams_t datagram;
    if (resend_map_acknowledge(client_context->retransmission, sequence_number, &datagram)) {
        for (size_t i = 0; i < datagram.datagram_packets_count; i++)
            free(datagram.datagram_packets[i].payload);
        free(datagram.datagram_packets);
    }
}

void add_to_raw_packets_queues(non_connected_t *non_connected, const binary_stream_t packet) {
    non_connected->raw_packets_queues_size++;
    non_connected->raw_packets_queues = (binary_stream_t *) reallocarray(non_connected->raw_packets_queues, non_connected->raw_packets_queues_size, sizeof(binary_stream_t));
    non_connected->raw_packets_queues[non_connected->raw_packets_queues_size - 1] = packet;
}

void send_raw_packets_queues(non_connected_t *non_connected, server_context_t *server_context) {
    if (non_connected->raw_packets_queues_size < 1)
        return;
    for (size_t i = 0; i < non_connected->raw_packets_queues_size; i++) {
        const binary_stream_t packet = non_connected->raw_packets_queues[i];
        struct iovec *iov = malloc(sizeof(struct iovec));
        iov->iov_base = packet.buffer;
        iov->iov_len = packet.size;
        struct sockaddr_in *addr = malloc(sizeof(struct sockaddr_in));
        *addr = non_connected->address;
        server_context->messages_size++;
        server_context->messages = reallocarray(
            server_context->messages,
            server_context->messages_size,
            sizeof(struct mmsghdr)
        );
        struct mmsghdr *msg = &server_context->messages[server_context->messages_size - 1];
        memset(msg, 0, sizeof(struct mmsghdr));
        msg->msg_hdr.msg_iov = iov;
        msg->msg_hdr.msg_iovlen = 1;
        msg->msg_hdr.msg_name = addr;
        msg->msg_hdr.msg_namelen = sizeof(struct sockaddr_in);
    }
    non_connected->raw_packets_queues = (binary_stream_t *) malloc(0);
    non_connected->raw_packets_queues_size = 0;
}

void send_encoded_datagram_queue(client_context_t *context) {
    if (context->encoded_datagram_send_packets_queue.datagram_packets_count > 0) {
        context->encoded_datagram_send_packets_queue.sequence_number = context->next_sequence_number;
        append_raknet_encoded_datagram_resend_packets_queue(context, context->encoded_datagram_send_packets_queue);
        context->next_sequence_number++;
        size_t frames_packets_size = 4;
        for (size_t ii = 0; ii < context->encoded_datagram_send_packets_queue.datagram_packets_count; ii++) {
            frames_packets_size += raknet_write_online_data_gram_capsule_size(context->encoded_datagram_send_packets_queue.datagram_packets[ii]);
        }
        // uint8_t *output_buffer = calloc(frames_packets_size, 1);
        uint8_t *output_buffer = malloc(frames_packets_size);
        size_t output_offset = 0;
        raknet_write_online_frames_header(output_buffer, &output_offset, (int8_t) (FLAG_VALID | FLAG_PACKET_PAIR), (int32_t) context->encoded_datagram_send_packets_queue.sequence_number);
        for (size_t ii = 0; ii < context->encoded_datagram_send_packets_queue.datagram_packets_count; ii++) {
            raknet_write_online_data_gram_capsule(output_buffer, &output_offset, context->encoded_datagram_send_packets_queue.datagram_packets[ii]);
        }
        add_to_raw_packets_queues(&context->basic_info, BUFFER_TO_BINARY_STREAM(output_buffer, frames_packets_size));
        context->encoded_datagram_send_packets_queue.datagram_packets = (rak_message_t *) malloc(0);
        context->encoded_datagram_send_packets_queue.datagram_packets_count = 0;
    }
}

void check_client_retransmission_timeouts(client_context_t *context) {
    if (!context->retransmission)
        return;
    uint32_t *timeout_sequences = nullptr;
    size_t timeout_count = 0;
    resend_map_check_timeouts(context->retransmission, &timeout_sequences, &timeout_count);
    for (size_t i = 0; i < timeout_count; i++) {
        packet_datagrams_t packet_datagrams;
        if (resend_map_retransmit(context->retransmission, timeout_sequences[i], &packet_datagrams)) {
            packet_datagrams.sequence_number = context->next_sequence_number;
            resend_map_add(context->retransmission, packet_datagrams.sequence_number, packet_datagrams);
            context->next_sequence_number++;
            size_t frames_packets_size = 4;
            for (size_t ii = 0; ii < packet_datagrams.datagram_packets_count; ii++) {
                frames_packets_size += raknet_write_online_data_gram_capsule_size(packet_datagrams.datagram_packets[ii]);
            }
            // uint8_t *output_buffer = calloc(frames_packets_size, 1);
            uint8_t *output_buffer = malloc(frames_packets_size);
            size_t output_offset = 0;
            raknet_write_online_frames_header(output_buffer, &output_offset, (int8_t) (FLAG_VALID | FLAG_PACKET_PAIR), (int32_t) packet_datagrams.sequence_number);
            for (size_t ii = 0; ii < packet_datagrams.datagram_packets_count; ii++) {
                raknet_write_online_data_gram_capsule(output_buffer, &output_offset, packet_datagrams.datagram_packets[ii]);
            }
            add_to_raw_packets_queues(&context->basic_info, BUFFER_TO_BINARY_STREAM(output_buffer, frames_packets_size));
        }
    }
    free(timeout_sequences);
}

void append_encoded_datagram_queue(client_context_t *context, const rak_message_t message, const bool is_split) {
    size_t size = 4 + raknet_write_online_data_gram_capsule_size(message);
    for (size_t i = 0; i < context->encoded_datagram_send_packets_queue.datagram_packets_count; i++) {
        size += raknet_write_online_data_gram_capsule_size(context->encoded_datagram_send_packets_queue.datagram_packets[i]);
    }
    if (size > ((size_t) context->mtu - 36))
        send_encoded_datagram_queue(context);
    context->encoded_datagram_send_packets_queue.datagram_packets_count++;
    context->encoded_datagram_send_packets_queue.datagram_packets = (rak_message_t *) reallocarray(context->encoded_datagram_send_packets_queue.datagram_packets, context->encoded_datagram_send_packets_queue.datagram_packets_count, sizeof(rak_message_t));
    context->encoded_datagram_send_packets_queue.datagram_packets[context->encoded_datagram_send_packets_queue.datagram_packets_count - 1] = message;
    if (is_split)
        send_encoded_datagram_queue(context);
}

void add_to_sent_queue(client_context_t *context, const queue_packet_t packet) {
    int32_t order_index = 0;
    if (is_ordered(packet.reliability)) {
		order_index = context->next_order_index;
        context->next_order_index++;
	}
	const int16_t max_size = (int16_t) (context->mtu - 60);
	if (packet.raw_packet.size > (size_t) max_size) {
	    const int32_t frame_count = (int32_t)(packet.raw_packet.size / max_size) + 1;
	    size_t offset = 0;
        for (int32_t i = 0; i < frame_count; i++) {
			rak_message_t message = {
			    .segmented = true,
			    .reliability = packet.reliability,
			    .segmented_id = (int16_t) context->segmented_id,
			    .segmented_count = frame_count,
			    .segmented_index = i,
			    .payload_size = max_size
			};
            const size_t diff = packet.raw_packet.size - offset;
            if (diff <= (size_t) max_size)
                message.payload_size = diff;
            message.payload = malloc(message.payload_size);
            memcpy(message.payload, packet.raw_packet.buffer + offset, message.payload_size);
            offset += message.payload_size;
			if (is_reliable(packet.reliability)) {
				message.message_index = context->next_message_index;
			    context->next_message_index++;
			}
			if (is_ordered(packet.reliability))
				message.order_index = order_index & 0xFFFFFF;
			append_encoded_datagram_queue(context, message, true);
		}
	    free(packet.raw_packet.buffer);
		context->segmented_id++;
	} else {
	    rak_message_t message = {
	        .segmented = false,
	        .reliability = packet.reliability,
	        .payload_size = packet.raw_packet.size,
	        .order_index = order_index & 0xFFFFFF,
	        .payload = packet.raw_packet.buffer,
	    };
	    if (is_reliable(packet.reliability)) {
	        message.message_index = context->next_message_index;
	        context->next_message_index++;
	    }
		append_encoded_datagram_queue(context, message, false);
	}
}

bool raknet_flush_acks_nacks(client_context_t *client_context) {
    uint16_t record_count;
    if (client_context->ack_queue_size > 0) {
        size_t ack_size = raknet_write_online_ack_nack_size(client_context->ack_queue_size, &client_context->ack_queue, &record_count);
        auto const response = (uint8_t *) calloc(ack_size, 1);
        raknet_write_online_ack_nack(response, &ack_size, true, client_context->ack_queue_size, client_context->ack_queue, record_count);
        add_to_raw_packets_queues(&client_context->basic_info, BUFFER_TO_BINARY_STREAM(response, ack_size));
        free(client_context->ack_queue);
        client_context->ack_queue = (uint32_t *) malloc(0);
        client_context->ack_queue_size = 0;
    }
    if (client_context->nack_queue_size > 0) {
        size_t nack_size = raknet_write_online_ack_nack_size(client_context->nack_queue_size, &client_context->nack_queue, &record_count);
        auto const response = (uint8_t *) calloc(nack_size, 1);
        raknet_write_online_ack_nack(response, &nack_size, false, client_context->nack_queue_size, client_context->nack_queue, record_count);
        add_to_raw_packets_queues(&client_context->basic_info, BUFFER_TO_BINARY_STREAM(response, nack_size));
        free(client_context->nack_queue);
        client_context->nack_queue = (uint32_t *) malloc(0);
        client_context->nack_queue_size = 0;
    }
    return true;
}

bool raknet_process_packet(const uint8_t *buffer, const size_t length, non_connected_t *non_connected, server_context_t *server_context) {
    if (!buffer || length == 0)
        return false;
    const uint8_t packet_id = buffer[0];
    bool is_has_raknet_context = false;
    is_has_raknet_context = has_raknet_context_connection(non_connected, server_context);
    if (!is_has_raknet_context && non_connected->state != CONNECTION_STATE_UNCONNECTED)
        return non_connected->state == CONNECTION_STATE_DISCONNECTED;
    if (!is_has_raknet_context) {
        switch (packet_id) {
            case ID_UN_PING:
            case ID_UN_PING_OPEN_CONNECTIONS:
                return handle_unconnected_ping(buffer + 1, length, non_connected, server_context);
            case ID_OPEN_REQUEST_1:
                return handle_open_connection_request_1(buffer + 1, length, non_connected, server_context);
            case ID_OPEN_REQUEST_2:
                return handle_open_connection_request_2(buffer + 1, length, non_connected, server_context);
            default:
                return true;
        }
    }
    client_context_t *client_context = get_raknet_connection(non_connected, server_context);
    if (!client_context)
        return false;
    client_context->last_receive_time = get_current_time_ms();
    switch(client_context->basic_info.state) {
        case CONNECTION_STATE_CONNECTING:
        case CONNECTION_STATE_CONNECTED: {
            switch (packet_id) {
                case ID_UN_PING:
                case ID_UN_PING_OPEN_CONNECTIONS:
                    return true;
                case ID_OPEN_REQUEST_2:
                    if (!server_context->enable_cookie)
                        return true;
                    return handle_open_connection_request_2(buffer + 1, length, non_connected, server_context);
                // case ID_ACK:
                //     return handle_ack_packet(buffer + 1, length - 1, client_context);
                // case ID_NACK:
                //     return handle_nack_packet(buffer + 1, length - 1, client_context);
                // case ID_SET_0 ... ID_SET_C:
                //     return handle_datagram_packet(buffer, length, client_context, server_context);
                // default:
                //     break;
            }
            if ((packet_id & FLAG_VALID) > 0) {
                if ((packet_id & FLAG_ACK) > 0) {
                    if ((packet_id & FLAG_HAS_B_AND_AS) > 0) {
                        //skip 4 bytes btw this should not be possible with vanilla raknet
                        return handle_ack_packet(buffer + 5, length - 5, client_context);
                    }
                    return handle_ack_packet(buffer + 1, length - 1, client_context);
                }
                if ((packet_id & FLAG_NACK) > 0) {
                    return handle_nack_packet(buffer + 1, length - 1, client_context);
                }
                return handle_datagram_packet(buffer, length, client_context, server_context);
            }
            break;
        }
        default: return true;
    }
    return false;
}

bool handle_unconnected_ping(const uint8_t *buffer, const size_t length, non_connected_t *non_connected, const server_context_t *server_context) {
    size_t offset = 0;
    int64_t ping_id, player_guid;
    if (!raknet_read_unconnected_ping(buffer, &offset, length, &ping_id, &player_guid))
        return false;
    size_t response_length = PACKET_SIZE_UNCONNECTED_PONG + server_context->motd_size;
    auto const response = (uint8_t *) calloc(response_length, 1);
    raknet_create_unconnected_pong(response, &response_length, MAGIC_PART_1, MAGIC_PART_2, server_context->server_guid, server_context->motd_size, server_context->motd);
    raknet_write_unconnected_pong(response, &response_length, ping_id, server_context->motd_size);
    add_to_raw_packets_queues(non_connected, BUFFER_TO_BINARY_STREAM(response, response_length));
    return true;
}

bool handle_open_connection_request_1(const uint8_t *buffer, const size_t length, non_connected_t *non_connected, server_context_t *server_context) {
    size_t offset = 0;
    int8_t protocol_version;
    size_t mtu;
    if (!raknet_read_open_connection_request_1(buffer, &offset, length, &protocol_version, &mtu))
        return false;
    if (protocol_version != 11 && protocol_version != 8) {
        size_t response_length = PACKET_SIZE_INCOMPATIBLE_PROTOCOL_VERSION;
        auto const response = (uint8_t *) calloc(response_length, 1);
        raknet_write_incompatible_protocol_version(response, &response_length, 11, MAGIC_PART_1, MAGIC_PART_2, server_context->server_guid);
        add_to_raw_packets_queues(non_connected, BUFFER_TO_BINARY_STREAM(response, response_length));
        return true;
    }
    const int32_t fake_cookie = (int32_t) (server_context->enable_cookie ? (non_connected->hash >> 32) : 0);
    int32_t real_cookie = (int32_t) (server_context->enable_cookie ? (non_connected->hash & 0xFFFFFFFF) : 0);
    size_t response_length = 32;
    const uint16_t new_mtu = MIN(mtu, MAX_MTU_SIZE);
#ifndef BYPASS_ALL_TEST
    if (server_context->enable_cookie) {
        auto const fake_response = (uint8_t *) calloc(response_length, 1);
        raknet_write_open_connection_reply_1(fake_response, &response_length, MAGIC_PART_1, MAGIC_PART_2, server_context->server_guid, fake_cookie, (int16_t) new_mtu);
        add_to_raw_packets_queues(non_connected, BUFFER_TO_BINARY_STREAM(fake_response, response_length));
    }
#endif
    auto const real_response = (uint8_t *) calloc(response_length, 1);
    raknet_write_open_connection_reply_1(real_response, &response_length, MAGIC_PART_1, MAGIC_PART_2, server_context->server_guid, real_cookie, (int16_t) new_mtu);
    add_to_raw_packets_queues(non_connected, BUFFER_TO_BINARY_STREAM(real_response, response_length));
    return true;
}

bool handle_open_connection_request_2(const uint8_t *buffer, const size_t length, non_connected_t *non_connected, server_context_t *server_context) {
    size_t offset = 1;
    rak_address_t server_address;
    int16_t mtu;
    int64_t player_guid;
    int32_t cookie = server_context->enable_cookie;
    if (!raknet_read_open_connection_request_2(buffer, &offset, length, &cookie, &server_address, &mtu, &player_guid)) {
        return false;
    }
    if (mtu < MIN_MTU_SIZE) {
        return false;
    }
#ifndef BYPASS_ALL_TEST
    const int32_t fake_cookie = (int32_t) (non_connected->hash >> 32);
    const int32_t real_cookie = (int32_t) (non_connected->hash & 0xFFFFFFFF);
    if (server_context->enable_cookie && cookie != real_cookie && cookie != fake_cookie) {
        return false;
    }
#endif
    mtu = MIN(mtu, MAX_MTU_SIZE);
    add_raknet_connection(non_connected, mtu, server_context);
    if (!has_raknet_context_connection(non_connected, server_context))
        return false;
    client_context_t *client_context = get_raknet_connection(non_connected, server_context);
#ifndef BYPASS_ALL_TEST
    if (server_context->enable_cookie) {
        client_context->packet_violation |= (cookie == fake_cookie) << FAILED_COOKIE_DUPLICATE;
        client_context->packet_violation |= (cookie == real_cookie) << PASSED_COOKIE_DUPLICATE;
    }else {
        client_context->packet_violation |= 0b11;
    }
#else
    const int32_t fake_cookie = cookie;
#endif
    if (cookie == fake_cookie || !server_context->enable_cookie) {
        size_t response_length = 35;
        auto const response = (uint8_t *) calloc(response_length, 1);
        raknet_write_open_connection_reply_2(response, &response_length, MAGIC_PART_1, MAGIC_PART_2, SERVER_GUID, server_address, mtu, server_context->enable_cookie);
        add_to_raw_packets_queues(non_connected, BUFFER_TO_BINARY_STREAM(response, response_length));
        size_t ping_response_length = 9;
        auto const ping_response = (uint8_t *) calloc(response_length, 1);
        raknet_write_online_ping(ping_response, &ping_response_length, get_current_time_ms());
        const queue_packet_t packet = {
            .raw_packet = BUFFER_TO_BINARY_STREAM(ping_response, ping_response_length),
            .reliability = RELIABILITY_UNRELIABLE
        };
        add_to_sent_queue(client_context, packet);
    }
    client_context->basic_info.state = CONNECTION_STATE_CONNECTING;
    return true;
}

bool handle_connection_request(const uint8_t *buffer, const size_t length, client_context_t *context) {
    size_t offset = 0;
    int64_t client_guid, client_timestamp;
    if (!raknet_read_online_connection_request(buffer, &offset, length, &client_guid, &client_timestamp))
        return false;
    const rak_address_t system_addresses[20] = {};
    size_t response_length = raknet_online_connection_request_accepted_size(context->client_address, 20, system_addresses);
    auto const response = (uint8_t *) calloc(response_length, 1);
    raknet_write_online_connection_request_accepted(response, &response_length, context->client_address, 20, system_addresses,client_timestamp, get_current_time_ms());
    const queue_packet_t packet = {
        .raw_packet = BUFFER_TO_BINARY_STREAM(response, response_length),
        .reliability = RELIABILITY_UNRELIABLE,
    };
    add_to_sent_queue(context, packet);
    return true;
}

bool handle_new_incoming_connection(const uint8_t *buffer, const size_t length, client_context_t *context, const server_context_t *server_context) {
    size_t offset = 0;
    rak_address_t server_address, client_address;
    bool failed = false;
    failed &= raknet_read_online_new_incoming_connection(buffer, &offset, length, &server_address, &client_address);
    failed |= (uint16_t) client_address.port != io_switch_int16(context->basic_info.address.sin_port);
    failed |= (uint32_t) client_address.ipv4_address == 0xFFFFFFFF;
    if (is_have_bedrock_player(server_context, &context->basic_info)) {
        return false;
    }
    context->packet_violation |= failed << FAILED_NEW_INCOMING_ADDRESS;
    // print_uint16_base2_debug(context->packet_violation, true);
    // printf("\n");
    context->player_data = malloc(sizeof(bedrock_player_data_t));
    create_bedrock_player(server_context, context->player_data, context);
    context->basic_info.state = CONNECTION_STATE_CONNECTED;
    return true;
}

bool handle_online_ping(const uint8_t *buffer, const size_t length, client_context_t *context) {
    size_t offset = 0;
    int64_t client_send_time;
    raknet_read_online_ping(buffer, &offset, &client_send_time);
    size_t response_length = 17;
    auto const response = (uint8_t *) calloc(response_length, 1);
    raknet_write_online_pong(response, &response_length, client_send_time, get_current_time_ms());
    const queue_packet_t packet = {
        .raw_packet = BUFFER_TO_BINARY_STREAM(response, response_length),
        .reliability = RELIABILITY_UNRELIABLE
    };
    add_to_sent_queue(context, packet);
    return true;
}

bool handle_ack_packet(const uint8_t *buffer, const size_t length, client_context_t *context) {
    context->last_receive_time = get_current_time_ms();
    size_t offset = 0;
    const size_t sequence_count = raknet_read_online_ack_nack_size(buffer);
    if (sequence_count <= 0)
        return false;
    uint32_t *sequence_numbers = malloc(sequence_count * sizeof(uint32_t));
    raknet_read_online_ack_nack(buffer, &offset, length, sequence_numbers);
    for (size_t i = 0; i < sequence_count; i++)
        deduct_raknet_encoded_datagram_resend_packets_queue(context, sequence_numbers[i]);
    free(sequence_numbers);
    return true;
}

bool handle_nack_packet(const uint8_t *buffer, const size_t length, client_context_t *context) {
    size_t offset = 0;
    const size_t sequence_count = raknet_read_online_ack_nack_size(buffer);
    if (sequence_count <= 0)
        return false;
    uint32_t *sequence_numbers = malloc(sequence_count * sizeof(uint32_t));
    raknet_read_online_ack_nack(buffer, &offset, length, sequence_numbers);
    for (size_t i = 0; i < sequence_count; i++) {
        packet_datagrams_t packet_datagrams;
        if (resend_map_retransmit(context->retransmission, sequence_numbers[i], &packet_datagrams)) {
            if (packet_datagrams.sequence_number != 0 && packet_datagrams.datagram_packets_count != 0 && packet_datagrams.datagram_packets != NULL) {
                packet_datagrams.sequence_number = context->next_sequence_number;
                append_raknet_encoded_datagram_resend_packets_queue(context, packet_datagrams);
                context->next_sequence_number++;
                size_t frames_packets_size = 4;
                for (size_t ii = 0; ii < packet_datagrams.datagram_packets_count; ii++)
                    frames_packets_size += raknet_write_online_data_gram_capsule_size(packet_datagrams.datagram_packets[ii]);
                uint8_t *output_buffer = calloc(frames_packets_size, 1);
                size_t output_offset = 0;
                raknet_write_online_frames_header(output_buffer, &output_offset, (int8_t) (FLAG_VALID | FLAG_PACKET_PAIR), (int32_t) packet_datagrams.sequence_number);
                for (size_t ii = 0; ii < packet_datagrams.datagram_packets_count; ii++)
                    raknet_write_online_data_gram_capsule(output_buffer, &output_offset, packet_datagrams.datagram_packets[ii]);
                add_to_raw_packets_queues(&context->basic_info, BUFFER_TO_BINARY_STREAM(output_buffer, frames_packets_size));
            }
        }
    }
    free(sequence_numbers);
    return true;
}

bool process_datagram_packet(const rak_message_t message, client_context_t *client_context, const server_context_t *server_context) {
    const uint8_t encoded_packet_id = message.payload[0];
    switch (encoded_packet_id) {
        case ID_PING:
            return handle_online_ping(message.payload + 1, message.payload_size - 1, client_context);
        case ID_PONG:
            return true;
        case ID_DISCONNECT_NOTIFICATION: {
            if (client_context->basic_info.state == CONNECTION_STATE_CONNECTED) {
                const binary_stream_t batch_packet = {
                    .buffer = malloc(message.payload_size),
                    .size = message.payload_size
                };
                memcpy(batch_packet.buffer, message.payload, message.payload_size);
                push_batch_packets_queue_c2p(client_context->player_data, batch_packet);
                return true;
            }
            client_context->basic_info.state = CONNECTION_STATE_DISCONNECTED;
            return true;
        }
        default: break;
    }
    if (client_context->basic_info.state == CONNECTION_STATE_CONNECTING) {
        switch (encoded_packet_id) {
            case ID_REQUEST:
#ifndef BYPASS_ALL_TEST
                client_context->packet_violation |= is_ordered(message.reliability) << FAILED_ORDERED_CONNECTION_REQUEST;
                client_context->packet_violation |= message.invalid_need_b_and_as << FAILED_NEED_B_AND_AS_REQUEST;
#endif
                return handle_connection_request(message.payload + 1, message.payload_size - 1, client_context);
            case ID_NEW_INCOMING_CONNECTION:
                return handle_new_incoming_connection(message.payload + 1, message.payload_size - 1, client_context, server_context);
            default:
                return false;
        }
    }
    if (client_context->basic_info.state == CONNECTION_STATE_CONNECTED) {
        if (encoded_packet_id == MINECRAFT_BEDROCK_BATCH_PACKET) { //#blameshoghi
            const binary_stream_t batch_packet = {
                .buffer = malloc(message.payload_size),
                .size = message.payload_size
            };
            memcpy(batch_packet.buffer, message.payload, message.payload_size);
            push_batch_packets_queue_c2p(client_context->player_data, batch_packet);//todo: make it order
        }
    }
    return false;
}

bool handle_datagram_packet(const uint8_t *buffer, const size_t length, client_context_t *context, server_context_t *server_context) {
    size_t offset = 1;
    const uint8_t datagram_packet_id = buffer[0];
    uint32_t sequence_number;
    raknet_read_online_frames_header(buffer, &offset, length, (int32_t *)&sequence_number);
    context->last_receive_time = get_current_time_ms();
    deduct_raknet_nack_queue(context, sequence_number);
    add_to_ack_queue(context, sequence_number);
    if (sequence_number == context->expected_sequence_number) {
        context->expected_sequence_number++;
    } else if (sequence_number > context->expected_sequence_number) {
        for (uint32_t i = context->expected_sequence_number; i < sequence_number; i++)
            add_to_nack_queue(context, i);
        context->expected_sequence_number = sequence_number + 1;
    }
    while (offset < length) {
        rak_message_t message = {nullptr};
        memset(&message, 0, sizeof(message));
        if (!raknet_read_online_data_gram_capsule(buffer, &offset, length, &message)) {
            if (message.payload != NULL)
                free(message.payload);
            break;
        }
        if (message.segmented) {
#ifndef BYPASS_ALL_TEST
            if (message.segmented_index == 0 && datagram_packet_id == ID_SET_C)
                context->packet_violation |= 1 << FAILED_DATAGRAM_ALL_C;
            if (message.segmented_index != 0 && datagram_packet_id == ID_SET_4)
                context->packet_violation |= 1 << FAILED_DATAGRAM_ALL_4;
#endif
            append_raknet_segmented_datagram_queue(context, message);
            if (get_raknet_segmented_size(context, message.segmented_id) == message.segmented_count) {
                rak_message_t output_datagram = {
                    .segmented_id = message.segmented_id,
                    .segmented_index = message.segmented_count,
                    .segmented_count = message.segmented_count,
                    .reliability = message.reliability,
                    .payload_size = 0,
                    .payload = (uint8_t *) malloc(0)
                };
                for (uint32_t i = 0; i < message.segmented_count; i++) {
                    const rak_message_t compound_entry = pop_raknet_segmented_datagram_entry(context, message.segmented_id, i);
                    output_datagram.payload = reallocarray(output_datagram.payload, output_datagram.payload_size + compound_entry.payload_size, sizeof(uint8_t));
                    memcpy(output_datagram.payload + output_datagram.payload_size, compound_entry.payload, compound_entry.payload_size);
                    output_datagram.payload_size += compound_entry.payload_size;
                    free(compound_entry.payload);
                }
                context->packet_violation |= (!process_datagram_packet(output_datagram, context, server_context)) << FAILED_PACKET_ERROR;
            }
        }else {
            context->packet_violation |= (!process_datagram_packet(message, context, server_context) << FAILED_PACKET_ERROR);
            if (message.payload != NULL) {
                free(message.payload);
                message.payload = nullptr;
            }
        }
    }
    return true;
}