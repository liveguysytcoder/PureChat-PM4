//
// Created by kani on 6/12/25.
//
#include "encryption.h"

#include "debug.h"
#ifdef WOLFSSL
#include <wolfssl/ssl.h>
#include <wolfssl/wolfcrypt/aes.h>
#else
#include <openssl/rand.h>
#endif

#ifdef WOLFSSL
void generate_server_keypair(ecc_key **server_key) {
	WC_RNG rng;
	*server_key = (ecc_key*)malloc(sizeof(ecc_key));
	if (wc_ecc_init(*server_key) != 0) {
		free(*server_key);
		*server_key = nullptr;
		return;
	}
	if (wc_InitRng(&rng) != 0) {
		free(*server_key);
		*server_key = nullptr;
		return;
	}
	if (wc_ecc_make_key(&rng, 48, *server_key) != 0) {
		wc_ecc_free(*server_key);
		wc_FreeRng(&rng);
		return;
	}
	wc_FreeRng(&rng);
}
#else
void generate_server_keypair(EVP_PKEY **server_key) {
    EVP_PKEY_CTX *server_ctx = EVP_PKEY_CTX_new_id(EVP_PKEY_EC, nullptr);
    if (EVP_PKEY_keygen_init(server_ctx) <= 0) {
        EVP_PKEY_CTX_free(server_ctx);
    }
    if (EVP_PKEY_CTX_set_ec_paramgen_curve_nid(server_ctx, OBJ_txt2nid("secp384r1")) <= 0) {
        EVP_PKEY_CTX_free(server_ctx);
    }
    if (EVP_PKEY_keygen(server_ctx, server_key) <= 0) {
        EVP_PKEY_CTX_free(server_ctx);
    }
    EVP_PKEY_CTX_free(server_ctx);
}
#endif

void cleanup_aes_256_ctr(player_cipher_block_t *cipher) {
    if (cipher->server_key != nullptr) {
#ifdef WOLFSSL
    	wc_ecc_free(cipher->server_key);
    	free(cipher->server_key);
    	cipher->server_key = nullptr;
#else
        EVP_PKEY_free(cipher->server_key);
#endif
    }
    if (!cipher->enabled) {
        return;
    }
	free(cipher->key);
	free(cipher->salt);
#ifdef WOLFSSL
	if (cipher->encrypt_block != nullptr) {
		wc_AesFree(cipher->encrypt_block);
		free(cipher->encrypt_block);
		cipher->encrypt_block = nullptr;
	}
	if (cipher->decrypt_block != nullptr) {
		wc_AesFree(cipher->decrypt_block);
		free(cipher->decrypt_block);
		cipher->decrypt_block = nullptr;
	}
#else
    EVP_CIPHER_CTX_free(cipher->encrypt_block);
    EVP_CIPHER_CTX_free(cipher->decrypt_block);
    cipher->encrypt_block = nullptr;
    cipher->decrypt_block = nullptr;
#endif
    cipher->enabled = false;
}

bool init_aes_256_ctr(uint8_t *key, uint8_t *iv, player_cipher_block_t *cipher) {
#ifdef WOLFSSL
	cipher->encrypt_block = (Aes*)malloc(sizeof(Aes));
	cipher->decrypt_block = (Aes*)malloc(sizeof(Aes));
	if (wc_AesInit(cipher->encrypt_block, NULL, INVALID_DEVID) != 0) goto CLEAN;
	if (wc_AesInit(cipher->decrypt_block, NULL, INVALID_DEVID) != 0) goto CLEAN;
	if (wc_AesSetKeyDirect(cipher->encrypt_block, key, 32, iv, AES_ENCRYPTION) != 0) goto CLEAN;
	if (wc_AesSetKeyDirect(cipher->decrypt_block, key, 32, iv, AES_ENCRYPTION) != 0) goto CLEAN;
#else
    cipher->encrypt_block = EVP_CIPHER_CTX_new();
    cipher->decrypt_block = EVP_CIPHER_CTX_new();
    if (!EVP_EncryptInit_ex(cipher->encrypt_block, EVP_aes_256_ctr(), nullptr, key, iv)) {
        goto CLEAN;
    }
    if (!EVP_DecryptInit_ex(cipher->decrypt_block, EVP_aes_256_ctr(), nullptr, key, iv)) {
        goto CLEAN;
    }
#endif
	cipher->key = key;
	free(iv);
    cipher->enabled = true;
    return true;
CLEAN:
    cleanup_aes_256_ctr(cipher);
    return false;
}

bool setup_encryption(uint8_t** player_key, const int64_t key_size, player_cipher_block_t *cipher) {



	size_t out_length;
	char *key = b64_encode_with_alloc(*player_key, key_size, &out_length);
	printf("client_key: ");
	for (size_t i = 0; i < out_length; i++) {
		printf("%c", key[i]);
	}
	printf("\n");
	free(key);


    size_t key_length = 48;
	cipher->salt = malloc(16);
	memset(cipher->salt, 'X', 16);
	// RAND_bytes(cipher->salt, 16);
    auto const derived_key = (uint8_t *) malloc(key_length);
    uint8_t *secretKeyBytes = malloc(32);
#ifdef WOLFSSL
	ecc_key player_public_key;
	wc_ecc_init(&player_public_key);
	word32 idx = 0;
	if (wc_EccPublicKeyDecode(*player_key, &idx, &player_public_key, key_size) != 0 || wc_ecc_shared_secret(cipher->server_key, &player_public_key, derived_key, (uint32_t *)&key_length) != 0) {
		wc_ecc_free(&player_public_key);
		free(derived_key);
		free(cipher->salt);
		return false;
	}
	wc_ecc_free(&player_public_key);
	wc_Sha256 sha256;
	wc_InitSha256(&sha256);
	wc_Sha256Update(&sha256, cipher->salt, 16);
	wc_Sha256Update(&sha256, derived_key, key_length);
	wc_Sha256Final(&sha256, secretKeyBytes);
	wc_Sha256Free(&sha256);
#else
    EVP_PKEY *player_public_key = d2i_PUBKEY(nullptr, (const uint8_t **) player_key, key_size);
	EVP_PKEY_CTX *ctx = EVP_PKEY_CTX_new(cipher->server_key, nullptr);
    if (EVP_PKEY_derive_init(ctx) <= 0 || EVP_PKEY_derive_set_peer(ctx, player_public_key) <= 0 || EVP_PKEY_derive(ctx, derived_key, &key_length) <= 0) {//combine key
        EVP_PKEY_free(player_public_key);
        EVP_PKEY_CTX_free(ctx);
        free(derived_key);
    	free(secretKeyBytes);
        return false;
    }
    EVP_PKEY_free(player_public_key);
    EVP_PKEY_CTX_free(ctx);
    EVP_MD_CTX *md_ctx = EVP_MD_CTX_create();
    EVP_DigestInit_ex(md_ctx, EVP_sha256(), nullptr);
    EVP_DigestUpdate(md_ctx, cipher->salt, 16);
    EVP_DigestUpdate(md_ctx, derived_key, key_length);
    EVP_DigestFinal_ex(md_ctx, secretKeyBytes, nullptr);

	printf("combined: \n");
	debug_byte_buffer(secretKeyBytes, 32);

    EVP_MD_CTX_destroy(md_ctx);
#endif
    free(derived_key);
    uint8_t* iv = calloc(16, 1);
    memcpy(iv, secretKeyBytes, 12);
    iv[15] = (uint8_t) 0x02;
    return init_aes_256_ctr(secretKeyBytes, iv, cipher);
}

int64_t calculate_checksum(const int64_t block_counter, uint8_t **key, const uint8_t *input_buffer, const size_t input_size) {
    uint8_t hash[32];
    uint8_t counter[8];
    io_write_int64(counter, block_counter, io_little_endian);
#ifdef WOLFSSL
	wc_Sha256 sha;
	wc_InitSha256(&sha);
	wc_Sha256Update(&sha, counter, 8);
	wc_Sha256Update(&sha, input_buffer, (word32)input_size);
	wc_Sha256Update(&sha, *key, 32);
	wc_Sha256Final(&sha, hash);
#else
    EVP_MD_CTX *md_ctx = EVP_MD_CTX_create();
    EVP_DigestInit_ex(md_ctx, EVP_sha256(), nullptr);
    EVP_DigestUpdate(md_ctx, counter, 8);
    EVP_DigestUpdate(md_ctx, input_buffer, input_size);
    EVP_DigestUpdate(md_ctx, *key, 32);
    EVP_DigestFinal_ex(md_ctx, hash, nullptr);
    EVP_MD_CTX_destroy(md_ctx);
#endif
    return io_read_int64(hash, io_little_endian);
}

bool encrypt_packet_buffer(const uint8_t *input_buffer, size_t input_size, uint8_t **output_buffer, size_t *output_size, player_cipher_block_t *cipher) {
    const int64_t hash = calculate_checksum(cipher->encrypt_block_counter++, &cipher->key, input_buffer, input_size);
    uint8_t *payload = malloc(input_size + 8);
    memcpy(payload, input_buffer, input_size);
    io_write_int64(payload + input_size, hash, io_little_endian);
	input_size += 8;
    *output_buffer = (uint8_t *) malloc((input_size + EVP_MAX_BLOCK_LENGTH) * sizeof(uint8_t));
#ifdef WOLFSSL
	wc_AesCtrEncrypt(&cipher->encrypt_block, *output_buffer, payload, input_size);
	*output_size = input_size;
#else
    EVP_EncryptUpdate(cipher->encrypt_block, *output_buffer, (int *) output_size, payload, (int)input_size);
#endif

	free(payload);
    return true;
}

bool decrypt_packet_buffer(const uint8_t *input_buffer, const size_t input_size, uint8_t **output_buffer, size_t *output_size, player_cipher_block_t *cipher) {
    if (input_size < 9)
        return false;
    int decrypted_len;
    uint8_t block_output[input_size];
#ifdef WOLFSSL
	wc_AesCtrEncrypt(&cipher->decrypt_block, block_output, input_buffer, input_size);
	decrypted_len = (int32_t) input_size;
#else
    EVP_DecryptUpdate(cipher->decrypt_block, block_output, &decrypted_len, input_buffer, (int)input_size);
#endif
    const int64_t checksum = io_read_int64(block_output + (decrypted_len - 8), io_little_endian);
    const int64_t hash = calculate_checksum(cipher->decrypt_block_counter++, &cipher->key, block_output, decrypted_len - 8);
	assert(checksum == hash);
	if (checksum != hash) return false;
    *output_size = decrypted_len - 8;
	*output_buffer = (uint8_t *) malloc(*output_size);
    memcpy(*output_buffer, block_output, *output_size);
    return true;
}

jwt_data_t jwt_decode_segments(char *jwt_buffer, const size_t jwt_size) {
    const char* next = strchr(jwt_buffer, '.');
    const char* next_ptr = strchr(next + 1, '.');
    const jwt_data_t ret = {
        .raw_jwt = UTL_ARRTOSTR(jwt_buffer, jwt_size),
        .part1_end = next - jwt_buffer,
        .part2_end = next_ptr - jwt_buffer
    };
    return ret;
}

bool phd_send_encryption_request(player_cipher_block_t *cipher_block) {
    BIO *bio = BIO_new(BIO_s_mem());
    if (!i2d_PUBKEY_bio(bio, cipher_block->server_key)) {
        BIO_free(bio);
        return false;
    }
    const int32_t der_length = BIO_pending(bio);
    auto const der_string = (uint8_t *) malloc(der_length);
    if (BIO_read(bio, der_string, der_length) != der_length) {
        free(der_string);
        BIO_free(bio);
        return false;
    }
    BIO_free(bio);
	size_t out_length;
	char *new_salt = b64_encode_with_alloc(cipher_block->salt, 16, &out_length);
	size_t json_salt_len = strlen("{\"salt\":\"\"}") + out_length + 1;
    char json_salt[json_salt_len];
    snprintf(json_salt, json_salt_len, "{\"salt\":\"%s\"}", new_salt);
	free(new_salt);
	size_t actual_salt_len;
	char *actual_salt = b64url_encode_with_alloc(json_salt, json_salt_len - 1, &actual_salt_len);
	char *x5u = b64_encode_with_alloc(der_string, der_length, &out_length);
	free(der_string);
	const size_t raw_body_len = strlen("{\"x5u\":\"\",\"alg\":\"ES384\"}") + out_length + 1;
    char raw_body[raw_body_len];
    snprintf(raw_body, raw_body_len, "{\"x5u\":\"%s\",\"alg\":\"ES384\"}", x5u);
	printf("%s\n", raw_body);
	free(x5u);
	size_t body_hack_len;
	char *body_hack = b64url_encode_with_alloc(raw_body, raw_body_len -1, &body_hack_len);
	const size_t hack_body_len = body_hack_len + actual_salt_len + 2;
    char hack_body[hack_body_len];
    snprintf(hack_body, hack_body_len, "%s.%s", body_hack, actual_salt);
	// printf("%s\n", hack_body);
	free(body_hack);
	free(actual_salt);
	EVP_MD_CTX *ctx = EVP_MD_CTX_new();
	if (EVP_DigestSignInit(ctx, nullptr, EVP_sha384(), nullptr, cipher_block->server_key) != 1) {
		return false;
	}
	if (EVP_DigestSignUpdate(ctx, hack_body, hack_body_len - 1) != 1) {
		return false;
	}
	size_t sigLength;
	if (EVP_DigestSignFinal(ctx, nullptr, &sigLength) != 1) {
		return false;
	}
	unsigned char * signature = malloc(sigLength);
	if (EVP_DigestSignFinal(ctx, signature, &sigLength) != 1) {
		free(signature);
		return false;
	}
	const unsigned char *sig_ptr = signature;
	ECDSA_SIG *parsedSignature = d2i_ECDSA_SIG(nullptr, &sig_ptr, (long)sigLength);
	free(signature);
	if (!parsedSignature) {
		free(hack_body);
		return false;
	}
	EVP_MD_CTX_free(ctx);
	const BIGNUM *pr = ECDSA_SIG_get0_r(parsedSignature);
	const BIGNUM *ps = ECDSA_SIG_get0_s(parsedSignature);
	free(parsedSignature);
	unsigned char sig[96];
    BN_bn2bin(pr, sig + (48 - BN_num_bytes(pr)));
    BN_bn2bin(ps, sig + (96 - BN_num_bytes(ps)));
	size_t signature_encoded_len;
	char *signature_encoded = b64url_encode_with_alloc(sig, 96, &signature_encoded_len);
	const size_t final_jwt_len = hack_body_len + signature_encoded_len + 2;
    cipher_block->shared_secret = malloc(final_jwt_len);
    snprintf((char *) cipher_block->shared_secret, final_jwt_len, "%s.%s", hack_body, signature_encoded);
	free(signature_encoded);
	cipher_block->shared_secret_size = final_jwt_len - 1;
	return true;
}

bool verify_rs256(const char *data, const uint8_t *signature_b64, const cJSON *jwk) {
	size_t sig_len;
	unsigned char *signature = b64url_decode_with_alloc(signature_b64, strlen((char *) signature_b64), &sig_len);
	cJSON *n = cJSON_GetObjectItem(jwk, "n");
	cJSON *e = cJSON_GetObjectItem(jwk, "e");
	if (!n || !e || !cJSON_IsString(n) || !cJSON_IsString(e)) {
		free(signature);
		return 0;
	}
	size_t n_len, e_len;
	unsigned char *n_bytes = b64url_decode_with_alloc((uint8_t *) n->valuestring, strlen(n->valuestring), &n_len);
	unsigned char *e_bytes = b64url_decode_with_alloc((uint8_t *) e->valuestring, strlen(e->valuestring), &e_len);
	EVP_PKEY *pkey = EVP_PKEY_new();
	EVP_PKEY_CTX *p_ctx = EVP_PKEY_CTX_new_id(EVP_PKEY_RSA, nullptr);
	OSSL_PARAM params[3];
	params[0] = OSSL_PARAM_construct_BN("n", n_bytes, n_len);
	params[1] = OSSL_PARAM_construct_BN("e", e_bytes, e_len);
	params[2] = OSSL_PARAM_construct_end();
	EVP_PKEY_fromdata_init(p_ctx);
	EVP_PKEY_fromdata(p_ctx, &pkey, EVP_PKEY_PUBLIC_KEY, params);
	EVP_MD_CTX *ctx = EVP_MD_CTX_new();
	EVP_DigestVerifyInit(ctx, nullptr, EVP_sha256(), nullptr, pkey);
	EVP_DigestVerifyUpdate(ctx, data, strlen(data));
	const int result = EVP_DigestVerifyFinal(ctx, signature, sig_len);
	EVP_MD_CTX_free(ctx);
	EVP_PKEY_CTX_free(p_ctx);
	EVP_PKEY_free(pkey);
	free(signature);
	free(n_bytes);
	free(e_bytes);
	return result == 1;
}

bool phd_check_jwt_data(const jwt_data_t *jwt_data, uint8_t **current_public_key, const int8_t chain_id) {
	const int64_t start_time = (int64_t) time(nullptr);
	size_t decoded_len = 0;
	auto const decoded_header = (char *) b64url_decode_with_alloc((const uint8_t *) jwt_data->raw_jwt.value, jwt_data->part1_end, &decoded_len);
	const cJSON *header_doc = cJSON_ParseWithLength(decoded_header, decoded_len);
	free(decoded_header);
	size_t signature_size;
	uint8_t *raw_signature = b64url_decode_with_alloc((const uint8_t *) jwt_data->raw_jwt.value + jwt_data->part2_end + 1, jwt_data->raw_jwt.length - (jwt_data->part2_end + 1), &signature_size);
	if (signature_size != 96)
		return false;
	const int bignum_sig_size = (int) signature_size >> 1;
	BIGNUM *pr = BN_bin2bn(raw_signature, bignum_sig_size, nullptr);
	BIGNUM *ps = BN_bin2bn((raw_signature + bignum_sig_size), bignum_sig_size, nullptr);
	free(raw_signature);
	ECDSA_SIG *ecdsa_sig = ECDSA_SIG_new();
	ECDSA_SIG_set0(ecdsa_sig, pr, ps);
	uint8_t *new_sig = nullptr;
	const int new_sig_len = i2d_ECDSA_SIG(ecdsa_sig, &new_sig);
	BN_free(pr);
	BN_free(ps);
	char *x5u = cJSON_GetStringValue(cJSON_GetObjectItem(header_doc, "x5u"));
	uint8_t *header_der_key = b64_decode_with_alloc((const uint8_t *) x5u, strlen(x5u), &decoded_len);
	free(x5u);
	if (*current_public_key == NULL) {
		if (chain_id != 0) {
			free(header_der_key);
			return false;
		}
	} else if (memcmp(header_der_key, *current_public_key, 120) != 0) {
		free(header_der_key);
		return false;
	}
	EVP_MD_CTX *md_ctx = EVP_MD_CTX_new();
	EVP_PKEY *public_key = d2i_PUBKEY(nullptr, (const uint8_t **) &header_der_key, (int64_t) decoded_len);
	if (EVP_DigestVerifyInit(md_ctx, nullptr, EVP_sha384(), nullptr, public_key) != 1) {
		free(new_sig);
		EVP_PKEY_free(public_key);
		EVP_MD_CTX_free(md_ctx);
		return false;
	}
	EVP_PKEY_free(public_key);
	if (EVP_DigestVerifyUpdate(md_ctx, jwt_data->raw_jwt.value, jwt_data->part2_end) != 1) {
		free(new_sig);
		EVP_MD_CTX_free(md_ctx);
		return false;
	}
	const int result = EVP_DigestVerifyFinal(md_ctx, new_sig, new_sig_len);
	free(new_sig);
	EVP_MD_CTX_free(md_ctx);
	if (result != 1) return false;
	if (chain_id == 3) return true;
	auto const payload_decoded = (char *) b64url_decode_with_alloc((const uint8_t *) jwt_data->raw_jwt.value + jwt_data->part1_end + 1, jwt_data->part2_end - (jwt_data->part1_end + 1), &decoded_len);
	cJSON *payload_doc = cJSON_ParseWithLength(payload_decoded, decoded_len);
	free(payload_decoded);
	const double exp_date = cJSON_GetNumberValue(cJSON_GetObjectItem(payload_doc, "exp"));
	const char *identity_public_key = cJSON_GetStringValue(cJSON_GetObjectItem(payload_doc, "identityPublicKey"));
	const double nbf_date = cJSON_GetNumberValue(cJSON_GetObjectItem(payload_doc, "nbf"));
	if((int64_t) nbf_date > start_time + 60 || (int64_t) exp_date < start_time - 60){
		cJSON_Delete(payload_doc);
		return false;
	}
	free(*current_public_key);
	*current_public_key = b64_decode_with_alloc((const uint8_t *)identity_public_key, strlen(identity_public_key), &decoded_len);
	cJSON_Delete(payload_doc);
	return true;
}