#include <pthread.h>
#include <stdio.h>
#include <signal.h>
#include <unistd.h>

#include "raknet_server.h"

static volatile int running = 1;

void signal_handler(int sig) {
    printf("\n[MAIN] Received signal %d, shutting down...\n", sig);
    running = 0;
}

int main() {
    signal(SIGINT, signal_handler);
    signal(SIGTERM, signal_handler);

    if (raknet_server_init(19133) < 0) {
        return 1;
    }

    pthread_t recv_tid, send_tid;

    if (pthread_create(&recv_tid, nullptr, raknet_server_recv_thread, NULL) != 0) {
        raknet_server_shutdown();
        return 1;
    }
    //
    // if (pthread_create(&send_tid, nullptr, raknet_server_send_thread, NULL) != 0) {
    //     raknet_server_shutdown();
    //     return 1;
    // }

    printf("[MAIN] Server running. Press Ctrl+C to stop.\n\n");

    while (running) {
        sleep(1);
    }
    raknet_server_shutdown();
    pthread_kill(recv_tid, 9);
    pthread_join(recv_tid, nullptr);

    printf("[MAIN] Waiting for threads to finish...\n");

    printf("[MAIN] Shutdown complete.\n");
    return 0;
}