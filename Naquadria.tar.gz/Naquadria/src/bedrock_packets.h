//
// Created by zeen on 9/5/25.
//

#ifndef BEDROCK_PACKETS_H
#define BEDROCK_PACKETS_H

#include <stddef.h>
#include <stdint.h>

#include "bedrock_net_serializer.h"
#include "bedrock_packet_ids.h"

typedef struct {
    uint32_t protocol_version;
    uint8_t* auth_info_json;
    int32_t auth_info_json_size;
    uint8_t* client_data_jwt;
    int32_t client_data_jwt_size;
} login_packet_t;

typedef struct {
    uint8_t* jwt;
    uint32_t jwt_size;
} server_to_client_handshake_packet_t;

typedef struct {
    int32_t reason;
    uint8_t* message;
    uint32_t message_size;
    uint8_t* filtered_message;
    uint32_t filtered_message_size;
} disconnect_packet_t;

typedef struct {
    bool must_accept;
    bool has_addons;
    bool has_scripts;
    bool force_disable_vibrant_visuals;
    uuid_t world_template_id;
    uint8_t* world_template_version;
    uint32_t world_template_version_size;
    uint16_t resource_packs_count;
    resource_pack_info_entry_t* resource_packs;
} resource_packs_info_packet_t;

typedef struct {
    bool must_accept;
    resource_pack_stack_entry_t* resource_pack_stack;
    uint32_t resource_pack_stack_size;
    resource_pack_stack_entry_t* behavior_pack_stack;
    uint32_t behavior_pack_stack_size;
    uint8_t* base_game_version;
    uint32_t base_game_version_size;
    uint32_t experiments_size;
    experiment_entry_t* experiments;
    bool has_previously_used_experiments;
    bool use_vanilla_editor_packs;
} resource_pack_stack_packet_t;

typedef struct {
    int8_t status;
    binary_stream_t *pack_ids;
    uint16_t pack_ids_size;
} resource_pack_client_response_packet_t;

typedef struct {
    uint8_t* pack_id;
    uint32_t pack_id_size;
    uint32_t max_chunk_size;
    uint32_t chunk_count;
    uint64_t compressed_pack_size;
    uint8_t* sha256;
    uint32_t sha256_size;
    bool is_premium;
    uint8_t pack_type;
} resource_pack_data_info_packet_t;

typedef struct {
    uint8_t* pack_id;
    uint32_t pack_id_size;
    uint32_t chunk_index;
    uint64_t offset;
    uint8_t* data;
    uint32_t data_size;
} resource_pack_chunk_data_packet_t;

typedef struct {
    uint8_t* pack_id;
    uint32_t pack_id_size;
    uint32_t chunk_index;
} resource_pack_chunk_request_packet_t;

typedef struct {
    uint32_t protocol_version;
} request_network_settings_packet_t;

typedef struct {
    int16_t compression_threshold;
    int16_t compression_algorithm;
    bool enable_client_throttling;
    int8_t client_throttle_threshold;
    float client_throttle_scalar;
} network_settings_packet_t;

login_packet_t read_login_packet_t(pck_packet_t* packet, minecraft_protocol_version_t version);

void write_server_to_client_handshake_packet_t(pck_packet_t* packet, server_to_client_handshake_packet_t server_to_client_handshake_packet, minecraft_protocol_version_t version);

void write_disconnect_packet_t(pck_packet_t* packet, disconnect_packet_t disconnect_packet, minecraft_protocol_version_t version);

disconnect_packet_t read_disconnect_packet_t(pck_packet_t* packet, minecraft_protocol_version_t version);

void write_resource_packs_info_packet_t(pck_packet_t* packet, resource_packs_info_packet_t resource_packs_info_packet, minecraft_protocol_version_t version);

void write_resource_pack_stack_packet_t(pck_packet_t* packet, resource_pack_stack_packet_t resource_pack_stack_packet, minecraft_protocol_version_t version);

resource_pack_client_response_packet_t read_resource_pack_client_response_packet_t(pck_packet_t* packet, minecraft_protocol_version_t version);

void write_resource_pack_data_info_packet_t(pck_packet_t* packet, resource_pack_data_info_packet_t resource_pack_data_info_packet, minecraft_protocol_version_t version);

void write_resource_pack_chunk_data_packet_t(pck_packet_t* packet, resource_pack_chunk_data_packet_t resource_pack_chunk_data_packet, minecraft_protocol_version_t version);

resource_pack_chunk_request_packet_t read_resource_pack_chunk_request_packet_t(pck_packet_t* packet, minecraft_protocol_version_t version);

request_network_settings_packet_t read_network_settings_packet(pck_packet_t* packet);

void write_network_settings_packet_t(pck_packet_t *packet, network_settings_packet_t network_settings_packet, minecraft_protocol_version_t version);

#endif //BEDROCK_PACKETS_H
