//
// Created by kani on 6/13/25.
//

#ifndef STR_UTIL_H
#define STR_UTIL_H
#include <stddef.h>
#pragma once

#define UTL_CONSOLE_RESET    "\033[0m"

#define UTL_CONSOLE_BLACK    "\033[30m"
#define UTL_CONSOLE_RED      "\033[31m"
#define UTL_CONSOLE_GREEN    "\033[32m"
#define UTL_CONSOLE_YELLOW   "\033[33m"
#define UTL_CONSOLE_BLUE     "\033[34m"
#define UTL_CONSOLE_MAGENTA  "\033[35m"
#define UTL_CONSOLE_CYAN     "\033[36m"
#define UTL_CONSOLE_WHITE    "\033[37m"

#define UTL_CONSOLE_BRIGHT_BLACK    "\033[30;1m"
#define UTL_CONSOLE_BRIGHT_RED      "\033[31;1m"
#define UTL_CONSOLE_BRIGHT_GREEN    "\033[32;1m"
#define UTL_CONSOLE_BRIGHT_YELLOW   "\033[33;1m"
#define UTL_CONSOLE_BRIGHT_BLUE     "\033[34;1m"
#define UTL_CONSOLE_BRIGHT_MAGENTA  "\033[35;1m"
#define UTL_CONSOLE_BRIGHT_CYAN     "\033[36;1m"
#define UTL_CONSOLE_BRIGHT_WHITE    "\033[37;1m"

#define UTL_STRTOCSTR(str) str.value
#define UTL_CSTRTOSTR(str) (string_t) { .value = str, .length = sizeof(str) - 1 }
#define UTL_ARRTOSTR(arr, len) (string_t) { .value = arr, .length = len }

#define UTL_STRTOARG(str) str.value, str.length
#define UTL_CSTRTOARG(str) str, sizeof(str) - 1

#define UTL_STRLEN(str) str.length

#define UTL_FREESTR(str) if (str.value != NULL) free(str.value)

typedef struct {
    char* value;
    size_t length;
} string_t;

#endif //STR_UTIL_H
