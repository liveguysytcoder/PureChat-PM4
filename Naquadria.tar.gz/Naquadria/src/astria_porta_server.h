//
// Created by zeen on 10/10/25.
//

#ifndef ASTRIA_PORTA_SERVER_H
#define ASTRIA_PORTA_SERVER_H

#include "binarystream.h"

typedef struct bedrock_player_data bedrock_player_data_t;

typedef struct astria_porta_server {
    size_t                              players_size;
    bedrock_player_data_t               *players;
    // binary_stream_t                     *processing_packets;
    size_t                              raw_packets_size;
    binary_stream_t                     *raw_packets;
    //address
    //rtt

} astria_porta_server_t;
#endif //ASTRIA_PORTA_SERVER_H
