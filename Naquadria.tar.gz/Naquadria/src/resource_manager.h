//
// Created by zeen on 11/15/25.
//

#ifndef RESOURCE_MANAGER_H
#define RESOURCE_MANAGER_H
#include "bedrock_net_serializer.h"

pck_packet_t* read_file(const char *path);


#endif //RESOURCE_MANAGER_H
