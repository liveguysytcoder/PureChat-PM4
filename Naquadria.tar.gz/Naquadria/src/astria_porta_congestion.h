//
// Created by zeen on 10/15/25.
//

#ifndef ASTRIA_PORTA_CONGESTION_H
#define ASTRIA_PORTA_CONGESTION_H

#include <stdint.h>
#include <stdbool.h>
#include <time.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>

#define MAX_PACKET_SIZE 1472
#define MIN_PACKET_SIZE 1200
#define PACKET_HEADER_SIZE 16
#define MAX_ACK_DELAY_US 25000
#define TIMER_GRANULARITY_NS 1000000
#define MAX_ACK_RANGES 64

#define INITIAL_RTT_MS 333
#define CUBIC_BETA 0.7
#define CUBIC_C 0.4
#define RENO_REDUCTION_FACTOR 0.5

#define BURST_INTERVAL_NS 2000000
#define MIN_BURST_SIZE 10
#define MAX_BURST_SIZE 256

#define MIN(a, b) ((a) < (b) ? (a) : (b))
#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define CLAMP(val, min, max) ((val) < (min) ? (min) : ((val) > (max) ? (max) : (val)))

static inline int64_t timespec_to_ns(const struct timespec *ts) {
    return (int64_t)ts->tv_sec * 1000000000LL + ts->tv_nsec;
}

static inline int64_t timespec_diff_ns(const struct timespec *now, const struct timespec *then) {
    return timespec_to_ns(now) - timespec_to_ns(then);
}

static inline double timespec_diff_sec(const struct timespec *now, const struct timespec *then) {
    return (double)timespec_diff_ns(now, then) / 1000000000.0;
}

typedef struct {
    bool measured;
    int64_t min_rtt_ns;
    int64_t latest_rtt_ns;
    int64_t smoothed_rtt_ns;
    int64_t rtt_var_ns;
} rtt_t;

static inline void rtt_init(rtt_t *rtt) {
    constexpr int64_t initial = INITIAL_RTT_MS * 1000000LL;
    rtt->measured = false;
    rtt->min_rtt_ns = initial;
    rtt->latest_rtt_ns = 0;
    rtt->smoothed_rtt_ns = initial;
    rtt->rtt_var_ns = initial / 2;
}

static inline void rtt_add(rtt_t *rtt, const int64_t latest_rtt_ns, int64_t ack_delay_ns) {
    if (latest_rtt_ns <= 0) return;
    rtt->latest_rtt_ns = latest_rtt_ns;
    if (!rtt->measured) {
        rtt->measured = true;
        rtt->min_rtt_ns = latest_rtt_ns;
        rtt->smoothed_rtt_ns = latest_rtt_ns;
        rtt->rtt_var_ns = latest_rtt_ns / 2;
        return;
    }
    rtt->min_rtt_ns = MIN(rtt->min_rtt_ns, latest_rtt_ns);
    ack_delay_ns = MIN(ack_delay_ns, MAX_ACK_DELAY_US * 1000LL);
    int64_t adjusted_rtt = latest_rtt_ns;
    if (latest_rtt_ns >= rtt->min_rtt_ns + ack_delay_ns)
        adjusted_rtt -= ack_delay_ns;
    const int64_t rtt_sample = llabs(rtt->smoothed_rtt_ns - adjusted_rtt);
    rtt->rtt_var_ns = (3 * rtt->rtt_var_ns + rtt_sample) / 4;
    rtt->smoothed_rtt_ns = (7 * rtt->smoothed_rtt_ns + adjusted_rtt) / 8;
}

static inline int64_t rtt_get_rto(const rtt_t *rtt) {
    return rtt->smoothed_rtt_ns + MAX(4 * rtt->rtt_var_ns, TIMER_GRANULARITY_NS) + MAX_ACK_DELAY_US * 1000LL;
}

typedef struct congestion_controller congestion_controller_t;

typedef void (*on_ack_fn)(congestion_controller_t *cc, struct timespec *now, struct timespec *sent, struct timespec *recovery_start, rtt_t *rtt, uint64_t bytes, uint64_t flight);
typedef void (*on_congestion_fn)(congestion_controller_t *cc, struct timespec *now, struct timespec *sent);

struct congestion_controller {
    uint64_t cwnd;
    uint64_t ssthres;
    uint64_t mss;
    on_ack_fn on_ack;
    on_congestion_fn on_congestion;
};

static inline uint64_t initial_window(const uint64_t mss) {
    return CLAMP(14720, 2 * mss, 10 * mss);
}

static inline uint64_t minimum_window(const uint64_t mss) {
    return 2 * mss;
}

static inline bool should_increase_window(const uint64_t flight, const uint64_t window, const uint64_t ssthres) {
    if (flight >= window) return true;
    const uint64_t available = window - flight;
    const bool slow_start_limited = ssthres > window && flight > window / 2;
    return slow_start_limited || available <= 3 * MAX_PACKET_SIZE;
}

typedef struct {
    congestion_controller_t base;
    uint64_t bytes_acked;
} reno_t;

static void reno_on_ack(congestion_controller_t *cc, struct timespec *now, struct timespec *sent, struct timespec *recovery_start, rtt_t *rtt, const uint64_t bytes, const uint64_t flight) {
    auto const r = (reno_t *)cc;
    if (!should_increase_window(flight, r->base.cwnd, r->base.ssthres)) {
        return;
    }
    if (r->base.cwnd < r->base.ssthres) {
        r->base.cwnd += r->base.mss;
        if (r->base.cwnd >= r->base.ssthres) {
            r->base.ssthres = r->base.cwnd;
        }
    } else {
        r->bytes_acked += bytes;
        if (r->bytes_acked >= r->base.cwnd) {
            r->bytes_acked -= r->base.cwnd;
            r->base.cwnd += r->base.mss;
        }
    }
}

static void reno_on_congestion(congestion_controller_t *cc, struct timespec *now, struct timespec *sent) {
    auto const r = (reno_t *)cc;
    r->base.cwnd = (uint64_t)((double)r->base.cwnd * RENO_REDUCTION_FACTOR);
    r->base.cwnd = MAX(r->base.cwnd, minimum_window(r->base.mss));
    r->bytes_acked = (uint64_t)((double)r->base.cwnd * RENO_REDUCTION_FACTOR);
    r->base.ssthres = r->base.cwnd;
}

static inline void reno_init(reno_t *reno, const uint64_t mss) {
    memset(reno, 0, sizeof(reno_t));
    reno->base.mss = mss;
    reno->base.cwnd = initial_window(mss);
    reno->base.ssthres = UINT64_MAX;
    reno->base.on_ack = reno_on_ack;
    reno->base.on_congestion = reno_on_congestion;
}

typedef struct {
    congestion_controller_t base;
    uint64_t cwnd_inc;
    double w_max;
    double k;
} cubic_t;

static inline double cubic_k(const double w_max, const uint64_t mss) {
    return cbrt(w_max / (double)mss * (1.0 - CUBIC_BETA) / CUBIC_C);
}

static inline double w_cubic(const double t, const double w_max, const double k, const uint64_t mss) {
    const double tk = t - k;
    return CUBIC_C * (tk * tk * tk + w_max / (double)mss) * (double)mss;
}

static inline double w_est(const double t, const double rtt, const double w_max, const uint64_t mss) {
    return (w_max / (double)mss * CUBIC_BETA + 3.0 * (1.0 - CUBIC_BETA) / (1.0 + CUBIC_BETA) * t / rtt) * (double)mss;
}

static void cubic_on_ack(congestion_controller_t *cc, const struct timespec *now, struct timespec *sent, const struct timespec *recovery_start, const rtt_t *rtt, const uint64_t bytes, const uint64_t flight) {
    auto const c = (cubic_t *)cc;
    if (!should_increase_window(flight, c->base.cwnd, c->base.ssthres))
        return;
    if (c->base.cwnd < c->base.ssthres) {
        c->base.cwnd += bytes;
        return;
    }
    const double smoothed_rtt_sec = (double)rtt->smoothed_rtt_ns / 1000000000.0;
    const double t = timespec_diff_sec(now, recovery_start);
    const double w = w_cubic(t + smoothed_rtt_sec, c->w_max, c->k, c->base.mss);
    const double est = w_est(t, smoothed_rtt_sec, c->w_max, c->base.mss);
    uint64_t cubic_cwnd = c->base.cwnd;
    if (w < est) {
        cubic_cwnd = MAX(cubic_cwnd, (uint64_t)est);
    } else if (cubic_cwnd < (uint64_t)w) {
        cubic_cwnd += (uint64_t)((w - (double)cubic_cwnd) / (double)cubic_cwnd * (double)c->base.mss);
    }
    c->cwnd_inc += cubic_cwnd - c->base.cwnd;
    if (c->cwnd_inc >= c->base.mss) {
        c->base.cwnd += c->base.mss;
        c->cwnd_inc = 0;
    }
}

static void cubic_on_congestion(congestion_controller_t *cc, struct timespec *now, struct timespec *sent) {
    auto const c = (cubic_t *)cc;
    if ((double)c->base.cwnd < c->w_max) {
        c->w_max = (double)c->base.cwnd * (1.0 - CUBIC_BETA) / 2.0;
    } else {
        c->w_max = (double)c->base.cwnd;
    }
    c->base.ssthres = MAX((uint64_t)(c->w_max * CUBIC_BETA), minimum_window(c->base.mss));
    c->base.cwnd = c->base.ssthres;
    c->k = cubic_k(c->w_max, c->base.mss);
    c->cwnd_inc = (uint64_t)((double)c->cwnd_inc * CUBIC_BETA);
}

static inline void cubic_init(cubic_t *cubic, const uint64_t mss) {
    memset(cubic, 0, sizeof(cubic_t));
    cubic->base.mss = mss;
    cubic->base.cwnd = initial_window(mss);
    cubic->base.ssthres = UINT64_MAX;
    cubic->w_max = (double)cubic->base.cwnd;
    cubic->base.on_ack = cubic_on_ack;
    cubic->base.on_congestion = cubic_on_congestion;
}

typedef struct {
    uint64_t capacity;
    uint64_t tokens;
    uint64_t mss;
    uint64_t window;
    struct timespec prev;
} pacer_t;

static inline uint64_t optimal_capacity(const int64_t rtt_ns, const uint64_t mss, const uint64_t window) {
    const int64_t rtt = MAX(rtt_ns, 1);
    const uint64_t capacity = (window * BURST_INTERVAL_NS) / (uint64_t)rtt;
    return CLAMP(capacity, MIN_BURST_SIZE * mss, MAX_BURST_SIZE * mss);
}

static inline void pacer_init(pacer_t *p, const struct timespec *now) {
    memset(p, 0, sizeof(pacer_t));
    p->prev = *now;
}

static inline bool pacer_time_until_send(pacer_t *p, const struct timespec *now, struct timespec *out, const int64_t rtt_ns, const uint64_t bytes, const uint64_t mss, const uint64_t window) {
    if (mss != p->mss || window != p->window) {
        p->capacity = optimal_capacity(rtt_ns, mss, window);
        p->tokens = MIN(p->tokens, p->capacity);
        p->mss = mss;
        p->window = window;
    }
    if (p->tokens >= bytes || window >= UINT32_MAX)
        return false;
    const int64_t elapsed_ns = timespec_diff_ns(now, &p->prev);
    const double elapsed_rtt = (double)elapsed_ns / (double)rtt_ns;
    const double new_tokens = (double)window * 1.25 * elapsed_rtt;
    p->tokens = MIN(p->tokens + (uint64_t)new_tokens, p->capacity);
    p->prev = *now;
    if (p->tokens >= bytes)
        return false;
    const int64_t unscaled_delay = rtt_ns * (MIN(bytes, p->capacity) - p->tokens) / window;
    const int64_t delay = unscaled_delay / 5 * 4;
    out->tv_sec = now->tv_sec;
    out->tv_nsec = now->tv_nsec + delay;
    if (out->tv_nsec >= 1000000000) {
        out->tv_sec += out->tv_nsec / 1000000000;
        out->tv_nsec %= 1000000000;
    }
    return true;
}

static inline void pacer_on_send(pacer_t *p, const uint64_t bytes) {
    if (p->tokens > bytes) {
        p->tokens -= bytes;
    } else {
        p->tokens = 0;
    }
}

typedef struct {
    uint64_t flight;
    bool recovery_send;
    struct timespec recovery_start;
    congestion_controller_t *cc;
    pacer_t pacer;
} sender_t;

static inline void sender_init(sender_t *s, const struct timespec *now, uint64_t mss, congestion_controller_t *cc) {
    memset(s, 0, sizeof(sender_t));
    s->recovery_start = *now;
    s->cc = cc;
    pacer_init(&s->pacer, now);
}

static inline bool sender_time_until_send(sender_t *s, const struct timespec *now, struct timespec *out, const rtt_t *rtt, const uint64_t bytes) {
    return pacer_time_until_send(&s->pacer, now, out, rtt->smoothed_rtt_ns, bytes, s->cc->mss, s->cc->cwnd);
}

static inline void sender_on_send(sender_t *s, uint64_t bytes) {
    s->flight += bytes;
    pacer_on_send(&s->pacer, bytes);
    if (s->recovery_send)
        s->recovery_send = false;
}

static inline void sender_on_ack(sender_t *s, struct timespec *now, struct timespec *sent, rtt_t *rtt, uint64_t bytes) {
    if (s->flight > bytes) {
        s->flight -= bytes;
    } else {
        s->flight = 0;
    }
    s->cc->on_ack(s->cc, now, sent, &s->recovery_start, rtt, bytes, s->flight);
}

static inline void sender_on_congestion(sender_t *s, struct timespec *now, struct timespec *sent) {
    if (timespec_diff_ns(sent, &s->recovery_start) > 0) {
        s->recovery_send = true;
        s->recovery_start = *now;
        s->cc->on_congestion(s->cc, now, sent);
    }
}

static inline uint64_t sender_available(const sender_t *s) {
    if (s->recovery_send)
        return s->cc->mss;
    if (s->cc->cwnd > s->flight)
        return s->cc->cwnd - s->flight;
    return 0;
}

#endif //ASTRIA_PORTA_CONGESTION_H
