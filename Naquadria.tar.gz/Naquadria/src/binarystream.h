//
// Created by kani on 21/10/2024 AD.
//

#ifndef BINARYSTREAM_H
#define BINARYSTREAM_H

#include <string.h>
#include <stdint.h>

#define BUFFER_TO_BINARY_STREAM(buff, len) (binary_stream_t) { .buffer = buff, .size = len }

typedef struct {
	uint8_t *buffer;
	size_t size;
} binary_stream_t;

#define FORCE_INLINE inline __attribute__((__always_inline__))

typedef enum io_endianness {
	io_little_endian = 0,
	io_big_endian = 1
} io_endianness_t;

static FORCE_INLINE uint16_t io_switch_int16(const uint16_t num) {
	return ((num & 0xff00) >> 8) | (num << 8);
}

static FORCE_INLINE uint32_t io_switch_int32(const uint32_t num) {
	return ((num & 0xff000000) >> 24) | ((num & 0x00ff0000) >> 8) | ((num & 0x0000ff00) << 8) | (num << 24);
}

static FORCE_INLINE uint64_t io_switch_int64(const uint64_t num) {
	return
		((num & 0xff00000000000000L) >> 56) |
		((num & 0x00ff000000000000L) >> 40) |
		((num & 0x0000ff0000000000L) >> 24) |
		((num & 0x000000ff00000000L) >>  8) |
		((num & 0x00000000ff000000L) <<  8) |
		((num & 0x0000000000ff0000L) << 24) |
		((num & 0x000000000000ff00L) << 40) |
		(num << 56);
}

static FORCE_INLINE int8_t io_read_int8(const uint8_t* buffer) {
	return *buffer;
}

static FORCE_INLINE int16_t io_read_int16(const uint8_t* buffer, const io_endianness_t endianness) {
	if (__ENDIANNESS__ == endianness) {
		return *((int16_t*) buffer);
	} else {
		return io_switch_int16(*((int16_t*) buffer));
	}
}

static FORCE_INLINE int32_t io_read_int24(const uint8_t* buffer) {
	return (buffer[0] & 0xff) | (buffer[1] & 0xff) << 8 | (buffer[2] & 0xff) << 16;
}

static FORCE_INLINE int32_t io_read_int32(const uint8_t* buffer, const io_endianness_t endianness) {
	if (__ENDIANNESS__ == endianness) {
		return *((int32_t*) buffer);
	} else {
		return io_switch_int32(*((int32_t*) buffer));
	}
}

static FORCE_INLINE int64_t io_read_int64(const uint8_t* buffer, const io_endianness_t endianness) {
	if (__ENDIANNESS__ == endianness) {
		return *((int64_t*) buffer);
	} else {
		return io_switch_int64(*((int64_t*) buffer));
	}
}

static FORCE_INLINE float io_read_float32(const uint8_t* buffer, const io_endianness_t endianness) {
	if (__ENDIANNESS__ == endianness) {
		float out;
		memcpy(&out, buffer, sizeof(float));
		return out;
	} else {
		uint32_t bytes = io_switch_int32(*((uint32_t*) buffer));
		float out;
		memcpy(&out, &bytes, sizeof(out));
		return out;
	}
}

static FORCE_INLINE double io_read_double64(const uint8_t* buffer, const io_endianness_t endianness) {
	if (__ENDIANNESS__ == endianness) {
		double out;
		memcpy(&out, buffer, sizeof(double));
		return out;
	} else {
		uint64_t bytes = io_switch_int64(*((uint64_t*) buffer));
		double out;
		memcpy(&out, &bytes, sizeof(out));
		return out;
	}
}

static FORCE_INLINE uint32_t io_read_var_int(const uint8_t* buffer, size_t max_length, size_t* length) {
	uint32_t result = 0;
	int8_t read = 0x80;
	if (max_length > 5) max_length = 5;
	for (*length = 0; *length < max_length && (read & 0x80); ++*length) {
		read = io_read_int8(buffer + *length);
		result |= ((read & 0x7F) << (7 * *length));
	}
	return result;
}

static FORCE_INLINE uint64_t io_read_var_long(const uint8_t* buffer, size_t max_length, size_t* length) {
	uint64_t result = 0;
	int8_t read = 0x80;
	if (max_length > 10) max_length = 10;
	for (*length = 0; *length < max_length && (read & 0x80); ++*length) {
		read = io_read_int8(buffer + *length);
		result |= ((uint64_t) (read & 0x7F) << (7 * *length));
	}
	return result;
}

static FORCE_INLINE void io_write_int8(uint8_t* buffer, const int8_t value) {
	buffer[0] = value;
}

static FORCE_INLINE void io_write_int16(uint8_t* buffer, const int16_t value, const io_endianness_t endianness) {
	if (__ENDIANNESS__ == endianness) {
		*((int16_t*) buffer) = value;
	} else {
		*((int16_t*) buffer) = io_switch_int16(value);
	}
}

static FORCE_INLINE void io_write_int24(uint8_t* buffer, const int32_t value) {
	buffer[0] = value & 0xff;
	buffer[1] = (value >> 8) & 0xff;
	buffer[2] = (value >> 16) & 0xff;
}

static FORCE_INLINE void io_write_int32(uint8_t* buffer, const int32_t value, const io_endianness_t endianness) {
	if (__ENDIANNESS__ == endianness) {
		*((int32_t*) buffer) = value;
	} else {
		*((int32_t*) buffer) = io_switch_int32(value);
	}
}

static FORCE_INLINE void io_write_int64(uint8_t* buffer, const int64_t value, const io_endianness_t endianness) {
	if (__ENDIANNESS__ == endianness) {
		*((int64_t*) buffer) = value;
	} else {
		*((int64_t*) buffer) = io_switch_int64(value);
	}
}

static FORCE_INLINE void io_write_float32(uint8_t* buffer, const float value, const io_endianness_t endianness) {
	if (__ENDIANNESS__ == endianness) {
		memcpy(buffer, &value, sizeof(value));
	} else {
		uint32_t bytes;
		memcpy(&bytes, &value, sizeof(bytes));
		bytes = io_switch_int32(bytes);
		memcpy(buffer, &bytes, sizeof(bytes));
	}
}

static FORCE_INLINE void io_write_double64(uint8_t* buffer, const double value, const io_endianness_t endianness) {
	if (__ENDIANNESS__ == endianness) {
		memcpy(buffer, &value, sizeof(value));
	} else {
		uint64_t bytes;
		memcpy(&bytes, &value, sizeof(bytes));
		bytes = io_switch_int64(bytes);
		memcpy(buffer, &bytes, sizeof(bytes));
	}
}

static FORCE_INLINE size_t io_var_int_length(uint32_t value) {
	size_t len = 0;
	do {
		len++;
		value >>= 7;
	} while (value != 0);
	return len;
}

static FORCE_INLINE size_t io_var_long_length(uint64_t value) {
	size_t len = 0;
	do {
		len++;
		value >>= 7;
	} while (value != 0);
	return len;
}

static FORCE_INLINE size_t io_write_var_int(uint8_t* buffer, uint32_t value, const size_t max_length) {
	size_t i = 0;
	do {
		int8_t temp = (int8_t) (value & 0x7F);
		value >>= 7;
		if (value != 0) {
			temp |= 0x80;
		}
		if (i >= max_length) return 0;
		io_write_int8(buffer + i++, temp);
	} while (value != 0);
	return i;
}

static FORCE_INLINE void io_write_long_var_int(uint8_t* buffer, uint32_t value) {
	size_t i = 0;
	do {
		int8_t temp = (int8_t) (value & 0x7F);
		value >>= 7;
		if (i < 4) temp |= 0x80;
		io_write_int8(buffer + i++, temp);
	} while (i < 5);
}

static FORCE_INLINE size_t io_write_var_long(uint8_t* buffer, uint64_t value, const size_t max_length) {
	size_t i = 0;
	do {
		int8_t temp = (int8_t) (value & 0x7F);
		value >>= 7;
		if (value != 0) temp |= 0x80;
		if (i >= max_length) return 0;
		io_write_int8(buffer + i++, temp);
	} while (value != 0);
	return i;
}

#endif //BINARYSTREAM_H
