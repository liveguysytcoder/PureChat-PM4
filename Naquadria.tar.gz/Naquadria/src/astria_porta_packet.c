//
// Created by zeen on 9/20/25.
//
#include "astria_porta_packet.h"

//correlative update protocol
//(check compat with key, MTU discovery)

//(split game packets, NACKs ACKs)
//0x01|type(1)|size(2)|buff|
//0x02|id(4)|size(4)|flag(1)>0b111<|split_id(4)|client_id(8)|buff|

//(control protocol (server lists,server transfer, get player list, control player, telemetry))
//0x03|id(4)|pk_id(2)|
    //0x00                                          server list
    //0x01|client_id(8)|type(1)|                    server transfer
        //0x01|server_id(8)|
        //0x02|ipv4(6)|
    //0x02|server_id(8)|                            player lists
    //0x03|server_id(8)|client_id(8)|               
    //0x04|client_id(8)|type(2)|extra(2)|buff
    //0x05|server_id(8)|players(2)|
//0x04|id(4)|pk_id(2)|
    //0x00|servers(2)|buff|
    //0x01|status(1)|
    //0x02|players(2)|buff|
