//
// Created by zeen on 9/15/25.
//

#ifndef BEDROCK_NET_SERIALIZER_H
#define BEDROCK_NET_SERIALIZER_H

#include <assert.h>
#include <stdlib.h>
#include <uuid/uuid.h>
#include "binarystream.h"

#define PACKET_PID_MASK 0x3ff //10 bits
#define PACKET_SUB_CLIENT_ID_MASK 0x03 //2 bits
#define PACKET_SENDER_SUB_CLIENT_ID_SHIFT 10
#define PACKET_RECIPIENT_SUB_CLIENT_ID_SHIFT 12

typedef struct {
    binary_stream_t     stream;
    size_t              cursor;
} pck_packet_t;

// #define PCK_INLINE(name, len) uint8_t name ##_r[sizeof(pck_packet_t) + len]; pck_packet_t* name = (pck_packet_t*) name ##_r; name->cursor = 0; name->stream.size = len;

#define PCK_REALLOC(packet, len) packet->stream.buffer = reallocarray(packet->stream.buffer, packet->stream.size + len, sizeof(char)); packet->stream.size += len;

#define PCK_READ_STRING(name, packet) int32_t name ##_length = pck_read_var_int(packet); char name [name ##_length + 1]; pck_read_bytes(packet, (uint8_t*) name, name ##_length); if (name ##_length + 1 != 0) { name [name ##_length] = '\0'; }
#define PCK_ALLOC_STRING(name, packet) int32_t name ##_length = pck_read_var_int(packet); char* name = malloc(name ##_length + 1); pck_read_bytes(packet, (uint8_t*) name, name ##_length); name[name ##_length] = '\0';

extern pck_packet_t* pck_create(size_t);
extern pck_packet_t* pck_from_bytes(const uint8_t*, size_t);

extern void pck_init_from_bytes(pck_packet_t*, const uint8_t*, size_t);

static inline size_t pck_left_over(const pck_packet_t* packet){
	return packet->stream.size - packet->cursor;
}

static inline void pck_cursor_skip(pck_packet_t* packet, const size_t size){
	assert(packet->stream.size - packet->cursor >= size);
	packet->cursor += size;
}

static inline int8_t pck_read_int8(pck_packet_t* packet) {
	assert(packet->stream.size - packet->cursor >= 1);
	packet->cursor += 1;
	return io_read_int8(packet->stream.buffer + packet->cursor - 1);
}

static inline int16_t pck_read_int16(pck_packet_t* packet) {
	assert(packet->stream.size - packet->cursor >= 2);
	packet->cursor += 2;
	return io_read_int16(packet->stream.buffer + packet->cursor - 2, io_little_endian);
}

static inline int32_t pck_read_int32(pck_packet_t* packet) {
	assert(packet->stream.size - packet->cursor >= 4);
	packet->cursor += 4;
	return io_read_int32(packet->stream.buffer + packet->cursor - 4, io_little_endian);
}

static inline int64_t pck_read_int64(pck_packet_t* packet) {
	assert(packet->stream.size - packet->cursor >= 8);
	packet->cursor += 8;
	return io_read_int64(packet->stream.buffer + packet->cursor - 8, io_little_endian);
}

static inline float pck_read_float32(pck_packet_t* packet) {
	assert(packet->stream.size - packet->cursor >= 4);
	packet->cursor += 4;
	return io_read_float32(packet->stream.buffer + packet->cursor - 4, io_little_endian);
}

static inline double pck_read_float64(pck_packet_t* packet) {
	assert(packet->stream.size - packet->cursor >= 8);
	packet->cursor += 8;
	return io_read_double64(packet->stream.buffer + packet->cursor - 8, io_little_endian);
}

static inline uint32_t pck_read_var_int(pck_packet_t* packet) {
	size_t size = 0;
	const uint32_t value = io_read_var_int(packet->stream.buffer + packet->cursor, packet->stream.size - packet->cursor, &size);
	packet->cursor += size;
	return value;
}

static inline int32_t pck_read_var_int_signed(pck_packet_t* packet) {
	size_t size = 0;
	const uint32_t value = io_read_var_int(packet->stream.buffer + packet->cursor, packet->stream.size - packet->cursor, &size);
	packet->cursor += size;
	return (int32_t) (value >> 1) ^ (-1 * (value & 1));
}

static inline uint64_t pck_read_var_long(pck_packet_t* packet) {
	size_t size = 0;
	const uint64_t value = io_read_var_long(packet->stream.buffer + packet->cursor, packet->stream.size - packet->cursor, &size);
	packet->cursor += size;
	return value;
}

static inline int64_t pck_read_var_long_signed(pck_packet_t* packet) {
	size_t size = 0;
	const uint64_t value = io_read_var_long(packet->stream.buffer + packet->cursor, packet->stream.size - packet->cursor, &size);
	packet->cursor += size;
	return (int64_t) (value >> 1) ^ (-1 * (value & 1));
}

static inline void pck_read_bytes(pck_packet_t* packet, uint8_t* bytes, const int32_t length) {
	assert(packet->stream.size - packet->cursor >= (unsigned) length);
	memcpy(bytes, packet->stream.buffer + packet->cursor, length);
	packet->cursor += length;
}

static inline void pck_write_int8(pck_packet_t* packet, const int8_t value) {
	assert(packet->stream.size - packet->cursor >= 1);
	io_write_int8(packet->stream.buffer + packet->cursor, value);
	packet->cursor += 1;
}

static inline void pck_write_int16(pck_packet_t* packet, const int16_t value) {
	assert(packet->stream.size - packet->cursor >= 2);
	io_write_int16(packet->stream.buffer + packet->cursor, value, io_little_endian);
	packet->cursor += 2;
}

static inline void pck_write_int32(pck_packet_t* packet, const int32_t value) {
	assert(packet->stream.size - packet->cursor >= 4);
	io_write_int32(packet->stream.buffer + packet->cursor, value, io_little_endian);
	packet->cursor += 4;
}

static inline void pck_write_int64(pck_packet_t* packet, const int64_t value) {
	assert(packet->stream.size - packet->cursor >= 8);
	io_write_int64(packet->stream.buffer + packet->cursor, value, io_little_endian);
	packet->cursor += 8;
}

static inline void pck_write_float32(pck_packet_t* packet, const float value) {
	assert(packet->stream.size - packet->cursor >= 4);
	io_write_float32(packet->stream.buffer + packet->cursor, value, io_little_endian);
	packet->cursor += 4;
}

static inline void pck_write_float64(pck_packet_t* packet, const double value) {
	assert(packet->stream.size - packet->cursor >= 8);
	io_write_double64(packet->stream.buffer + packet->cursor, value, io_little_endian);
	packet->cursor += 8;
}

static inline void pck_write_var_int(pck_packet_t* packet, const uint32_t value) {
	packet->cursor += io_write_var_int(packet->stream.buffer + packet->cursor, value, packet->stream.size - packet->cursor);
}

static inline void pck_write_var_int_signed(pck_packet_t* packet, const int32_t value) {
	packet->cursor += io_write_var_int(packet->stream.buffer + packet->cursor, ((uint32_t)value << 1) ^ (value < 0 ? ~0 : 0), packet->stream.size - packet->cursor);
}

static inline void pck_write_var_long(pck_packet_t* packet, const uint64_t value) {
	packet->cursor += io_write_var_long(packet->stream.buffer + packet->cursor, value, packet->stream.size - packet->cursor);
}

static inline void pck_write_var_long_signed(pck_packet_t* packet, const int64_t value) {
	packet->cursor += io_write_var_long(packet->stream.buffer + packet->cursor, ((uint64_t)value << 1) ^ (value < 0 ? ~0 : 0), packet->stream.size - packet->cursor);
}

static inline void pck_write_bytes(pck_packet_t* packet, const uint8_t* bytes, const int32_t length) {
	memcpy(packet->stream.buffer + packet->cursor, bytes, length);
	packet->cursor += length;
}

static inline void pck_write_string(pck_packet_t* packet, const uint8_t* string, const size_t length) {
	pck_write_var_int(packet, length);
	pck_write_bytes(packet, string, length);
}

static inline uint8_t* pck_cursor(const pck_packet_t* packet) {
	return packet->stream.buffer + packet->cursor;
}

typedef struct {
	binary_stream_t experiment_name;
	bool enabled;
} experiment_entry_t;


typedef struct {
	uuid_t uuid;
	binary_stream_t version;
	uint64_t size;
	binary_stream_t encryption_key;
	binary_stream_t sub_pack_name;
	binary_stream_t content_id;
	bool has_scripts;
	bool is_addon_pack;
	bool is_rtx_capable;
	binary_stream_t cdn_url;
} resource_pack_info_entry_t;

typedef struct {
	binary_stream_t pack_id;
	binary_stream_t version;
	binary_stream_t sub_pack_name;
} resource_pack_stack_entry_t;

typedef struct {
    int32_t id;
    int16_t count;
    uint32_t meta;
} item_stack_header_t;

typedef struct {
    item_stack_header_t item_stack_header;
    int32_t block_runtime_id;
    uint8_t *raw_extra_data;
    uint32_t raw_extra_data_size;
} item_stack_t;

typedef struct {
    int32_t stack_id;
    item_stack_t item_stack;
} item_stack_wrapper_t;

typedef struct {
	int32_t width;
	int32_t height;
	uint32_t data_size;
	uint8_t *data;
} skin_image_t;

typedef struct {
	skin_image_t image;
	int32_t type;
	float frames;
	int32_t expression_type;
} skin_animation_t;

typedef struct {
	uint32_t piece_id_size;
	uint8_t *piece_id;
	uint32_t piece_type_size;
	uint8_t *piece_type;
	uint32_t pack_id_size;
	uint8_t *pack_id;
	uint8_t is_piece_default;
	uint32_t product_id_size;
	uint8_t *product_id;
} skin_persona_t;

typedef struct {
	uint32_t piece_type_size;
	uint8_t *piece_type;
	uint32_t color_count;
	// int32_t *colors_size;
	// uint8_t **colors;
} skin_persona_tint_color_t;

typedef struct {
	uint32_t skin_id_size;
	uint8_t *skin_id;
	uint32_t play_fab_id_size;
	uint8_t *play_fab_id;
	uint32_t resources_patch_size;
	uint8_t *resources_patch;
	skin_image_t skin_image;
	int32_t animation_count;
	skin_animation_t *animations;
	skin_image_t cape_image;
	uint32_t geometry_data_size;
	uint8_t *geometry_data;
	uint32_t geometry_engine_version_size;
	uint8_t *geometry_engine_version;
	uint32_t animation_data_size;
	uint8_t *animation_data;
	uint32_t cape_id_size;
	uint8_t *cape_id;
	uint32_t full_skin_id_size;
	uint8_t *full_skin_id;
	uint32_t arm_size_size;
	uint8_t *arm_size;
	uint32_t skin_color_size;
	uint8_t *skin_color;
	int32_t persona_count;
	skin_persona_t *personas;
	int32_t persona_tint_color_count;
	skin_persona_tint_color_t *persona_tint_colors;
	bool is_premium;
	bool is_persona;
	bool is_persona_cape_classic;
	bool is_primary_user;
	bool is_override;
} skin_data_t;

void net_write_experiment_entry(pck_packet_t* packet, experiment_entry_t entry);
////////////////////////////////////////////////////////////////////////////////////
/// RESOURCE PACK DATA READ AND WRITE
////////////////////////////////////////////////////////////////////////////////////
void net_write_resource_pack_info_entry(pck_packet_t* packet, resource_pack_info_entry_t entry);
void net_write_resource_pack_stack_entry(pck_packet_t* packet, resource_pack_stack_entry_t entry);
////////////////////////////////////////////////////////////////////////////////////
/// BASIC PROTOCOL READ AND WRITE
////////////////////////////////////////////////////////////////////////////////////
void net_read_var_int_bytes(pck_packet_t* packet, uint32_t *size, uint8_t** data);
void net_read_uuid(pck_packet_t* packet, const uuid_t uuid);
void net_write_uuid(pck_packet_t* packet, const uuid_t uuid);
////////////////////////////////////////////////////////////////////////////////////
/// ITEM DATA READ AND WRITE
////////////////////////////////////////////////////////////////////////////////////
item_stack_header_t net_read_item_stack_header(pck_packet_t* packet);
void net_write_item_stack_header(pck_packet_t* packet, item_stack_header_t item_stack_header);
item_stack_wrapper_t net_read_item_stack_wrapper(pck_packet_t* packet);
void net_write_item_stack_wrapper(pck_packet_t* packet, item_stack_wrapper_t item_stack_wrapper);
////////////////////////////////////////////////////////////////////////////////////
/// SKIN DATA READ AND WRITE
////////////////////////////////////////////////////////////////////////////////////
skin_image_t net_read_skin_image(pck_packet_t* packet);
void net_write_skin_image(pck_packet_t* packet, skin_image_t skin_image);
skin_animation_t net_read_skin_animation(pck_packet_t* packet);
void net_write_skin_animation(pck_packet_t* packet, skin_animation_t skin_animation);
skin_persona_t net_read_skin_persona(pck_packet_t* packet);
void net_write_skin_persona(pck_packet_t* packet, skin_persona_t skin_persona);
skin_persona_tint_color_t net_read_skin_persona_tint_color(pck_packet_t* packet);
void net_write_skin_persona_tint_color(pck_packet_t* packet, skin_persona_tint_color_t skin_persona_tint_color);
skin_data_t net_read_skin_data(pck_packet_t* packet, bool skip);
void net_write_skin_data(pck_packet_t* packet, skin_data_t skin_data);

#endif //BEDROCK_NET_SERIALIZER_H
