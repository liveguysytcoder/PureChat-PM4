//
// Created by zeen on 9/7/25.
//

#ifndef RAKNET_PACKET_HANDLER_H
#define RAKNET_PACKET_HANDLER_H

#define _GNU_SOURCE

#include <netinet/in.h>
#include <sys/socket.h>
#include <time.h>
#include <uv.h>
#include <liburing.h>

#include "raknet_rtt.h"
#include "raknet_packet.h"
#include "raknet_server.h"
#include "raknet_types.h"

#define FORCE_INLINE inline __attribute__((__always_inline__))

#define FH_SEED (0x2d31e867)
#define L3_SEED (0x6ad611c3)

#define MIN_MTU_SIZE 400
#define MAX_MTU_SIZE 1472

#define MINECRAFT_BEDROCK_BATCH_PACKET 0xFE

static inline int64_t get_current_time_ms() {
    struct timespec time;
    clock_gettime(CLOCK_REALTIME, &time);
    return time.tv_sec * 1000 + time.tv_nsec / 0xF4240;
}

struct pending_messages {
    struct mmsghdr *messages;
    size_t count;
};

bool has_raknet_context_connection(const non_connected_t* non_connected, const server_context_t *server);
void add_raknet_connection(const non_connected_t* non_connected, int16_t mtu_size, server_context_t *server);
client_context_t *get_raknet_connection(const non_connected_t* non_connected, const server_context_t *server);
void raknet_cleanup_client_resources(client_context_t *client);
void remove_raknet_connection(const client_context_t* client_context, server_context_t *server);
bool is_in_ack_queue(const client_context_t *client_context, uint32_t sequence_number);
bool is_in_nack_queue(const client_context_t *client_context, uint32_t sequence_number);
void deduct_raknet_nack_queue(client_context_t *client_context, uint32_t sequence_number);
bool is_in_raknet_segmented_datagram_queue(const client_context_t *client_context, uint16_t segmented_id, uint32_t segmented_index);
void append_raknet_segmented_datagram_queue(client_context_t *client_context, rak_message_t segmented_datagram);
uint32_t get_raknet_segmented_size(const client_context_t *client_context, uint16_t segmented_id);
rak_message_t pop_raknet_segmented_datagram_entry(client_context_t *client_context, uint16_t segmented_id, uint32_t segmented_index);
void append_raknet_encoded_datagram_resend_packets_queue(const client_context_t *client_context, packet_datagrams_t packet_datagrams);
void deduct_raknet_encoded_datagram_resend_packets_queue(const client_context_t *client_context, uint32_t sequence_number);
void add_to_raw_packets_queues(non_connected_t *non_connected, binary_stream_t packet);
struct pending_messages extract_raw_packets_for_send(non_connected_t *non_connected);

void send_raw_packets_queues(non_connected_t *non_connected, server_context_t *server_context);
void send_encoded_datagram_queue(client_context_t *context);
void check_client_retransmission_timeouts(client_context_t *context);
void append_encoded_datagram_queue(client_context_t *context, rak_message_t message, bool is_split);
void add_to_sent_queue(client_context_t *context, queue_packet_t packet);
bool raknet_flush_acks_nacks(client_context_t *client_context);

bool raknet_process_packet(const uint8_t *buffer, size_t length, non_connected_t *non_connected, server_context_t *server_context);

bool handle_unconnected_ping(const uint8_t *buffer, size_t length, non_connected_t *non_connected, const server_context_t *server_context);
bool handle_open_connection_request_1(const uint8_t *buffer, size_t length, non_connected_t *non_connected, server_context_t *server_context);
bool handle_open_connection_request_2(const uint8_t *buffer, size_t length, non_connected_t *non_connected, server_context_t *server_context);
bool handle_connection_request(const uint8_t *buffer, size_t length, client_context_t *context);
bool handle_new_incoming_connection(const uint8_t *buffer, size_t length, client_context_t *context, const server_context_t *server_context);
bool handle_online_ping(const uint8_t *buffer, size_t length, client_context_t *context);
bool handle_ack_packet(const uint8_t *buffer, size_t length, client_context_t *context);
bool handle_nack_packet(const uint8_t *buffer, size_t length, client_context_t *context);
bool process_datagram_packet(rak_message_t message, client_context_t *client_context, const server_context_t *server_context);
bool handle_datagram_packet(const uint8_t *buffer, size_t length, client_context_t *context, server_context_t *server_context);

#endif //RAKNET_PACKET_HANDLER_H
