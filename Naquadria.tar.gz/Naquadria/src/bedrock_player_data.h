//
// Created by zeen on 10/9/25.
//

#ifndef BEDROCK_PLAYER_DATA_H
#define BEDROCK_PLAYER_DATA_H

#include <pthread.h>
#include <stdint.h>
#include <stddef.h>
#include "compression.h"
#include "encryption.h"
#include "raknet_server.h"

typedef struct client_context client_context_t;
typedef struct astria_porta_server astria_porta_server_t;

typedef enum game_state {
    GAME_NO_COMPRESSION,
    GAME_COMPRESSION,
    GAME_ENCRYPTION,
    GAME_START_GAME,
    GAME_SPAWNED,
    GAME_INGAME,
    GAME_TRANSFER,
    GAME_DISCONNECTED
} bedrock_player_play_state_t;

typedef struct bedrock_player_data {
    client_context_t            *client_context;
    bedrock_player_play_state_t game_state;
    astria_porta_server_t       *server;
    pthread_t                   thread;
    size_t                      packets_queue_size;
    binary_stream_t             *packets_queue;
    pthread_mutex_t             batch_packets_queue_client_lock;
    size_t                      batch_packets_queue_c2p_size;
    binary_stream_t             *batch_packets_queue_c2p;
    size_t                      batch_packets_queue_p2c_size;
    binary_stream_t             *batch_packets_queue_p2c;
    pthread_mutex_t             batch_packets_queue_server_lock;
    size_t                      batch_packets_queue_s2p_size;
    binary_stream_t             *batch_packets_queue_s2p;
    size_t                      batch_packets_queue_p2s_size;
    binary_stream_t             *batch_packets_queue_p2s;
    int32_t                     protocol_version;
    char*                       raw_xbox_name;
    char*                       player_xbox_user_id;
    uint64_t                    runtime_id;
    int64_t                     unique_id;
    compression_type_t          compression_type;
    player_cipher_block_t       *encrypted_block;
} bedrock_player_data_t;

void create_bedrock_player(const server_context_t *server_context, bedrock_player_data_t *player, client_context_t *context);
void cleanup_bedrock_player(const server_context_t *server_context, bedrock_player_data_t *player);
bool is_have_bedrock_player(const server_context_t *server_context, const non_connected_t *context);

void push_batch_packets_queue_c2p(bedrock_player_data_t *player, binary_stream_t stream);
binary_stream_t get_batch_packets_queue_c2p(bedrock_player_data_t *player);
void push_batch_packets_queue_p2c(bedrock_player_data_t *player, binary_stream_t stream);
binary_stream_t get_batch_packets_queue_p2c(bedrock_player_data_t *player);
void push_batch_packets_queue_s2p(bedrock_player_data_t *player, binary_stream_t stream);
binary_stream_t get_batch_packets_queue_s2p(bedrock_player_data_t *player);
void push_batch_packets_queue_p2s(bedrock_player_data_t *player, binary_stream_t stream);
binary_stream_t get_batch_packets_queue_p2s(bedrock_player_data_t *player);

#endif //BEDROCK_PLAYER_DATA_H