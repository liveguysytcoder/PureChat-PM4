//
// Created by zeen on 11/15/25.
//
#include "resource_manager.h"

#include <stdio.h>
#include <cjson/cJSON.h>
#include <sys/stat.h>

pck_packet_t* read_file(const char *path) {
    FILE *file = fopen(path, "rb");
    fseek(file, 0, SEEK_END);
    struct stat f_info;
    fstat(fileno(file), &f_info);
    pck_packet_t* stream = pck_create(f_info.st_size);
    fseek(file, 0, SEEK_SET);
    fread(stream->stream.buffer, 1, f_info.st_size, file);
    fclose(file);
    return stream;
}

void read_allay_block_state(const pck_packet_t* buffer) {
    cJSON* json = cJSON_ParseWithLength((char *) buffer->stream.buffer, buffer->stream.size);
    
    free(buffer->stream.buffer);
}

void read_allay_block_palette(const pck_packet_t* buffer) {

}