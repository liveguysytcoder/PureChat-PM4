//
// Created by zeen on 9/6/25.
//

#include "raknet_server.h"

#include "bedrock_player_data.h"
#include "raknet_packet_handler.h"
#include <liburing.h>
#include <unistd.h>
#include <errno.h>
#include "base64.h"
#include <netinet/ip.h>
#include <fcntl.h>

static int server_sock_file_desc = -1;
static struct io_uring ring;

#define MAX_BUFFER_SIZE 1600
#define ENTRIES 256

server_context_t* server_context = nullptr;

typedef struct {
    struct msghdr msg;
    struct iovec iov;
    struct sockaddr_in addr;
    uint8_t buffer[MAX_MTU_SIZE];
} io_recv_ctx_t;

static io_recv_ctx_t global_recv_ctx;

void submit_recv(void) {
    struct io_uring_sqe *sqe = io_uring_get_sqe(&ring);
    global_recv_ctx.iov.iov_base = global_recv_ctx.buffer;
    global_recv_ctx.iov.iov_len = MAX_MTU_SIZE;
    global_recv_ctx.msg.msg_name = &global_recv_ctx.addr;
    global_recv_ctx.msg.msg_namelen = sizeof(struct sockaddr_in);
    global_recv_ctx.msg.msg_iov = &global_recv_ctx.iov;
    global_recv_ctx.msg.msg_iovlen = 1;

    io_uring_prep_recvmsg(sqe, server_sock_file_desc, &global_recv_ctx.msg, 0);
    io_uring_sqe_set_data(sqe, &global_recv_ctx);
    io_uring_submit(&ring);
}

int raknet_server_init(const int port) {
    server_sock_file_desc = socket(AF_INET, SOCK_DGRAM, 0);
    if (server_sock_file_desc < 0) {
        perror("socket");
        return -1;
    }

    constexpr int rcv_size = 16 * 1024 * 1024;
    setsockopt(server_sock_file_desc, SOL_SOCKET, SO_RCVBUF, &rcv_size, sizeof(rcv_size));
    constexpr int send_size = 16 * 1024 * 1024;
    setsockopt(server_sock_file_desc, SOL_SOCKET, SO_SNDBUF, &send_size, sizeof(send_size));
    constexpr int reuse = 1;
    setsockopt(server_sock_file_desc, SOL_SOCKET, SO_REUSEADDR, &reuse, sizeof(reuse));

    struct sockaddr_in addr = {
        .sin_family = AF_INET,
        .sin_port = htons(port),
        .sin_addr.s_addr = INADDR_ANY
    };

    if (bind(server_sock_file_desc, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
        perror("bind");
        close(server_sock_file_desc);
        server_sock_file_desc = -1;
        return -1;
    }

    if (io_uring_queue_init(ENTRIES, &ring, 0) < 0) {
        perror("io_uring_init");
        close(server_sock_file_desc);
        return -1;
    }

    printf("[rak_server] Initialized with io_uring on port %d\n", port);
    server_context = (server_context_t*)malloc(sizeof(server_context_t));
    *server_context = (server_context_t){
        .motd = "MCPE;NotNativeGames;100;1.21.100;0;40;45475643462;Naquadria;Survival;1;19132;0;0;",
        .server_guid = SERVER_GUID,
        .clients = (client_context_t *) malloc(0),
        .clients_size = 0,
        .blocked_connections = (blocked_connection_t *) malloc(0),
        .blocked_connections_size = 0,
        .bedrock_players = (bedrock_player_data_t *) malloc(0),
        .bedrock_players_size = 0,
    };

    server_context->motd_size = (int16_t) strlen(server_context->motd),
    generate_server_keypair(&server_context->server_key);
    unsigned char *der_buffer = nullptr;
    int der_len = i2d_PrivateKey(server_context->server_key, &der_buffer);
    size_t out_length;
    char *key = b64_encode_with_alloc(der_buffer, der_len, &out_length);
    printf("server_key: ");
    for (size_t i = 0; i < out_length; i++) {
        printf("%c", key[i]);
    }
    printf("\n");
    free(key);
    return 0;
}

void raknet_server_shutdown(void) {
    if (server_context) {
        // ... (existing cleanup code)
        free(server_context);
        server_context = nullptr;
    }
    io_uring_queue_exit(&ring);
    if (server_sock_file_desc >= 0) {
        close(server_sock_file_desc);
        server_sock_file_desc = -1;
    }
    printf("[rak_server] Shutdown complete\n");
}

static void ipv4_hash(const struct sockaddr_in ip, uint64_t *hash) {
    *hash = fasthash64(&ip, sizeof(ip), FH_SEED);
    *hash ^= fasthash_mix(hashlittle(&ip, sizeof(ip), L3_SEED));
}

void *raknet_server_recv_thread(void *arg) {
    printf("[rak_server] thread started with io_uring\n");

    submit_recv();

    int64_t last_tick_time = get_current_time_ms();
    uint64_t tick_count = 0;

    while (1) {
        const int64_t current_time = get_current_time_ms();
        struct io_uring_cqe *cqe;
        struct __kernel_timespec ts = { .tv_sec = 0, .tv_nsec = 5000000 }; // 5ms

        int ret = io_uring_wait_cqe_timeout(&ring, &cqe, &ts);

        if (ret == 0) {
            io_recv_ctx_t *ctx = (io_recv_ctx_t *)io_uring_cqe_get_data(cqe);
            int bytes_read = cqe->res;

            if (bytes_read > 0) {
                uint64_t hash = 0;
                const struct sockaddr_in *client_addr = &ctx->addr;
                ipv4_hash(*client_addr, &hash);

                non_connected_t cli = {
                    .raw_packets_queues = (binary_stream_t *) malloc(0),
                    .raw_packets_queues_size = 0,
                    .address = *client_addr,
                    .hash = fasthash_mix(hash),
                };

                bool blocked = false;
                for (size_t ii = 0; ii < server_context->blocked_connections_size; ii++)
                    if (server_context->blocked_connections[ii].address == client_addr->sin_addr.s_addr) {
                        blocked = true; break;
                    }

                if (!blocked) {
                    if (!raknet_process_packet(ctx->buffer, bytes_read, &cli, server_context)) {
                        server_context->blocked_connections_size++;
                        server_context->blocked_connections = (blocked_connection_t*)reallocarray(
                            server_context->blocked_connections, server_context->blocked_connections_size, sizeof(blocked_connection_t));
                        server_context->blocked_connections[server_context->blocked_connections_size - 1] =
                            (blocked_connection_t){.address = client_addr->sin_addr.s_addr, .end_time = current_time + 10000};
                    }
                }
                send_raw_packets_queues(&cli, server_context);
                if (cli.raw_packets_queues) free(cli.raw_packets_queues);
            }
            io_uring_cqe_seen(&ring, cqe);
            submit_recv();
        }

        // --- Tick Processing ---
        size_t new_size = 0;
        for (size_t i = 0; i < server_context->blocked_connections_size; i++)
            if (server_context->blocked_connections[i].end_time > current_time)
                server_context->blocked_connections[new_size++] = server_context->blocked_connections[i];

        if (new_size < server_context->blocked_connections_size) {
            if (new_size > 0) server_context->blocked_connections = (blocked_connection_t*)reallocarray(server_context->blocked_connections, new_size, sizeof(blocked_connection_t));
            else { free(server_context->blocked_connections); server_context->blocked_connections = (blocked_connection_t*)malloc(0); }
            server_context->blocked_connections_size = new_size;
        }

        for (size_t i = 0; i < server_context->clients_size; i++) {
            client_context_t *client = &server_context->clients[i];
            if (client->basic_info.state == CONNECTION_STATE_DISCONNECTED) continue;

            const int64_t inactive_time = current_time - client->last_receive_time;
            int64_t timeout_threshold = 5000;
            if (client->retransmission) timeout_threshold += (resend_map_rtt_ms(client->retransmission) * 2);
            if (inactive_time > timeout_threshold) client->basic_info.state = CONNECTION_STATE_DISCONNECTED;

            if (client->basic_info.state == CONNECTION_STATE_CONNECTED) {
                const binary_stream_t stream = get_batch_packets_queue_p2c(client->player_data);
                if (stream.size > 0) add_to_sent_queue(client, (queue_packet_t){.raw_packet = stream, .reliability = RELIABILITY_RELIABLE_ORDERED});
            }

            send_encoded_datagram_queue(client);
            if (tick_count % 4 == 0) { check_client_retransmission_timeouts(client); raknet_flush_acks_nacks(client); }
            if (tick_count % 1000 == 0) {
                size_t res_len = 17; uint8_t *res = (uint8_t*)calloc(res_len, 1);
                raknet_write_online_ping(res, &res_len, current_time);
                add_to_sent_queue(client, (queue_packet_t){.raw_packet = BUFFER_TO_BINARY_STREAM(res, res_len), .reliability = RELIABILITY_UNRELIABLE});
            }
            send_raw_packets_queues(&client->basic_info, server_context);
        }

        if (server_context->messages_size > 0) {
            sendmmsg(server_sock_file_desc, server_context->messages, server_context->messages_size, 0);
            for (size_t i = 0; i < server_context->messages_size; i++) {
                free(server_context->messages[i].msg_hdr.msg_iov->iov_base);
                free(server_context->messages[i].msg_hdr.msg_iov);
                free(server_context->messages[i].msg_hdr.msg_name);
            }
            free(server_context->messages);
            server_context->messages = (struct mmsghdr*)malloc(0);
            server_context->messages_size = 0;
        }

        for (size_t i = 0; i < server_context->clients_size; i++) {
            if (server_context->clients[i].basic_info.state == CONNECTION_STATE_DISCONNECTED) {
                raknet_cleanup_client_resources(&server_context->clients[i]);
                remove_raknet_connection(&server_context->clients[i], server_context);
                i--;
            }
        }
        last_tick_time = get_current_time_ms();
        tick_count++;
    }
    return NULL;
}