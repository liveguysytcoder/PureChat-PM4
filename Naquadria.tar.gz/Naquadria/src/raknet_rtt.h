//
// Created by zeen on 10/6/25.
//

#ifndef RAKNET_RTT_H
#define RAKNET_RTT_H

#include <stdint.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "raknet_packet.h"

#define RTT_CALCULATION_WINDOW_NS (5000000000LL)
#define DEFAULT_RTT_MS 50

typedef struct {
    int64_t timestamp_ns;
    int64_t rtt_ns;
} rtt_delay_record_t;

typedef struct {
    packet_datagrams_t datagram;
    int64_t timestamp_ns;
} retransmission_record_t;

typedef struct {
    retransmission_record_t *unacknowledged;
    size_t unacknowledged_count;
    size_t unacknowledged_capacity;
    rtt_delay_record_t *delays;
    size_t delays_count;
    size_t delays_capacity;
} resend_map_t;

static inline int64_t get_time_ns(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (int64_t)ts.tv_sec * 1000000000LL + (int64_t)ts.tv_nsec;
}

static inline resend_map_t* resend_map_create(void) {
    resend_map_t *map = malloc(sizeof(resend_map_t));
    if (!map)
        return NULL;
    map->unacknowledged = NULL;
    map->unacknowledged_count = 0;
    map->unacknowledged_capacity = 0;
    map->delays = NULL;
    map->delays_count = 0;
    map->delays_capacity = 0;
    return map;
}

static inline void resend_map_free(resend_map_t *map) {
    if (!map)
        return;
    free(map->unacknowledged);
    free(map->delays);
    free(map);
}

static inline void resend_map_add(resend_map_t *map, uint32_t seq, const packet_datagrams_t datagram) {
    if (map->unacknowledged_count >= map->unacknowledged_capacity) {
        const size_t new_capacity = map->unacknowledged_capacity == 0 ? 16 : map->unacknowledged_capacity * 2;
        retransmission_record_t *new_records = reallocarray(map->unacknowledged, new_capacity, sizeof(retransmission_record_t));
        if (!new_records)
            return;
        map->unacknowledged = new_records;
        map->unacknowledged_capacity = new_capacity;
    }
    map->unacknowledged[map->unacknowledged_count++] = (retransmission_record_t){
        .datagram = datagram,
        .timestamp_ns = get_time_ns()
    };
}

static inline int32_t resend_map_find_index(const resend_map_t *map, const uint32_t seq) {
    for (size_t i = 0; i < map->unacknowledged_count; i++)
        if (map->unacknowledged[i].datagram.sequence_number == seq)
            return (int32_t) i;
    return -1;
}

static inline bool resend_map_remove(resend_map_t *map, const uint32_t seq, const int32_t multiplier, packet_datagrams_t *out_datagram) {
    const int32_t index = resend_map_find_index(map, seq);
    if (index < 0)
        return false;
    const retransmission_record_t record = map->unacknowledged[index];
    const int64_t now = get_time_ns();
    const int64_t rtt = (now - record.timestamp_ns) * multiplier;
    if (map->delays_count >= map->delays_capacity) {
        const size_t new_capacity = map->delays_capacity == 0 ? 64 : map->delays_capacity * 2;
        rtt_delay_record_t *new_delays = reallocarray(map->delays, new_capacity, sizeof(rtt_delay_record_t));
        if (new_delays) {
            map->delays = new_delays;
            map->delays_capacity = new_capacity;
        }
    }
    if (map->delays_count < map->delays_capacity)
        map->delays[map->delays_count++] = (rtt_delay_record_t){
            .timestamp_ns = now,
            .rtt_ns = rtt
        };
    if (out_datagram)
        *out_datagram = record.datagram;
    if (index < (int32_t) map->unacknowledged_count - 1)
        memmove(&map->unacknowledged[index],  &map->unacknowledged[index + 1], (map->unacknowledged_count - index - 1) * sizeof(retransmission_record_t));
    map->unacknowledged_count--;
    return true;
}

static inline bool resend_map_acknowledge(resend_map_t *map, const uint32_t seq, packet_datagrams_t *out_datagram) {
    return resend_map_remove(map, seq, 1, out_datagram);
}

static inline bool resend_map_retransmit(resend_map_t *map, const uint32_t seq, packet_datagrams_t *out_datagram) {
    return resend_map_remove(map, seq, 2, out_datagram);
}

static inline int64_t resend_map_rtt_ns(resend_map_t *map) {
    const int64_t now = get_time_ns();
    size_t write_idx = 0;
    for (size_t i = 0; i < map->delays_count; i++)
        if (now - map->delays[i].timestamp_ns <= RTT_CALCULATION_WINDOW_NS) {
            if (write_idx != i)
                map->delays[write_idx] = map->delays[i];
            write_idx++;
        }
    map->delays_count = write_idx;
    if (map->delays_count == 0)
        return DEFAULT_RTT_MS * 1000000LL;
    int64_t total = 0;
    for (size_t i = 0; i < map->delays_count; i++)
        total += map->delays[i].rtt_ns;
    return total / (int64_t)map->delays_count;
}

static inline int64_t resend_map_rtt_ms(resend_map_t *map) {
    return resend_map_rtt_ns(map) / 1000000LL;
}

static inline void resend_map_check_timeouts(resend_map_t *map, uint32_t **out_sequences, size_t *out_count) {
    const int64_t now = get_time_ns();
    const int64_t rtt = resend_map_rtt_ns(map);
    const int64_t timeout = rtt + rtt / 2; // RTT + RTT/2 as in Go code

    *out_sequences = NULL;
    *out_count = 0;
    size_t capacity = 0;

    for (size_t i = 0; i < map->unacknowledged_count; i++) {
        if (now - map->unacknowledged[i].timestamp_ns > timeout) {
            if (*out_count >= capacity) {
                capacity = capacity == 0 ? 16 : capacity * 2;
                uint32_t *new_seqs = reallocarray(*out_sequences, capacity, sizeof(uint32_t));
                if (!new_seqs) {
                    free(*out_sequences);
                    *out_sequences = NULL;
                    *out_count = 0;
                    return;
                }
                *out_sequences = new_seqs;
            }
            (*out_sequences)[(*out_count)++] = map->unacknowledged[i].datagram.sequence_number;
        }
    }
}

#endif //RAKNET_RTT_H
