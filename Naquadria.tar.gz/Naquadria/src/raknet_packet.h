//
// Created by kani on 12/1/2025 AD.
//

#ifndef RAKNET_PACKET_H
#define RAKNET_PACKET_H

#include "binarystream.h"
#include <stdlib.h>

#define MAGIC_PART_1 0x00FFFF00FEFEFEFE
#define MAGIC_PART_2 0xFDFDFDFD12345678
#define ID_PING 0x00
#define ID_UN_PING 0x01
#define ID_UN_PING_OPEN_CONNECTIONS 0x02
#define ID_PONG 0x03
#define ID_DETECT_LOSS_CONNECTION 0x04
#define ID_OPEN_REQUEST_1 0x05
#define ID_OPEN_REPLY_1 0x06
#define ID_OPEN_REQUEST_2 0x07
#define ID_OPEN_REPLY_2 0x08
#define ID_REQUEST 0x09
#define ID_REQUEST_ACCEPTED 0x10
#define ID_CONNECTION_REQUEST_FAILED 0x11
#define ID_ALREADY_CONNECTED 0x12
#define ID_NEW_INCOMING_CONNECTION 0x13
#define ID_DISCONNECT_NOTIFICATION 0x15
#define ID_CONNECTION_BANNED 0x17
#define ID_WRONG_PRO_VERSION 0x19
#define ID_UN_PONG 0x1C

// A-AS flags do nothing
// #define ID_SET_0 0x80
// #define ID_SET_4 0x84
// #define ID_SET_8 0x9c
// #define ID_SET_C 0x8c
// #define ID_NACK 0xA0
// #define ID_ACK 0xC0

typedef enum : uint8_t {
    FLAG_VALID 											= 0b10000000,
    FLAG_ACK 											= 0b01000000,
    FLAG_HAS_B_AND_AS 									= 0b00100000,
    FLAG_NACK 											= 0b00100000,
    FLAG_PACKET_PAIR 									= 0b00010000,
    FLAG_CONTINUOUS_SEND 								= 0b00001000,
    FLAG_NEEDS_B_AND_AS 								= 0b00000100
} DATA_FLAGS;

#define RELIABILITY_UNRELIABLE 0x00
#define RELIABILITY_UNRELIABLE_SEQUENCED 0x01
#define RELIABILITY_RELIABLE 0x02
#define RELIABILITY_RELIABLE_ORDERED 0x03
#define RELIABILITY_RELIABLE_SEQUENCED 0x04
#define RELIABILITY_UNRELIABLE_WITH_ACK_RECEIPT 0x05
#define RELIABILITY_RELIABLE_WITH_ACK_RECEIPT 0x06
#define RELIABILITY_RELIABLE_ORDERED_WITH_ACK_RECEIPT 0x07

#define PACKET_SIZE_UNCONNECTED_PING 33
#define PACKET_SIZE_UNCONNECTED_PONG 35
#define PACKET_SIZE_OPENCONNECTION_REQUEST_1 19
#define PACKET_SIZE_OPENCONNECTION_REPLY_1 28
#define PACKET_SIZE_INCOMPATIBLE_PROTOCOL_VERSION 26
#define PACKET_SIZE_OPENCONNECTION_REQUEST_2 34
#define PACKET_SIZE_OPENCONNECTION_REPLY_2 35
#define PACKET_SIZE_CONNECTION_BANNED 25
#define PACKET_SIZE_ALREADY_CONNECTED 25
#define PACKET_SIZE_CONNECTION_REQUEST 17
#define PACKET_SIZE_CONNECTED_PING 9

#define BYPASS_ALL_TEST

#ifndef MIN
    #define MIN(a, b) ((a) < (b) ? (a) : (b))
#endif

typedef struct {
    int64_t         ipv6_address_part1;
    int64_t         ipv6_address_part2;
    int32_t         ipv4_address;
    int16_t         port;
    uint8_t         ip_version;
} rak_address_t;

typedef struct {
    uint8_t         *payload;
    uint32_t        segmented_index;
    uint32_t        segmented_count;
    uint32_t        message_index;
    uint32_t        sequence_index;
    uint32_t        order_index;
    uint16_t        segmented_id;
    uint16_t        payload_size;
    int8_t          reliability;
    bool            invalid_need_b_and_as;
    bool            segmented;
} rak_message_t;

typedef struct {
    rak_message_t   *datagram_packets;
    size_t          datagram_packets_count;
    uint32_t        sequence_number;
} packet_datagrams_t;

static FORCE_INLINE bool is_reliable(const int8_t reliability) {
	return (reliability == RELIABILITY_RELIABLE ||
	    reliability == RELIABILITY_RELIABLE_ORDERED ||
	    reliability == RELIABILITY_RELIABLE_SEQUENCED ||
	    reliability == RELIABILITY_RELIABLE_WITH_ACK_RECEIPT ||
	    reliability == RELIABILITY_RELIABLE_ORDERED_WITH_ACK_RECEIPT);
}

static FORCE_INLINE bool is_sequenced(const int8_t reliability){
	return (reliability == RELIABILITY_UNRELIABLE_SEQUENCED ||
	    reliability == RELIABILITY_RELIABLE_SEQUENCED);
}

static FORCE_INLINE bool is_ordered(const int8_t reliability){
	return (reliability == RELIABILITY_UNRELIABLE_SEQUENCED ||
	    reliability == RELIABILITY_RELIABLE_ORDERED ||
	    reliability == RELIABILITY_RELIABLE_SEQUENCED ||
	    reliability == RELIABILITY_RELIABLE_ORDERED_WITH_ACK_RECEIPT);
}

static FORCE_INLINE int compare_uint32(const void *a, const void *b) {
    const uint32_t ua = *(const uint32_t*)a;
    const uint32_t ub = *(const uint32_t*)b;
    return (ua > ub) - (ua < ub);
}

static FORCE_INLINE bool raknet_read_unconnected_ping(const uint8_t *buffers, size_t *offset, const size_t length, int64_t* ping_id, int64_t* player_guid) {
#ifndef BYPASS_ALL_TEST
    if (length != PACKET_SIZE_UNCONNECTED_PING)
        return false;
#endif
    *ping_id =     io_read_int64(buffers, io_big_endian);
    bool invalid = false;
    invalid |=     io_read_int64(buffers + 8, io_big_endian) != MAGIC_PART_1;
    invalid |=     io_read_int64(buffers + 16, io_big_endian) != MAGIC_PART_2;
    *player_guid = io_read_int64(buffers + 24, io_big_endian);
    *offset = PACKET_SIZE_UNCONNECTED_PING;
#ifndef BYPASS_ALL_TEST
    return !invalid;
#else
    return true;
#endif
}

static FORCE_INLINE void raknet_create_unconnected_pong(uint8_t *buffers, size_t *length, const int64_t magic_0, const int64_t magic_1, const int64_t server_guid, const int16_t motd_size, const char *message) {
    io_write_int8(buffers, ID_UN_PONG);
    io_write_int64(buffers + 9, server_guid, io_big_endian);
    io_write_int64(buffers + 17, magic_0, io_big_endian);
    io_write_int64(buffers + 25, magic_1, io_big_endian);
    io_write_int16(buffers + 33, motd_size, io_big_endian);
    memcpy(buffers + 35, message, motd_size);
    *length = PACKET_SIZE_UNCONNECTED_PONG + motd_size;
}

static FORCE_INLINE void raknet_write_unconnected_pong(uint8_t *buffers, size_t *length, const int64_t ping_id, const int16_t motd_size) {
    io_write_int64(buffers + 1, ping_id, io_big_endian);
    *length = PACKET_SIZE_UNCONNECTED_PONG + motd_size;
}

static FORCE_INLINE bool raknet_read_open_connection_request_1(const uint8_t *buffers, size_t *offset, const size_t length, int8_t *protocol_version, size_t *mtu) {
#ifndef BYPASS_ALL_TEST
    if (length < PACKET_SIZE_OPENCONNECTION_REQUEST_1)
         return false;
#endif
    bool invalid = false;
    invalid |= io_read_int64(buffers, io_big_endian) != MAGIC_PART_1;
    invalid |= io_read_int64(buffers + 8, io_big_endian) != MAGIC_PART_2;
    *protocol_version = io_read_int8(buffers + 16);
    *mtu = length + 9;
    *offset = PACKET_SIZE_OPENCONNECTION_REQUEST_1;
#ifndef BYPASS_ALL_TEST
    return !invalid;
#else
    return true;
#endif
}

static FORCE_INLINE void raknet_write_incompatible_protocol_version(uint8_t *buffers, size_t *length, const int8_t protocol_version, const int64_t magic_0, const int64_t magic_1, const int64_t server_guid) {
    io_write_int8(buffers, ID_WRONG_PRO_VERSION);
    io_write_int8(buffers + 1, protocol_version);
    io_write_int64(buffers + 2, magic_0, io_big_endian);
    io_write_int64(buffers + 10, magic_1, io_big_endian);
    io_write_int64(buffers + 18, server_guid, io_big_endian);
    *length = PACKET_SIZE_INCOMPATIBLE_PROTOCOL_VERSION;
}

static FORCE_INLINE void raknet_write_open_connection_reply_1(uint8_t *buffers, size_t *length, const int64_t magic_0, const int64_t magic_1, const int64_t server_guid, const int32_t cookie, const int16_t mtu) {
    io_write_int8(buffers, ID_OPEN_REPLY_1);
    io_write_int64(buffers + 1, magic_0, io_big_endian);
    io_write_int64(buffers + 9, magic_1, io_big_endian);
    io_write_int64(buffers + 17, server_guid, io_big_endian);
    io_write_int8(buffers + 25, (int8_t) (cookie != 0));
    *length = PACKET_SIZE_OPENCONNECTION_REPLY_1;
    if(cookie != 0) {
        io_write_int32(buffers + 26, cookie, io_big_endian);
        *length += 4;
    }
    io_write_int16(buffers + ((cookie != 0) ? 30 : 26), mtu, io_big_endian);
}

static FORCE_INLINE bool raknet_read_open_connection_request_2(const uint8_t *buffers, size_t *offset, size_t length, int32_t *cookie, rak_address_t *address, int16_t *mtu, int64_t *player_guid) {
    bool invalid = false;
    invalid |=     io_read_int64(buffers, io_big_endian) != MAGIC_PART_1;
    invalid |=     io_read_int64(buffers + 8, io_big_endian) != MAGIC_PART_2;
    *offset = 16;
    if(*cookie != 0) {
        *cookie =      io_read_int32(buffers + 16, io_big_endian);
        invalid |=     io_read_int8(buffers + 20);
        *offset += 5;
    }
    address->ip_version =       io_read_int8(buffers + *offset);
    *offset += 1;
    if(address->ip_version == 4) {
        address->ipv4_address = io_read_int32(buffers + *offset, io_big_endian);
        address->port =         io_read_int16(buffers + *offset + 4, io_big_endian);
        *offset += 6;
    }else if(address->ip_version == 6) {
        invalid |=                    io_read_int16(buffers + *offset, io_little_endian) != 0x17;
        address->port =               io_read_int16(buffers + *offset + 2, io_big_endian);
        address->ipv6_address_part1 = io_read_int64(buffers + *offset + 8, io_big_endian);
        address->ipv6_address_part2 = io_read_int64(buffers + *offset + 16, io_big_endian);
        invalid |=                    io_read_int32(buffers + *offset + 24, io_big_endian) != 0x00;
        *offset += 28;
    }else{
        invalid = true;
        *offset += 28;
    }
    *mtu = io_read_int16(buffers + *offset, io_big_endian);
    *player_guid = io_read_int64(buffers + *offset + 2, io_big_endian);
#ifndef BYPASS_ALL_TEST
    return !invalid;
#else
    return true;
#endif
}

static FORCE_INLINE void raknet_write_open_connection_reply_2(uint8_t *buffers, size_t *length, const int64_t magic_0, const int64_t magic_1, const int64_t server_guid, const rak_address_t address, const int16_t mtu, const bool encryption) {
    io_write_int8(buffers, ID_OPEN_REPLY_2);
    io_write_int64(buffers + 1, magic_0, io_big_endian);
    io_write_int64(buffers + 9, magic_1, io_big_endian);
    io_write_int64(buffers + 17, server_guid, io_big_endian);
    if(address.ip_version == 4 || address.ip_version == 0) {
         io_write_int8(buffers + 25, 4);
         io_write_int32(buffers + 26, (int32_t) (address.ip_version == 4 ? address.ipv4_address : 0xFFFFFFFF), io_big_endian);
         io_write_int16(buffers + 30, address.port, io_big_endian);
         *length = 32;
    } else {
         io_write_int8(buffers + 25, (int8_t) address.ip_version);
         io_write_int16(buffers + 26, 0x17, io_little_endian);
         io_write_int16(buffers + 28, address.port, io_big_endian);
         io_write_int32(buffers + 30, 0, io_big_endian);
         io_write_int64(buffers + 34, address.ipv6_address_part1, io_big_endian);
         io_write_int64(buffers + 42, address.ipv6_address_part2, io_big_endian);
         io_write_int32(buffers + 50, address.ipv4_address, io_big_endian);
         *length = 54;
    }
    io_write_int16(buffers + *length, mtu, io_big_endian);
    io_write_int8(buffers + *length + 2, (int8_t) encryption);
    *length += 3;
}

static FORCE_INLINE void raknet_write_connection_attempt_failed(uint8_t *buffers, size_t *length) {
    io_write_int8(buffers, ID_CONNECTION_REQUEST_FAILED);
    *length = 1;
}

static FORCE_INLINE void raknet_write_already_connected(uint8_t *buffers, size_t *length, const int64_t magic_0, const int64_t magic_1, const int64_t client_guid) {
    io_write_int8(buffers, ID_ALREADY_CONNECTED);
    io_write_int64(buffers + 1, magic_0, io_big_endian);
    io_write_int64(buffers + 9, magic_1, io_big_endian);
    io_write_int64(buffers + 17, client_guid, io_big_endian);
    *length = PACKET_SIZE_ALREADY_CONNECTED;
}

static FORCE_INLINE void raknet_write_connection_banned(uint8_t *buffers, size_t *length, const int64_t magic_0, const int64_t magic_1, const int64_t server_guid) {
    io_write_int8(buffers, ID_CONNECTION_BANNED);
    io_write_int64(buffers + 1, magic_0, io_big_endian);
    io_write_int64(buffers + 9, magic_1, io_big_endian);
    io_write_int64(buffers + 17, server_guid, io_big_endian);
    *length = PACKET_SIZE_CONNECTION_BANNED;
}

static FORCE_INLINE bool raknet_read_online_frames_header(const uint8_t *buffers, size_t *offset, size_t length, int32_t *sequence_number) {
    *sequence_number = io_read_int24(buffers + *offset);
    *offset += 3;
    return true;
}

static FORCE_INLINE bool raknet_read_online_data_gram_capsule(const uint8_t *buffers, size_t *offset, const size_t length, rak_message_t *packet) {
    bool invalid = false;
#ifndef BYPASS_ALL_TEST
    if(length < 3)
        invalid |= true;
#endif
    const int8_t flags =            io_read_int8(buffers + *offset);
    *offset += 1;
    packet->invalid_need_b_and_as =(flags & 0x04) > 0; //cloudburst only issue
    packet->segmented =            (flags & 0x10) > 0;
	packet->reliability = (int8_t)((flags & 0xE0) >> 5);
	packet->payload_size =(int16_t)(io_read_int16(buffers + *offset, io_big_endian) >> 3);
    *offset += 2;
    if(is_reliable(packet->reliability)) {
        if((*offset + 3) > length) return false;
        packet->message_index =     io_read_int24(buffers + *offset);
        *offset += 3;
    }
	if(is_sequenced(packet->reliability)) {
	    if((*offset + 3) > length) return false;
	    packet->sequence_index =    io_read_int24(buffers + *offset);
	    *offset += 3;
    }
    if(is_ordered(packet->reliability) || is_sequenced(packet->reliability)) {
        if((*offset + 4) > length) return false;
        packet->order_index =       io_read_int24(buffers + *offset);
        if(io_read_int8(buffers + (*offset + 3)) != 0)
            invalid |= true;
        *offset += 4;
    }
	if(packet->segmented) {
        if((*offset + 10) > length) return false;
	    packet->segmented_count =   io_read_int32(buffers + *offset, io_big_endian);
	    *offset += 4;
		packet->segmented_id =      io_read_int16(buffers + *offset, io_big_endian);
	    *offset += 2;
	    packet->segmented_index =   io_read_int32(buffers + *offset, io_big_endian);
        *offset += 4;
    }
    if((*offset + packet->payload_size) > length) {
        invalid |= true;
    }else {
        packet->payload = (uint8_t *)malloc(packet->payload_size);
        memcpy(packet->payload, buffers + *offset, packet->payload_size);
        *offset += packet->payload_size;
    }
#ifndef BYPASS_ALL_TEST
    return !invalid;
#else
    return true;
#endif
}

static FORCE_INLINE void raknet_write_online_frames_header(uint8_t *buffers, size_t *length, const int8_t flags, const int32_t sequence_number) {
    io_write_int8(buffers, flags);
    io_write_int24(buffers + 1, sequence_number);
    *length = 4;
}

static FORCE_INLINE size_t raknet_write_online_data_gram_capsule_size(const rak_message_t packet) {
    size_t size = 3 + packet.payload_size;
    if(is_reliable(packet.reliability))
        size += 3;
	if(is_sequenced(packet.reliability))
        size += 3;
    if(is_ordered(packet.reliability))
        size += 4;
    if(packet.segmented)
        size += 10;
    return size;
}

static FORCE_INLINE void raknet_write_online_data_gram_capsule(uint8_t *buffers, size_t *length, const rak_message_t packet) {
    io_write_int8(buffers + *length, (int8_t) (packet.reliability << 5 | (packet.segmented != 0 ? 0x10 : 0x00) | 0x04));
    *length += 1;
    io_write_int16(buffers + *length, (int16_t) (packet.payload_size << 3), io_big_endian);
    *length += 2;
    if(is_reliable(packet.reliability)) {
        io_write_int24(buffers + *length, (int32_t) packet.message_index);
        *length += 3;
    }
	if(is_sequenced(packet.reliability)) {
        io_write_int24(buffers + *length, (int32_t) packet.sequence_index);
        *length += 3;
    }
    if(is_ordered(packet.reliability)) {
        io_write_int24(buffers + *length, (int32_t) packet.order_index);
        io_write_int8(buffers + (*length + 1), (int8_t) ((packet.order_index >> 16) & 0xFF));
        *length += 4;
    }
	if(packet.segmented) {
        io_write_int32(buffers + *length, (int32_t) packet.segmented_count, io_big_endian);
        io_write_int16(buffers + (*length + 4), (int16_t) packet.segmented_id, io_big_endian);
        io_write_int32(buffers + (*length + 6), (int32_t) packet.segmented_index, io_big_endian);
        *length += 10;
    }
    memcpy(buffers + *length, packet.payload, packet.payload_size);
    *length += packet.payload_size;
}

static FORCE_INLINE bool raknet_read_online_connection_request(const uint8_t *buffers, size_t *offset, const size_t length, int64_t *client_guid, int64_t *client_timestamp) {
    if(length < PACKET_SIZE_CONNECTION_REQUEST) return false;
    *client_guid = io_read_int64(buffers, io_big_endian);
    *client_timestamp = io_read_int64(buffers + 8, io_big_endian);
#ifndef BYPASS_ALL_TEST
    return io_read_int8(buffers + 16) == 0;
#else
    return true;
#endif
}

static FORCE_INLINE size_t raknet_write_online_ack_nack_size(const uint16_t sequence_numbers_count, uint32_t **sequence_numbers, uint16_t *record_count) {
    if (sequence_numbers_count == 0) {
        *record_count = 0;
        return 3;
    }
    uint32_t *sequences = *sequence_numbers;
    qsort(sequences, sequence_numbers_count, sizeof(uint32_t), compare_uint32);
    size_t size = 3;
    uint16_t new_record_count = 0;
    uint32_t start_index = sequences[0];
    uint32_t end_index = sequences[0];
    for (uint16_t i = 1; i < sequence_numbers_count; ++i) {
        const uint32_t current_index = sequences[i];
        const uint32_t diff = current_index - end_index;
        if (diff == 1) {
            end_index = current_index;
        } else if (diff > 1) {
            size += (start_index == end_index) ? 4 : 7;
            new_record_count++;
            start_index = end_index = current_index;
        }
    }
    size += (start_index == end_index) ? 4 : 7;
    new_record_count++;
    *record_count = new_record_count;
    return size;
}

static FORCE_INLINE void raknet_write_online_ack_nack(uint8_t *buffers, size_t *length, const bool is_ack, const uint16_t sequence_numbers_count, const uint32_t *sequence_numbers, const uint16_t record_count) {
	if (sequence_numbers_count <= 0) return;
    *length = 0;
    io_write_int8(buffers + *length, (int8_t) (FLAG_VALID | (is_ack ? (FLAG_ACK | FLAG_HAS_B_AND_AS) : FLAG_NACK)));
    if (is_ack) {
        io_write_float32(buffers + *length, 0.0f, io_big_endian);
        *length += 4;
    }
    io_write_int16(buffers + *length + 1, (int16_t) record_count, io_big_endian);
    *length += 3;
	uint32_t start_index = sequence_numbers[0];
	uint32_t end_index = sequence_numbers[0];
    for (uint16_t i = 1; i < sequence_numbers_count; ++i) {
		const uint32_t current_index = sequence_numbers[i];
		const uint32_t diff = current_index - end_index;
		if (diff == 1) {
			end_index = current_index;
		} else if (diff > 1) {
			if (start_index == end_index) {
				io_write_int8(buffers + *length, 1);
                io_write_int24(buffers + *length + 1, (int32_t) start_index);
                *length += 4;
			} else {
				io_write_int8(buffers + *length, 0);
                io_write_int24(buffers + *length + 1, (int32_t) start_index);
                io_write_int24(buffers + *length + 4, (int32_t) end_index);
                *length += 7;
			}
            start_index = end_index = current_index;
		}
	}
	if (start_index == end_index) {
		io_write_int8(buffers + *length, 0x01);
        io_write_int24(buffers + *length + 1, (int32_t) start_index);
        *length += 4;
	} else {
		io_write_int8(buffers + *length, 0x00);
        io_write_int24(buffers + *length + 1, (int32_t) start_index);
        io_write_int24(buffers + *length + 4, (int32_t) end_index);
        *length += 7;
	}
}

static FORCE_INLINE size_t raknet_read_online_ack_nack_size(const uint8_t *buffers) {
    const uint16_t record_count = io_read_int16(buffers, io_big_endian);
    size_t sequence_numbers_count = 0;
    size_t offset = 2;
	for (uint16_t i = 0; i < record_count; ++i) {
		if (io_read_int8(buffers + offset)) {
            offset += 4;
			sequence_numbers_count++;
		} else {
			const uint32_t index = (uint32_t) io_read_int24(buffers + offset + 1);
			const uint32_t end_index = (uint32_t) io_read_int24(buffers + offset + 4);
            offset += 7;
            sequence_numbers_count += (end_index - index + 1);
		}
	}
    return sequence_numbers_count;
}

static FORCE_INLINE void raknet_read_online_ack_nack(const uint8_t *buffers, size_t *offset, size_t length, uint32_t *sequence_numbers) {
    const uint16_t record_count = io_read_int16(buffers, io_big_endian);
    *offset = 2;
    size_t sequence_numbers_count = 0;
	for (uint16_t i = 0; i < record_count; ++i) {
		const int8_t is_single = io_read_int8(buffers + *offset);
        *offset += 1;
		if (is_single != 0) {
		 	sequence_numbers[sequence_numbers_count] = (uint32_t) io_read_int24(buffers + *offset);
            sequence_numbers_count++;
            *offset += 3;
		} else {
			uint32_t index = io_read_int24(buffers + *offset);
			const uint32_t end_index = io_read_int24(buffers + *offset + 3);
			while (index <= end_index) {
				sequence_numbers[sequence_numbers_count] = index;
				sequence_numbers_count++;
				index++;
			}
		}
	}
}

static FORCE_INLINE size_t raknet_online_connection_request_accepted_size(const rak_address_t client_address, const int8_t size, const rak_address_t* address) {
    size_t length = 33;
    if(client_address.ip_version != 4 && client_address.ip_version != 0) {
        length += 22;
    }
    for (int8_t i = 0; i < size; i++) {
        length += 7;
        if (address[i].ip_version != 4 && address[i].ip_version != 0)
            length += 22;
    }
    length += 16;
    return length;
}

static FORCE_INLINE void raknet_write_online_connection_request_accepted(uint8_t *buffers, size_t *length, const rak_address_t client_address, const int8_t size, const rak_address_t* address, const int64_t request_timestamp, const int64_t reply_timestamp) {
    io_write_int8(buffers, ID_REQUEST_ACCEPTED);
    if(client_address.ip_version == 4 || client_address.ip_version == 0) {
        io_write_int8(buffers + 1, 4);
        io_write_int32(buffers + 2, (int32_t) (client_address.ip_version == 4 ? ~client_address.ipv4_address : 0xFFFFFFFF), io_big_endian);
	    io_write_int16(buffers + 6, client_address.port, io_big_endian);
        *length = 10;
    }else{
        io_write_int8(buffers + 1, 6);
        io_write_int16(buffers + *length + 2, 0x17, io_little_endian);
		io_write_int16(buffers + *length + 4, client_address.port, io_big_endian);
        io_write_int64(buffers + *length + 8, client_address.ipv6_address_part1, io_big_endian);
        io_write_int64(buffers + *length + 16, client_address.ipv6_address_part2, io_big_endian);
	    io_write_int32(buffers + *length + 24, client_address.ipv4_address, io_big_endian);
        *length = 32;
    }
    for (int8_t i = 0; i < size; i++) {
        const rak_address_t _address = address[i];
        if(_address.ip_version == 4) {
            io_write_int8(buffers + *length, 4);
            io_write_int32(buffers + *length + 1, ~_address.ipv4_address, io_big_endian);
            io_write_int16(buffers + *length + 5, _address.port, io_big_endian);
            *length += 7;
        } else if(_address.ip_version == 0) {
            io_write_int8(buffers + *length, 4);
            io_write_int32(buffers + *length + 1, (int32_t) 0xFFFFFFFF, io_big_endian);
            *length += 7;
        } else {
            io_write_int8(buffers + *length, (int8_t) _address.ip_version);
            io_write_int16(buffers + *length + 1, 0x17, io_little_endian);
		    io_write_int16(buffers + *length + 3, _address.port, io_big_endian);
            if(_address.ip_version == 6) {
                io_write_int64(buffers + *length + 9, _address.ipv6_address_part1, io_big_endian);
                io_write_int64(buffers + *length + 17, _address.ipv6_address_part2, io_big_endian);
            }else{
                memset(buffers + *length + 9, 0xFF, 16);
            }
	    	io_write_int32(buffers + *length + 25, _address.ipv4_address, io_big_endian);
            *length += 29;
        }
	}
    io_write_int64(buffers + *length, request_timestamp, io_big_endian);
    io_write_int64(buffers + *length + 8, reply_timestamp, io_big_endian);
    *length += 16;
}

static FORCE_INLINE bool raknet_read_online_new_incoming_connection(const uint8_t *buffers, size_t *offset, const size_t length, rak_address_t* server_address, rak_address_t* client_address) {
    bool invalid = false;
    server_address->ip_version =             io_read_int8(buffers + *offset);
    if(server_address->ip_version == 4) {
        server_address->ipv4_address =      ~io_read_int32(buffers + *offset + 1, io_big_endian);
        server_address->port =               io_read_int16(buffers + *offset + 5, io_big_endian);
        *offset = 7;
    }else if(server_address->ip_version == 6) {
        invalid |=                           io_read_int16(buffers + *offset + 1, io_big_endian) != 0x17;
        server_address->port =               io_read_int16(buffers + *offset + 3, io_big_endian);
        invalid |=                           io_read_int32(buffers + *offset + 5, io_big_endian) != 0x00;
        server_address->ipv6_address_part1 = io_read_int64(buffers + *offset + 9, io_big_endian);
        server_address->ipv6_address_part2 = io_read_int64(buffers + *offset + 17, io_big_endian);
        invalid |=                           io_read_int32(buffers + *offset + 25, io_little_endian) != 0x00;
        *offset = 29;
    }else{
        invalid = true;
        *offset = 29;
    }
    if(length - *offset < 0) {
        return false;
    }
    for(int8_t i = 0; i < 20; i++) {
#ifndef BYPASS_ALL_TEST
        if(i != 19 && (length - *offset < 0)) {
            invalid = true;
            break;
        }
#else
        if((length - *offset) < 0) {
            break;
        }
#endif
        const uint8_t ip_version = io_read_int8(buffers);
        *offset += 1;
        if(i == 0) {
            client_address->ip_version = ip_version;
            if(ip_version == 4) {
                client_address->ipv4_address =      ~io_read_int32(buffers + *offset, io_big_endian);
                client_address->port =               io_read_int16(buffers + *offset + 4, io_big_endian);
                *offset += 6;
            }else if(ip_version == 6) {
                invalid |=                           io_read_int16(buffers + *offset, io_little_endian) != 0x17;
                client_address->port =               io_read_int16(buffers + *offset + 2, io_big_endian);
                invalid |=                           io_read_int32(buffers + *offset + 4, io_big_endian) != 0x00;
                client_address->ipv6_address_part1 = io_read_int64(buffers + *offset + 8, io_big_endian);
                client_address->ipv6_address_part2 = io_read_int64(buffers + *offset + 16, io_big_endian);
                invalid |=                           io_read_int32(buffers + *offset + 24, io_big_endian) != 0x00;
                *offset += 28;
            }else{
                invalid = true;
                *offset += 28;
            }
        }else{
            invalid |= ip_version != 4;
            *offset += (ip_version == 4) ? 6 : 28;
        }
    }
#ifndef BYPASS_ALL_TEST
    return !invalid;
#else
    return true;
#endif
}

static FORCE_INLINE void raknet_write_online_ping(uint8_t *buffers, size_t *length, const int64_t server_send_time) {
    io_write_int8(buffers, ID_PING);
    io_write_int64(buffers + 1, server_send_time, io_big_endian);
    *length = 9;
}

static FORCE_INLINE bool raknet_read_online_ping(const uint8_t *buffers, size_t *offset, int64_t* client_send_time) {
    *client_send_time = io_read_int64(buffers, io_big_endian);
    return true;
}

static FORCE_INLINE void raknet_write_online_pong(uint8_t *buffers, size_t *length, const int64_t client_send_time, const int64_t server_send_time) {
    io_write_int8(buffers, ID_PONG);
    io_write_int64(buffers + 1, client_send_time, io_big_endian);
    io_write_int64(buffers + 9, server_send_time, io_big_endian);
    *length = 17;
}

static FORCE_INLINE bool raknet_read_online_pong(const uint8_t *buffers, size_t *offset, int64_t* client_send_time, int64_t* server_send_time) {
    *client_send_time = io_read_int64(buffers, io_big_endian);
    *server_send_time = io_read_int64(buffers + 8, io_big_endian);
    return true;
}

#endif //RAKNET_PACKET_H
