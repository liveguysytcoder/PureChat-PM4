//
// Created by kani on 6/12/25.
//
#include "compression.h"

bool zlib_decompress_buffer(const uint8_t *input_buff, const size_t input_len, uint8_t **output_buff, size_t *output_size, struct libdeflate_decompressor *decompressor) {
    *output_buff = malloc(input_len * 4);
    size_t out_size = 0;
    if (libdeflate_zlib_decompress(decompressor, input_buff, *output_size, output_buff, input_len << 2, &out_size) != LIBDEFLATE_SUCCESS) {
        free(*output_buff);
        return false;
    }
    libdeflate_free_decompressor(decompressor);
    *output_size = out_size;
    return true;
}

bool snappy_decompress_buffer(const uint8_t *input_buff, const size_t input_len, uint8_t **output_buff, size_t *output_size) {
    if (snappy_validate_compressed_buffer((char *)input_buff, input_len) != SNAPPY_OK)
        return false;
    const snappy_status stat = snappy_uncompressed_length((char *)input_buff, input_len, output_size);
    if (stat != SNAPPY_OK)
        return false;
    *output_buff = malloc(*output_size);
    if (snappy_uncompress((char *)input_buff, input_len, (char *)*output_buff, output_size) != SNAPPY_OK) {
        free(*output_buff);
        return false;
    }
	return true;
}

bool zlib_compress_buffer(const uint8_t *input_buff, const size_t input_len, uint8_t **output_buff, size_t *output_size, struct libdeflate_compressor *compressor) {
    if (compressor == nullptr)
        return false;
    size_t compressed_output_length = libdeflate_deflate_compress_bound(compressor, input_len);
    *output_buff = malloc(compressed_output_length);
    compressed_output_length = libdeflate_zlib_compress(compressor, input_buff, input_len, *output_buff, compressed_output_length);
    if (compressed_output_length == 0) {
        free(*output_buff);
        return false;
    }
    *output_size = compressed_output_length;
    libdeflate_free_compressor(compressor);
    return true;
}

bool snappy_compress_buffer(const uint8_t *input_buff, const size_t input_len, uint8_t **output_buff, size_t *output_size) {
    size_t compressed_output_length = snappy_max_compressed_length(input_len);
    *output_buff = malloc(compressed_output_length);
    snappy_compress((const char*) input_buff, input_len, (char *)*output_buff, &compressed_output_length);
    *output_size = compressed_output_length;
    if (snappy_validate_compressed_buffer((char *)*output_buff, compressed_output_length) != SNAPPY_OK) {
        free(*output_buff);
        return false;
    }
    return true;
}