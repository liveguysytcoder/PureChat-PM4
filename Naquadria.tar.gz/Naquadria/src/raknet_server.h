//
// Created by zeen on 9/6/25.
//

#ifndef RAKNET_SERVER_H
#define RAKNET_SERVER_H
#define _GNU_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <uv.h>
#include <stdint.h>
#include <unistd.h>
#include <sys/socket.h>
#include <liburing.h>
#include <openssl/types.h>

#include "raknet_packet.h"
#include "raknet_types.h"
#include "debug.h"
#include "fasthash.h"
#include "lookup3.h"
#include "raknet_rtt.h"

#define SERVER_GUID  0xC00FEE1234567890

typedef struct bedrock_player_data bedrock_player_data_t;

#define BATCH_SIZE 1024

typedef struct {
    uint64_t               address;
    uint64_t               end_time;
} blocked_connection_t;

typedef struct {
    struct sockaddr_in     address;
    binary_stream_t        *raw_packets_queues;
    size_t                 raw_packets_queues_size;
    uint64_t               hash;
    connection_state_t     state;
} non_connected_t;

typedef struct client_context{
    non_connected_t        basic_info;
    bedrock_player_data_t *player_data;
    rak_address_t          client_address;
    rak_message_t          *segmented_datagram_packets_queue;
    packet_datagrams_t     encoded_datagram_send_packets_queue;
    resend_map_t           *retransmission;
    uint32_t               *ack_queue;
    uint32_t               *nack_queue;
    int64_t                last_ping_time;
    int64_t                last_receive_time;
    int32_t                next_sequence_number;
    int32_t                next_message_index;
    int32_t                next_order_index;
    uint32_t               expected_sequence_number;
    uint32_t               segmented_datagram_packets_queue_size;
    int16_t                mtu;
    uint16_t               ack_queue_size;
    uint16_t               nack_queue_size;
    uint16_t               packet_violation;
    uint16_t               segmented_id;
} client_context_t;

typedef struct {
    size_t                 messages_size;
    struct mmsghdr         *messages;
    size_t                 clients_size;
    client_context_t       *clients;
    size_t                 bedrock_players_size;
    bedrock_player_data_t  *bedrock_players;
    size_t                 blocked_connections_size;
    blocked_connection_t   *blocked_connections;
    char                   *motd;
    int64_t                server_guid;
    int16_t                motd_size;
    bool                   enable_cookie;
    EVP_PKEY*              server_key;
} server_context_t;


int raknet_server_init(int port);
void raknet_server_shutdown();
void *raknet_server_recv_thread(void *arg);

#endif //RAKNET_SERVER_H