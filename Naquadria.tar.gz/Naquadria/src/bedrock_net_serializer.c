//
// Created by zeen on 9/15/25.
//
#include "bedrock_net_serializer.h"
#include "bedrock_packet_def.h"

pck_packet_t* pck_create(const size_t length) {
    pck_packet_t* packet = malloc(sizeof(pck_packet_t));
    memset(&packet->stream, 0, sizeof(binary_stream_t));
    packet->stream.buffer = malloc(length);
    packet->stream.size = length;
    packet->cursor = 0;
    return packet;
}

pck_packet_t* pck_from_bytes(const uint8_t* bytes, const size_t length) {
    pck_packet_t* packet;
    memset(&packet, 0, sizeof(pck_packet_t));
    packet->stream.buffer = malloc(length);
    packet->stream.size = length;
    packet->cursor = 0;
    memcpy(packet->stream.buffer, bytes, length);
    return packet;
}

void pck_init_from_bytes(pck_packet_t* packet, const uint8_t* bytes, const size_t length) {
    packet->stream.buffer = malloc(length);
    packet->stream.size = length;
    packet->cursor = 0;
    memcpy(packet->stream.buffer, bytes, length);
}
////////////////////////////////////////////////////////////////////////////////////
/// BASIC PROTOCOL READ AND WRITE
////////////////////////////////////////////////////////////////////////////////////
void net_read_var_int_bytes(pck_packet_t* packet, uint32_t *size, uint8_t** data) {
    *size = pck_read_var_int(packet);
    *data = (uint8_t *) malloc(*size);
    pck_read_bytes(packet, *data, (int32_t )*size);
}

void net_read_uuid(pck_packet_t* packet, const uuid_t uuid) {
    pck_read_bytes(packet, (uint8_t *) uuid, 16);
}

void net_write_uuid(pck_packet_t* packet, const uuid_t uuid) {
    pck_write_bytes(packet, (uint8_t *) uuid, 16);
}

void net_write_experiment_entry(pck_packet_t* packet, const experiment_entry_t entry) {
    PCK_REALLOC(packet,
        entry.experiment_name.size + io_var_int_length(entry.experiment_name.size) +
        1
    );
    pck_write_string(packet, entry.experiment_name.buffer, entry.experiment_name.size);
}
////////////////////////////////////////////////////////////////////////////////////
/// RESOURCE PACK DATA READ AND WRITE
////////////////////////////////////////////////////////////////////////////////////
void net_write_resource_pack_info_entry(pck_packet_t* packet, const resource_pack_info_entry_t entry) {
    PCK_REALLOC(packet,
        entry.version.size + io_var_int_length(entry.version.size) +
        entry.encryption_key.size + io_var_int_length(entry.encryption_key.size) +
        entry.sub_pack_name.size + io_var_int_length(entry.sub_pack_name.size) +
        entry.content_id.size + io_var_int_length(entry.content_id.size) +
        entry.cdn_url.size + io_var_int_length(entry.cdn_url.size) +
        27
    );
    net_write_uuid(packet, entry.uuid);
    pck_write_string(packet, entry.version.buffer, entry.version.size);
    pck_write_int64(packet, (int64_t) entry.size);
    pck_write_string(packet, entry.encryption_key.buffer, entry.encryption_key.size);
    pck_write_string(packet, entry.sub_pack_name.buffer, entry.sub_pack_name.size);
    pck_write_string(packet, entry.content_id.buffer, entry.content_id.size);
    pck_write_int8(packet, entry.has_scripts ? 1 : 0);
    pck_write_int8(packet, entry.is_addon_pack ? 1 : 0);
    pck_write_int8(packet, entry.is_rtx_capable ? 1 : 0);
    pck_write_string(packet, entry.cdn_url.buffer, entry.cdn_url.size);
}
void net_write_resource_pack_stack_entry(pck_packet_t* packet, const resource_pack_stack_entry_t entry) {
    PCK_REALLOC(packet,
        entry.pack_id.size + io_var_int_length(entry.pack_id.size) +
        entry.version.size + io_var_int_length(entry.version.size) +
        entry.sub_pack_name.size + io_var_int_length(entry.sub_pack_name.size)
    );
    pck_write_string(packet, entry.pack_id.buffer, entry.pack_id.size);
    pck_write_string(packet, entry.version.buffer, entry.version.size);
    pck_write_string(packet, entry.sub_pack_name.buffer, entry.sub_pack_name.size);
}
////////////////////////////////////////////////////////////////////////////////////
/// ITEM DATA READ AND WRITE
////////////////////////////////////////////////////////////////////////////////////
item_stack_header_t net_read_item_stack_header(pck_packet_t* packet) {
    item_stack_header_t header = {
        .id = pck_read_var_int_signed(packet),
    };
    if (header.id == 0)
        return header;
    header.count = pck_read_int16(packet);
    header.meta = pck_read_var_int(packet);
    return header;
}

void net_write_item_stack_header(pck_packet_t* packet, item_stack_header_t item_stack_header) {
    PCK_REALLOC(packet, io_var_int_length(item_stack_header.id));
    pck_write_var_int_signed(packet, item_stack_header.id);
    if (item_stack_header.id == 0) {
        return;
    }
    PCK_REALLOC(packet, 2 +
        io_var_int_length(item_stack_header.meta)
    );
    pck_write_int16(packet, item_stack_header.count);
    pck_write_var_int(packet, (int32_t) item_stack_header.meta);
}

/*
 * NetworkItemStackDescriptor in mojang docs
 */
item_stack_wrapper_t net_read_item_stack_wrapper(pck_packet_t* packet) {
    const item_stack_header_t item_stack_header = net_read_item_stack_header(packet);
    item_stack_wrapper_t item_stack_wrapper = {0};
    if (item_stack_header.id == 0)
        return item_stack_wrapper;
    item_stack_wrapper.stack_id = (pck_read_int8(packet) > 0) ? pck_read_var_int_signed(packet) : 0;
    item_stack_t item_stack = {
        .item_stack_header = item_stack_header,
        .block_runtime_id = pck_read_var_int_signed(packet)
    };
    net_read_var_int_bytes(packet, &item_stack.raw_extra_data_size, &item_stack.raw_extra_data);
    item_stack_wrapper.item_stack = item_stack;
    return item_stack_wrapper;
}

/*
 * NetworkItemStackDescriptor in mojang docs
 */
void net_write_item_stack_wrapper(pck_packet_t* packet, const item_stack_wrapper_t item_stack_wrapper) {
    net_write_item_stack_header(packet, item_stack_wrapper.item_stack.item_stack_header);
    if (item_stack_wrapper.item_stack.item_stack_header.id == 0)
        return;
    PCK_REALLOC(packet,
        1 +
        io_var_int_length(item_stack_wrapper.item_stack.block_runtime_id) +
        io_var_int_length(item_stack_wrapper.item_stack.raw_extra_data_size) + item_stack_wrapper.item_stack.raw_extra_data_size
    );
    if (item_stack_wrapper.stack_id != 0){
        pck_write_int8(packet, 1);
        PCK_REALLOC(packet, io_var_int_length(item_stack_wrapper.stack_id));
        pck_write_var_int_signed(packet, item_stack_wrapper.stack_id);
    }else {
        pck_write_int8(packet, 0);
    }
    pck_write_var_int_signed(packet, item_stack_wrapper.item_stack.block_runtime_id);
    pck_write_string(packet, item_stack_wrapper.item_stack.raw_extra_data, item_stack_wrapper.item_stack.raw_extra_data_size);
}

/*
 * NetworkItemInstanceDescriptor in mojang docs
 */
item_stack_t net_read_item_stack_without_stack_id(pck_packet_t* packet) {
    item_stack_t item_stack = {
        .item_stack_header = net_read_item_stack_header(packet),
    };
    if (item_stack.item_stack_header.id != 0) {
        item_stack.block_runtime_id = pck_read_var_int_signed(packet);
        net_read_var_int_bytes(packet, &item_stack.raw_extra_data_size, &item_stack.raw_extra_data);
    }
    return item_stack;
}

/*
 * NetworkItemInstanceDescriptor in mojang docs
 */
void net_write_item_stack_without_stack_id(pck_packet_t* packet, const item_stack_t item_stack) {
    net_write_item_stack_header(packet, item_stack.item_stack_header);
    if (item_stack.item_stack_header.id != 0) {
        PCK_REALLOC(packet,
            io_var_int_length(item_stack.block_runtime_id) +
            io_var_int_length(item_stack.raw_extra_data_size) + item_stack.raw_extra_data_size
        );
        pck_write_var_int_signed(packet, item_stack.block_runtime_id);
        pck_write_string(packet, item_stack.raw_extra_data, item_stack.raw_extra_data_size);
    }
}

////////////////////////////////////////////////////////////////////////////////////
/// SKIN DATA READ AND WRITE
////////////////////////////////////////////////////////////////////////////////////
skin_image_t net_read_skin_image(pck_packet_t* packet) {
    skin_image_t skin_image = {
        .width = pck_read_int32(packet),
        .height = pck_read_int32(packet)
    };
    net_read_var_int_bytes(packet, &skin_image.data_size, &skin_image.data);
    return skin_image;
}

void net_write_skin_image(pck_packet_t* packet, const skin_image_t skin_image) {
    PCK_REALLOC(packet, 8 +
        io_var_int_length(skin_image.data_size) + skin_image.data_size
    );
    pck_write_int32(packet, skin_image.width);
    pck_write_int32(packet, skin_image.height);
    pck_write_string(packet, skin_image.data, skin_image.data_size);
}

skin_animation_t net_read_skin_animation(pck_packet_t* packet) {
    const skin_animation_t skin_animation = {
        .image = net_read_skin_image(packet),
        .type = pck_read_int32(packet),
        .frames = pck_read_float32(packet),
        .expression_type = pck_read_int32(packet),
    };
    return skin_animation;
}

void net_write_skin_animation(pck_packet_t* packet, skin_animation_t skin_animation) {
    PCK_REALLOC(packet, 12);
    net_write_skin_image(packet, skin_animation.image);
    pck_write_int32(packet, skin_animation.type);
    pck_write_float32(packet, skin_animation.frames);
    pck_write_int32(packet, skin_animation.expression_type);
}

skin_persona_t net_read_skin_persona(pck_packet_t* packet) {
    skin_persona_t skin_persona = {0};
    net_read_var_int_bytes(packet, &skin_persona.piece_id_size, &skin_persona.piece_id);
    net_read_var_int_bytes(packet, &skin_persona.piece_type_size, &skin_persona.piece_type);
    net_read_var_int_bytes(packet, &skin_persona.pack_id_size, &skin_persona.pack_id);
    skin_persona.is_piece_default = pck_read_int8(packet) & 1;
    net_read_var_int_bytes(packet, &skin_persona.product_id_size, &skin_persona.product_id);
    return skin_persona;
}

void net_write_skin_persona(pck_packet_t* packet, const skin_persona_t skin_persona) {
    PCK_REALLOC(packet,
        io_var_int_length(skin_persona.piece_id_size) + skin_persona.piece_id_size +
        io_var_int_length(skin_persona.piece_type_size) + skin_persona.piece_type_size +
        io_var_int_length(skin_persona.pack_id_size) + skin_persona.pack_id_size +
        1 +
        io_var_int_length(skin_persona.product_id_size) + skin_persona.product_id_size
    );
    pck_write_string(packet, skin_persona.piece_id, skin_persona.piece_id_size);
    pck_write_string(packet, skin_persona.piece_type, skin_persona.piece_type_size);
    pck_write_string(packet, skin_persona.pack_id, skin_persona.pack_id_size);
    pck_write_int8(packet, skin_persona.is_piece_default ? 1 : 0);
    pck_write_string(packet, skin_persona.product_id, skin_persona.product_id_size);
}

skin_persona_tint_color_t net_read_skin_persona_tint_color(pck_packet_t* packet) {
    skin_persona_tint_color_t skin_persona_tint_color = {};
    net_read_var_int_bytes(packet, &skin_persona_tint_color.piece_type_size, &skin_persona_tint_color.piece_type);
    skin_persona_tint_color.color_count = pck_read_int32(packet);
    if (skin_persona_tint_color.color_count > 0) {
        for (int32_t i = 0; i < skin_persona_tint_color.color_count; i++) { //i don't care
            pck_cursor_skip(packet, pck_read_var_int(packet));
        }
    }
    return skin_persona_tint_color;
}

void net_write_skin_persona_tint_color(pck_packet_t* packet, const skin_persona_tint_color_t skin_persona_tint_color) {
    PCK_REALLOC(packet,
        io_var_int_length(skin_persona_tint_color.piece_type_size) + skin_persona_tint_color.piece_type_size
        + 4
    );
    pck_write_string(packet, skin_persona_tint_color.piece_type, skin_persona_tint_color.piece_type_size);
    pck_write_int32(packet, 0);    //TODO: implement proper color mapping
}

skin_data_t net_read_skin_data(pck_packet_t* packet, const bool skip) {
    skin_data_t skin_data = {0};
    net_read_var_int_bytes(packet, &skin_data.skin_id_size, &skin_data.skin_id);
    net_read_var_int_bytes(packet, &skin_data.play_fab_id_size, &skin_data.play_fab_id);
    net_read_var_int_bytes(packet, &skin_data.resources_patch_size, &skin_data.resources_patch);
    skin_data.skin_image = net_read_skin_image(packet);
    skin_data.animation_count = pck_read_int32(packet);
    if (skin_data.animation_count > 0) {
        if (skip) {
            for (int32_t i = 0; i < skin_data.animation_count; i++) {
                pck_cursor_skip(packet, 8);//width and height
                pck_cursor_skip(packet, pck_read_var_int(packet));
                pck_cursor_skip(packet, 12);
            }
        }else {
            skin_data.animations = (skin_animation_t *) malloc(skin_data.animation_count * sizeof(skin_animation_t));
            for (int32_t i = 0; i < skin_data.animation_count; i++) {
                skin_data.animations[i] = net_read_skin_animation(packet);
            }
        }
    }
    skin_data.cape_image = net_read_skin_image(packet);
    net_read_var_int_bytes(packet, &skin_data.geometry_data_size, &skin_data.geometry_data);
    net_read_var_int_bytes(packet, &skin_data.geometry_engine_version_size, &skin_data.geometry_engine_version);
    net_read_var_int_bytes(packet, &skin_data.animation_data_size, &skin_data.animation_data);
    net_read_var_int_bytes(packet, &skin_data.cape_id_size, &skin_data.cape_id);
    net_read_var_int_bytes(packet, &skin_data.full_skin_id_size, &skin_data.full_skin_id);
    net_read_var_int_bytes(packet, &skin_data.arm_size_size, &skin_data.arm_size);
    net_read_var_int_bytes(packet, &skin_data.skin_color_size, &skin_data.skin_color);
    skin_data.persona_count = pck_read_int32(packet);
    if (skin_data.persona_count > 0) {
        if (skip) {
            for (int32_t i = 0; i < skin_data.persona_count; i++) {
                pck_cursor_skip(packet, pck_read_var_int(packet));
                pck_cursor_skip(packet, pck_read_var_int(packet));
                pck_cursor_skip(packet, pck_read_var_int(packet));
                pck_cursor_skip(packet, 1);
                pck_cursor_skip(packet, pck_read_var_int(packet));
            }
        }else {
            skin_data.personas = (skin_persona_t *) malloc(skin_data.persona_count * sizeof(skin_persona_t));
            for (int32_t i = 0; i < skin_data.persona_count; i++) {
                skin_data.personas[i] = net_read_skin_persona(packet);
            }
        }
    }
    skin_data.persona_tint_color_count = pck_read_int32(packet);
    if (skin_data.persona_tint_color_count > 0) {
        if (skip) {
            for (int32_t i = 0; i < skin_data.persona_tint_color_count; i++) {
                pck_cursor_skip(packet, pck_read_var_int(packet));
                const int32_t skip_size = pck_read_int32(packet);
                for (int32_t j = 0; j < skip_size; j++) {
                    pck_cursor_skip(packet, pck_read_var_int(packet));
                }
            }
        }else {
            skin_data.persona_tint_colors = (skin_persona_tint_color_t *) malloc(skin_data.persona_tint_color_count * sizeof(skin_persona_tint_color_t));
            for (int32_t i = 0; i < skin_data.persona_tint_color_count; i++) {
                skin_data.persona_tint_colors[i] = net_read_skin_persona_tint_color(packet);
            }
        }
    }
    skin_data.is_premium = pck_read_int8(packet) & 1;
    skin_data.is_persona = pck_read_int8(packet) & 1;
    skin_data.is_persona_cape_classic = pck_read_int8(packet) & 1;
    skin_data.is_primary_user = pck_read_int8(packet) & 1;
    skin_data.is_override = pck_read_int8(packet) & 1;
    return skin_data;
}

void net_write_skin_data(pck_packet_t* packet, const skin_data_t skin_data) {
    PCK_REALLOC(packet,
        io_var_int_length(skin_data.skin_id_size) + skin_data.skin_id_size +
        io_var_int_length(skin_data.play_fab_id_size) + skin_data.play_fab_id_size +
        io_var_int_length(skin_data.resources_patch_size) + skin_data.resources_patch_size +
        io_var_int_length(skin_data.geometry_data_size) + skin_data.geometry_data_size +
        io_var_int_length(skin_data.geometry_engine_version_size) + skin_data.geometry_engine_version_size +
        io_var_int_length(skin_data.animation_data_size) + skin_data.animation_data_size +
        io_var_int_length(skin_data.cape_id_size) + skin_data.cape_id_size +
        io_var_int_length(skin_data.full_skin_id_size) + skin_data.full_skin_id_size +
        io_var_int_length(skin_data.arm_size_size) + skin_data.arm_size_size +
        io_var_int_length(skin_data.skin_color_size) + skin_data.skin_color_size +
        17
    );
    pck_write_string(packet, skin_data.skin_id, skin_data.skin_id_size);
    pck_write_string(packet, skin_data.play_fab_id, skin_data.play_fab_id_size);
    pck_write_string(packet, skin_data.resources_patch, skin_data.resources_patch_size);
    net_write_skin_image(packet, skin_data.skin_image);
    pck_write_int32(packet, skin_data.animation_count);
    for (int32_t i = 0; i < skin_data.animation_count; i++) {
        net_write_skin_animation(packet, skin_data.animations[i]);
    }
    net_write_skin_image(packet, skin_data.cape_image);
    pck_write_string(packet, skin_data.geometry_data, skin_data.geometry_data_size);
    pck_write_string(packet, skin_data.geometry_engine_version, skin_data.geometry_engine_version_size);
    pck_write_string(packet, skin_data.animation_data, skin_data.animation_data_size);
    pck_write_string(packet, skin_data.cape_id, skin_data.cape_id_size);
    pck_write_string(packet, skin_data.full_skin_id, skin_data.full_skin_id_size);
    pck_write_string(packet, skin_data.arm_size, skin_data.arm_size_size);
    pck_write_string(packet, skin_data.skin_color, skin_data.skin_color_size);
    pck_write_int32(packet, skin_data.persona_count);
    for (int32_t i = 0; i < skin_data.persona_count; i++) {
        net_write_skin_persona(packet, skin_data.personas[i]);
    }
    pck_write_int32(packet, skin_data.persona_tint_color_count);
    for (int32_t i = 0; i < skin_data.persona_tint_color_count; i++) {
        net_write_skin_persona_tint_color(packet, skin_data.persona_tint_colors[i]);
    }
    pck_write_int8(packet, skin_data.is_premium ? 1 : 0);
    pck_write_int8(packet, skin_data.is_persona ? 1 : 0);
    pck_write_int8(packet, skin_data.is_persona_cape_classic ? 1 : 0);
    pck_write_int8(packet, skin_data.is_primary_user ? 1 : 0);
    pck_write_int8(packet, skin_data.is_override ? 1 : 0);
}