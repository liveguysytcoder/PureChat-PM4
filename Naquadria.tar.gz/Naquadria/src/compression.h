//
// Created by kani on 6/12/25.
//

#ifndef COMPRESSION_H
#define COMPRESSION_H

#include <stdlib.h>

#include <libdeflate.h>
#include <snappy-c.h>

typedef enum  {
    COMPRESSION_ZLIB = 0x00,
    COMPRESSION_SNAPPY = 0x01,
    COMPRESSION_NONE = 0xFF
} compression_type_t;

bool zlib_decompress_buffer(const uint8_t *input_buff, size_t input_len, uint8_t **output_buff, size_t *output_size, struct libdeflate_decompressor *decompressor);

bool snappy_decompress_buffer(const uint8_t *input_buff, size_t input_len, uint8_t **output_buff, size_t *output_size);

bool zlib_compress_buffer(const uint8_t *input_buff, size_t input_len, uint8_t **output_buff, size_t *output_size, struct libdeflate_compressor *compressor);

bool snappy_compress_buffer(const uint8_t *input_buff, size_t input_len, uint8_t **output_buff, size_t *output_size);

#endif //COMPRESSION_H
