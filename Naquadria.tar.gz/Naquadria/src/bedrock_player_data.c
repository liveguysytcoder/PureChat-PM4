//
// Created by zeen on 10/9/25.
//

#include "bedrock_player_data.h"

#include "bedrock_packet_handler.h"

void create_bedrock_player(const server_context_t *server_context, bedrock_player_data_t *player, client_context_t *context) {
    *player = (bedrock_player_data_t) {
        .client_context = context,
        .compression_type = COMPRESSION_NONE,
        .game_state = GAME_NO_COMPRESSION,
        .packets_queue_size = 0,
        .packets_queue = (binary_stream_t *) malloc(0),
        .batch_packets_queue_c2p_size = 0,
        .batch_packets_queue_c2p = (binary_stream_t *) malloc(0),
        .batch_packets_queue_p2c_size = 0,
        .batch_packets_queue_p2c = (binary_stream_t *) malloc(0),
        .batch_packets_queue_s2p_size = 0,
        .batch_packets_queue_s2p = (binary_stream_t *) malloc(0),
        .batch_packets_queue_p2s_size = 0,
        .batch_packets_queue_p2s = (binary_stream_t *) malloc(0),
    };
    player->encrypted_block = malloc(sizeof(player_cipher_block_t));
    player->encrypted_block->enabled = false;
    player->encrypted_block->decrypt_block_counter = 0;
    player->encrypted_block->encrypt_block_counter = 0;
    player->encrypted_block->server_key = server_context->server_key;
    pthread_mutex_init(&player->batch_packets_queue_client_lock, nullptr);
    pthread_mutex_init(&player->batch_packets_queue_server_lock, nullptr);
    pthread_create(&player->thread, nullptr, player_packet_precessing_thread, player);
}

void cleanup_bedrock_player(const server_context_t *server_context, bedrock_player_data_t *player) {
    do {
    }while (player->game_state != GAME_DISCONNECTED);
    cleanup_aes_256_ctr(player->encrypted_block);
    free(player->encrypted_block);
    pthread_mutex_destroy(&player->batch_packets_queue_client_lock);
    pthread_mutex_destroy(&player->batch_packets_queue_server_lock);
    pthread_join(player->thread, nullptr);
    free(player);
}

bool is_have_bedrock_player(const server_context_t *server_context, const non_connected_t *context) {
    for (size_t i = 0; i < server_context->bedrock_players_size; i++)
        if (server_context->bedrock_players[i].client_context->basic_info.hash == context->hash)
            return true;
    return false;
}

void push_batch_packets_queue_c2p(bedrock_player_data_t *player, const binary_stream_t stream) {
    pthread_mutex_lock(&player->batch_packets_queue_client_lock);
    player->batch_packets_queue_c2p_size++;
    player->batch_packets_queue_c2p = (binary_stream_t *) reallocarray(player->batch_packets_queue_c2p, player->batch_packets_queue_c2p_size, sizeof(binary_stream_t));
    player->batch_packets_queue_c2p[player->batch_packets_queue_c2p_size - 1] = stream;
    pthread_mutex_unlock(&player->batch_packets_queue_client_lock);
}

binary_stream_t get_batch_packets_queue_c2p(bedrock_player_data_t *player) {
    binary_stream_t stream = {};
    pthread_mutex_lock(&player->batch_packets_queue_client_lock);
    if (player->batch_packets_queue_c2p_size > 0) {
        stream = player->batch_packets_queue_c2p[0];
        player->batch_packets_queue_c2p_size--;
        if (player->batch_packets_queue_c2p_size > 0) {
            memmove(player->batch_packets_queue_c2p, &player->batch_packets_queue_c2p[1], player->batch_packets_queue_c2p_size * sizeof(binary_stream_t));
            auto const new_ptr = (binary_stream_t *) reallocarray(player->batch_packets_queue_c2p, player->batch_packets_queue_c2p_size, sizeof(binary_stream_t));
            player->batch_packets_queue_c2p = new_ptr;
        }else {
            free(player->batch_packets_queue_c2p);
            player->batch_packets_queue_c2p = nullptr;
        }
    }
    pthread_mutex_unlock(&player->batch_packets_queue_client_lock);
    return stream;
}

void push_batch_packets_queue_p2c(bedrock_player_data_t *player, const binary_stream_t stream) {
    pthread_mutex_lock(&player->batch_packets_queue_client_lock);
    player->batch_packets_queue_p2c_size++;
    player->batch_packets_queue_p2c = (binary_stream_t *) reallocarray(player->batch_packets_queue_p2c, player->batch_packets_queue_p2c_size, sizeof(binary_stream_t));
    player->batch_packets_queue_p2c[player->batch_packets_queue_p2c_size - 1] = stream;
    pthread_mutex_unlock(&player->batch_packets_queue_client_lock);
}

binary_stream_t get_batch_packets_queue_p2c(bedrock_player_data_t *player) {
    binary_stream_t stream = {};
    pthread_mutex_lock(&player->batch_packets_queue_client_lock);
    if (player->batch_packets_queue_p2c_size > 0) {
        stream = player->batch_packets_queue_p2c[0];
        player->batch_packets_queue_p2c_size--;
        if (player->batch_packets_queue_p2c_size > 0) {
            memmove(player->batch_packets_queue_p2c, &player->batch_packets_queue_p2c[1], player->batch_packets_queue_p2c_size * sizeof(binary_stream_t));
            auto const new_ptr = (binary_stream_t *) reallocarray(player->batch_packets_queue_p2c, player->batch_packets_queue_p2c_size, sizeof(binary_stream_t));
            player->batch_packets_queue_p2c = new_ptr;
        }else {
            free(player->batch_packets_queue_p2c);
            player->batch_packets_queue_p2c = nullptr;
        }
    }
    pthread_mutex_unlock(&player->batch_packets_queue_client_lock);
    return stream;
}

void push_batch_packets_queue_p2s(bedrock_player_data_t *player, const binary_stream_t stream) {
    pthread_mutex_lock(&player->batch_packets_queue_server_lock);
    player->batch_packets_queue_p2s_size++;
    player->batch_packets_queue_p2s = (binary_stream_t *) reallocarray(player->batch_packets_queue_p2s, player->batch_packets_queue_p2s_size, sizeof(binary_stream_t));
    player->batch_packets_queue_p2s[player->batch_packets_queue_p2s_size - 1] = stream;
    pthread_mutex_unlock(&player->batch_packets_queue_server_lock);
}

binary_stream_t get_batch_packets_queue_p2s(bedrock_player_data_t *player) {
    binary_stream_t stream = {};
    pthread_mutex_lock(&player->batch_packets_queue_server_lock);
    if (player->batch_packets_queue_p2s_size > 0) {
        stream = player->batch_packets_queue_p2s[0];
        player->batch_packets_queue_p2s_size--;
        if (player->batch_packets_queue_p2s_size > 0) {
            memmove(player->batch_packets_queue_p2s, &player->batch_packets_queue_p2s[1], player->batch_packets_queue_p2s_size * sizeof(binary_stream_t));
            auto const new_ptr = (binary_stream_t *) reallocarray(player->batch_packets_queue_p2s, player->batch_packets_queue_p2s_size, sizeof(binary_stream_t));
            player->batch_packets_queue_p2s = new_ptr;
        }else {
            free(player->batch_packets_queue_p2s);
            player->batch_packets_queue_p2s = nullptr;
        }
    }
    pthread_mutex_unlock(&player->batch_packets_queue_server_lock);
    return stream;
}

void push_batch_packets_queue_s2p(bedrock_player_data_t *player, const binary_stream_t stream) {
    pthread_mutex_lock(&player->batch_packets_queue_server_lock);
    player->batch_packets_queue_s2p_size++;
    player->batch_packets_queue_s2p = (binary_stream_t *) reallocarray(player->batch_packets_queue_s2p, player->batch_packets_queue_s2p_size, sizeof(binary_stream_t));
    player->batch_packets_queue_s2p[player->batch_packets_queue_s2p_size - 1] = stream;
    pthread_mutex_unlock(&player->batch_packets_queue_server_lock);
}

binary_stream_t get_batch_packets_queue_s2p(bedrock_player_data_t *player) {
    binary_stream_t stream = {};
    pthread_mutex_lock(&player->batch_packets_queue_server_lock);
    if (player->batch_packets_queue_s2p_size > 0) {
        stream = player->batch_packets_queue_s2p[0];
        player->batch_packets_queue_s2p_size--;
        if (player->batch_packets_queue_s2p_size > 0) {
            memmove(player->batch_packets_queue_s2p, &player->batch_packets_queue_s2p[1], player->batch_packets_queue_s2p_size * sizeof(binary_stream_t));
            auto const new_ptr = (binary_stream_t *) reallocarray(player->batch_packets_queue_s2p, player->batch_packets_queue_s2p_size, sizeof(binary_stream_t));
            player->batch_packets_queue_s2p = new_ptr;
        }else {
            free(player->batch_packets_queue_s2p);
            player->batch_packets_queue_s2p = nullptr;
        }
    }
    pthread_mutex_unlock(&player->batch_packets_queue_server_lock);
    return stream;
}