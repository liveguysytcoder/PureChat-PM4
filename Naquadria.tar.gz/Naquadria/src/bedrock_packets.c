//
// Created by zeen on 9/5/25.
//
#include "bedrock_packets.h"
#include "binarystream.h"
#include "bedrock_packet_def.h"
#include "bedrock_packet_ids.h"
//#blameshoghi

login_packet_t read_login_packet_t(pck_packet_t* packet, minecraft_protocol_version_t version) {
    login_packet_t login_packet = {
        .protocol_version = io_switch_int32((uint32_t) pck_read_int32(packet))
    };
    const uint32_t size = pck_read_var_int(packet);
    if (size != pck_left_over(packet)) {
        return login_packet;
    }
    login_packet.auth_info_json_size = pck_read_int32(packet);
    login_packet.auth_info_json = malloc(login_packet.auth_info_json_size);
    pck_read_bytes(packet, login_packet.auth_info_json, login_packet.auth_info_json_size);
    login_packet.client_data_jwt_size = pck_read_int32(packet);
    login_packet.client_data_jwt = malloc(login_packet.client_data_jwt_size);
    pck_read_bytes(packet, login_packet.client_data_jwt, login_packet.client_data_jwt_size);
    return login_packet;
}

void write_server_to_client_handshake_packet_t(pck_packet_t* packet, const server_to_client_handshake_packet_t server_to_client_handshake_packet, minecraft_protocol_version_t version){
    PCK_REALLOC(packet, server_to_client_handshake_packet.jwt_size + io_var_int_length(server_to_client_handshake_packet.jwt_size));
    pck_write_string(packet, server_to_client_handshake_packet.jwt, server_to_client_handshake_packet.jwt_size);
}

void write_disconnect_packet_t(pck_packet_t* packet, const disconnect_packet_t disconnect_packet, minecraft_protocol_version_t version){
    PCK_REALLOC(packet, io_var_int_length(disconnect_packet.reason) + 1);
    pck_write_var_int(packet, disconnect_packet.reason);
    bool have_reason = false;
    have_reason |= disconnect_packet.message_size > 0;
    have_reason |= disconnect_packet.filtered_message_size > 0;
    pck_write_int8(packet, have_reason ? 0 : 1);
    if (have_reason) {
        PCK_REALLOC(packet,
            disconnect_packet.message_size + io_var_int_length(disconnect_packet.message_size) +
            disconnect_packet.filtered_message_size + io_var_int_length(disconnect_packet.filtered_message_size)
        );
        pck_write_string(packet, disconnect_packet.message, disconnect_packet.message_size);
        pck_write_string(packet, disconnect_packet.filtered_message, disconnect_packet.filtered_message_size);
    }
}

disconnect_packet_t read_disconnect_packet_t(pck_packet_t* packet, minecraft_protocol_version_t version) {
    disconnect_packet_t disconnect_packet = {
        .reason = pck_read_var_int_signed(packet),
    };
    if (pck_read_int8(packet) == 0) {
        net_read_var_int_bytes(packet, &disconnect_packet.message_size, &disconnect_packet.message);
        net_read_var_int_bytes(packet, &disconnect_packet.filtered_message_size, &disconnect_packet.filtered_message);
    }
    return disconnect_packet;
}

void write_resource_packs_info_packet_t(pck_packet_t* packet, const resource_packs_info_packet_t resource_packs_info_packet, minecraft_protocol_version_t version) {
    PCK_REALLOC(packet,
        resource_packs_info_packet.world_template_version_size + io_var_int_length(resource_packs_info_packet.world_template_version_size) +
        26
    );
    pck_write_int8(packet, resource_packs_info_packet.must_accept ? 1 : 0);
    pck_write_int8(packet, resource_packs_info_packet.has_addons ? 1 : 0);
    pck_write_int8(packet, resource_packs_info_packet.has_scripts ? 1 : 0);
    pck_write_int8(packet, resource_packs_info_packet.force_disable_vibrant_visuals ? 1 : 0);
    net_write_uuid(packet, resource_packs_info_packet.world_template_id);
    pck_write_string(packet, resource_packs_info_packet.world_template_version, resource_packs_info_packet.world_template_version_size);
    pck_write_int16(packet, (int16_t) resource_packs_info_packet.resource_packs_count);
    for (uint16_t i = 0; i < resource_packs_info_packet.resource_packs_count; i++) {
        net_write_resource_pack_info_entry(packet, resource_packs_info_packet.resource_packs[i]);
    }
}

void write_resource_pack_stack_packet_t(pck_packet_t* packet, const resource_pack_stack_packet_t resource_pack_stack_packet, minecraft_protocol_version_t version) {
    PCK_REALLOC(packet,
        resource_pack_stack_packet.base_game_version_size + io_var_int_length(resource_pack_stack_packet.base_game_version_size) +
        15
    );
    pck_write_int8(packet, resource_pack_stack_packet.must_accept ? 1 : 0);
    pck_write_int32(packet, (int32_t) resource_pack_stack_packet.behavior_pack_stack_size);
    for (uint32_t i = 0; i < resource_pack_stack_packet.behavior_pack_stack_size; ++i) {
        net_write_resource_pack_stack_entry(packet, resource_pack_stack_packet.behavior_pack_stack[i]);
    }
    pck_write_int32(packet, (int32_t) resource_pack_stack_packet.resource_pack_stack_size);
    for (uint32_t i = 0; i < resource_pack_stack_packet.resource_pack_stack_size; ++i) {
        net_write_resource_pack_stack_entry(packet, resource_pack_stack_packet.resource_pack_stack[i]);
    }
    pck_write_string(packet, resource_pack_stack_packet.base_game_version, resource_pack_stack_packet.base_game_version_size);
    pck_write_int32(packet, (int32_t) resource_pack_stack_packet.experiments_size);
    for (uint32_t i = 0; i < resource_pack_stack_packet.experiments_size; ++i) {
        net_write_experiment_entry(packet, resource_pack_stack_packet.experiments[i]);
    }
    pck_write_int8(packet, resource_pack_stack_packet.has_previously_used_experiments ? 1 : 0);
    pck_write_int8(packet, resource_pack_stack_packet.use_vanilla_editor_packs ? 1 : 0);
}

resource_pack_client_response_packet_t read_resource_pack_client_response_packet_t(pck_packet_t* packet, minecraft_protocol_version_t version) {
    resource_pack_client_response_packet_t resource_pack_client_response_packet = {
        .status = pck_read_int8(packet),
        .pack_ids_size = (uint16_t) pck_read_int16(packet),
    };
    if (resource_pack_client_response_packet.pack_ids_size == 0)
        return resource_pack_client_response_packet;
    resource_pack_client_response_packet.pack_ids = (binary_stream_t *) malloc(resource_pack_client_response_packet.pack_ids_size * sizeof(binary_stream_t));
    for (uint16_t i = 0; i < resource_pack_client_response_packet.pack_ids_size; ++i) {
        net_read_var_int_bytes(packet, (uint32_t *) &resource_pack_client_response_packet.pack_ids[i].size, &resource_pack_client_response_packet.pack_ids[i].buffer);
    }
    return resource_pack_client_response_packet;
}

void write_resource_pack_data_info_packet_t(pck_packet_t* packet, const resource_pack_data_info_packet_t resource_pack_data_info_packet, minecraft_protocol_version_t version) {
    PCK_REALLOC(packet,
        resource_pack_data_info_packet.pack_id_size + io_var_int_length(resource_pack_data_info_packet.pack_id_size) +
        resource_pack_data_info_packet.sha256_size + io_var_int_length(resource_pack_data_info_packet.sha256_size) +
        18
    );
    pck_write_string(packet, resource_pack_data_info_packet.pack_id, resource_pack_data_info_packet.pack_id_size);
    pck_write_int32(packet, (int32_t) resource_pack_data_info_packet.max_chunk_size);
    pck_write_int32(packet, (int32_t) resource_pack_data_info_packet.chunk_count);
    pck_write_int64(packet, (int64_t) resource_pack_data_info_packet.compressed_pack_size);
    pck_write_string(packet, resource_pack_data_info_packet.sha256, resource_pack_data_info_packet.sha256_size);
    pck_write_int8(packet, resource_pack_data_info_packet.is_premium ? 1 : 0);
    pck_write_int8(packet, (int8_t) resource_pack_data_info_packet.pack_type);
}

void write_resource_pack_chunk_data_packet_t(pck_packet_t* packet, const resource_pack_chunk_data_packet_t resource_pack_chunk_data_packet, minecraft_protocol_version_t version) {
    PCK_REALLOC(packet,
        resource_pack_chunk_data_packet.pack_id_size + io_var_int_length(resource_pack_chunk_data_packet.pack_id_size) +
        resource_pack_chunk_data_packet.data_size + io_var_int_length(resource_pack_chunk_data_packet.data_size) +
        12
    );
    pck_write_string(packet, resource_pack_chunk_data_packet.pack_id, resource_pack_chunk_data_packet.pack_id_size);
    pck_write_int32(packet, (int32_t) resource_pack_chunk_data_packet.chunk_index);
    pck_write_int64(packet, (int64_t) resource_pack_chunk_data_packet.offset);
    pck_write_string(packet, resource_pack_chunk_data_packet.data, resource_pack_chunk_data_packet.data_size);
}

resource_pack_chunk_request_packet_t read_resource_pack_chunk_request_packet_t(pck_packet_t* packet, minecraft_protocol_version_t version) {
    resource_pack_chunk_request_packet_t resource_pack_chunk_request_packet = {};
    net_read_var_int_bytes(packet, &resource_pack_chunk_request_packet.pack_id_size, &resource_pack_chunk_request_packet.pack_id);
    resource_pack_chunk_request_packet.chunk_index = (uint32_t) pck_read_int32(packet);
    return resource_pack_chunk_request_packet;
}

request_network_settings_packet_t read_network_settings_packet(pck_packet_t* packet) {
    return (request_network_settings_packet_t) {
        .protocol_version = io_switch_int32((uint32_t) pck_read_int32(packet)),
    };
}

void write_network_settings_packet_t(pck_packet_t *packet, const network_settings_packet_t network_settings_packet, minecraft_protocol_version_t version){
    pck_write_int16(packet, network_settings_packet.compression_threshold);
    pck_write_int16(packet, network_settings_packet.compression_algorithm);
    pck_write_int8(packet, network_settings_packet.enable_client_throttling ? 1 : 0);
    pck_write_int8(packet, network_settings_packet.client_throttle_threshold);
    pck_write_float32(packet, network_settings_packet.client_throttle_scalar);
}