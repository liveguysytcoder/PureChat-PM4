//
// Created by zeen on 10/8/25.
//

#include "bedrock_packet_handler.h"

#include "debug.h"
#include "base64.h"
#include "bedrock_packets.h"
#include "bedrock_packet_def.h"
#include "bedrock_packet_ids.h"
#include "bedrock_player_data.h"
#include "raknet_packet_handler.h"

void push_packet_to_queue(const pck_packet_t* packet, bedrock_player_data_t* player_data) {
    player_data->packets_queue_size++;
    player_data->packets_queue = (binary_stream_t *) reallocarray(player_data->packets_queue, player_data->packets_queue_size, sizeof(binary_stream_t));
    player_data->packets_queue[player_data->packets_queue_size - 1] = packet->stream;
}

bool is_valid_c2p_packet(const uint16_t packet_id, const bedrock_player_play_state_t state) {
    // if (state == GAME_NO_COMPRESSION) {
    //     return packet_id == REQUEST_NETWORK_SETTINGS_PACKET;
    // }
    // if (state == GAME_COMPRESSION) {
    //     return packet_id == LOGIN_PACKET;
    // }
    // if (state == GAME_ENCRYPTION) {
    //     return packet_id == CLIENT_TO_SERVER_HANDSHAKE_PACKET;
    // }
    return true;
}

const packet_handler_func dispatch_table[] = {
    [LOGIN_PACKET] = handle_c2p_login_packet,
    [CLIENT_TO_SERVER_HANDSHAKE_PACKET] = handle_c2p_client_to_server_handshake_packet,
    [DISCONNECT_PACKET] = handle_c2p_no_functionality_packet,
    [RESOURCE_PACK_CLIENT_RESPONSE_PACKET] = handle_c2p_resource_pack_client_response_packet,
    [TEXT_PACKET] = handle_c2p_text_packet,
    [MOVE_PLAYER_PACKET] = handle_c2p_move_player_packet,
    [ACTOR_EVENT_PACKET] = handle_c2p_actor_event_packet,
    [INVENTORY_TRANSACTION_PACKET] = handle_c2p_inventory_transaction_packet,
    [MOB_EQUIPMENT_PACKET] = handle_c2p_mob_equipment_packet,
    [MOB_ARMOR_EQUIPMENT_PACKET] = handle_c2p_mob_armor_equipment_packet,
    [INTERACT_PACKET] = handle_c2p_interact_packet,
    [BLOCK_PICK_REQUEST_PACKET] = handle_c2p_block_pick_request_packet,
    [ACTOR_PICK_REQUEST_PACKET] = handle_c2p_actor_pick_request_packet,
    [PLAYER_ACTION_PACKET] = handle_c2p_player_action_packet,
    [SET_ACTOR_DATA_PACKET] = handle_c2p_set_actor_data_packet, //??
    [SET_ACTOR_MOTION_PACKET] = handle_c2p_set_actor_motion_packet,
    [SET_ACTOR_LINK_PACKET] = handle_c2p_set_actor_link_packet,
    [ANIMATE_PACKET] = handle_c2p_animate_packet,
    [RESPAWN_PACKET] = handle_c2p_respawn_packet,
    [CONTAINER_CLOSE_PACKET] = handle_c2p_container_close_packet,
    [PLAYER_HOTBAR_PACKET] = handle_c2p_player_hotbar_packet,
    [GUI_DATA_PICK_ITEM_PACKET] = handle_c2p_gui_data_pick_item_packet,
    [BLOCK_ACTOR_DATA_PACKET] = handle_c2p_block_actor_data_packet,
    [SET_DIFFICULTY_PACKET] = handle_c2p_set_difficulty_packet,
    [SET_PLAYER_GAME_TYPE_PACKET] = handle_c2p_set_player_game_type_packet,
    [SIMPLE_EVENT_PACKET] = handle_c2p_simple_event_packet, //??
    [MAP_INFO_REQUEST_PACKET] = handle_c2p_map_info_request_packet,
    [REQUEST_CHUNK_RADIUS_PACKET] = handle_c2p_request_chunk_radius_packet,
    [BOSS_EVENT_PACKET] = handle_c2p_no_functionality_packet, //??
    [SHOW_CREDITS_PACKET] = handle_c2p_show_credits_packet,
    [COMMAND_REQUEST_PACKET] = handle_c2p_command_request_packet,
    [COMMAND_BLOCK_UPDATE_PACKET] = handle_c2p_command_block_update_packet,
    [RESOURCE_PACK_CHUNK_REQUEST_PACKET] = handle_c2p_resource_pack_chunk_request_packet,
    [STRUCTURE_BLOCK_UPDATE_PACKET] = handle_c2p_structure_block_update_packet,
    [PURCHASE_RECEIPT_PACKET] = handle_c2p_purchase_receipt_packet, //uhh
    [PLAYER_SKIN_PACKET] = handle_c2p_player_skin_packet,
    [SUB_CLIENT_LOGIN_PACKET] = handle_c2p_sub_client_login_packet, //TODO
    [BOOK_EDIT_PACKET] = handle_c2p_book_edit_packet,
    [NPC_REQUEST_PACKET] = handle_c2p_npc_request_packet,
    [MODAL_FORM_RESPONSE_PACKET] = handle_c2p_modal_form_response_packet,
    [SERVER_SETTINGS_RESPONSE_PACKET] = handle_c2p_server_settings_response_packet,
    [SET_DEFAULT_GAME_TYPE_PACKET] = handle_c2p_set_default_game_type_packet,
    [LAB_TABLE_PACKET] = handle_c2p_no_functionality_packet,
    [NETWORK_STACK_LATENCY_PACKET] = handle_c2p_network_stack_latency_packet,
    [LEVEL_SOUND_EVENT_PACKET] = handle_c2p_level_sound_event_packet,
    [LECTERN_UPDATE_PACKET] = handle_c2p_lectern_update_packet,
    [CLIENT_CACHE_STATUS_PACKET] = handle_c2p_client_cache_status_packet,
    [MAP_CREATE_LOCKED_COPY_PACKET] = handle_c2p_map_create_locked_copy_packet,
    [STRUCTURE_TEMPLATE_DATA_REQUEST_PACKET] = handle_c2p_structure_template_data_request_packet,
    [CLIENT_CACHE_BLOB_STATUS_PACKET] = handle_c2p_client_cache_blob_status_packet,
    [EMOTE_PACKET] = handle_c2p_emote_packet,
    [MULTIPLAYER_SETTINGS_PACKET] = handle_c2p_multiplayer_settings_packet,
    [SETTINGS_COMMAND_PACKET] = handle_c2p_settings_command_packet,
    [ANVIL_DAMAGE_PACKET] = handle_c2p_no_functionality_packet, //??
    [PLAYER_AUTH_INPUT_PACKET] = handle_c2p_player_auth_input_packet,
    [ITEM_STACK_REQUEST_PACKET] = handle_c2p_item_stack_request_packet,
    [EMOTE_LIST_PACKET] = handle_c2p_emote_list_packet,
    [POSITION_TRACKING_D_B_CLIENT_REQUEST_PACKET] = handle_c2p_position_tracking_d_b_client_request_packet,
    [DEBUG_INFO_PACKET] = handle_c2p_debug_info_packet, //umm
    [PACKET_VIOLATION_WARNING_PACKET] = handle_c2p_packet_violation_packet,
    [CREATE_PHOTO_PACKET] = handle_c2p_create_photo_packet,
    [SUB_CHUNK_REQUEST_PACKET] = handle_c2p_sub_chunk_request_packet,
    [SCRIPT_MESSAGE_PACKET] = handle_c2p_script_message_packet,
    [CHANGE_MOB_PROPERTY_PACKET] = handle_c2p_change_mob_property_packet, //umm
    [REQUEST_ABILITY_PACKET] = handle_c2p_request_ability_packet,
    [REQUEST_PERMISSIONS_PACKET] = handle_c2p_request_permissions_packet,
    [EDITOR_NETWORK_PACKET] = handle_c2p_editor_network_packet, //TODO
    [REQUEST_NETWORK_SETTINGS_PACKET] = handle_c2p_request_network_settings_packet,
    [GAME_TEST_REQUEST_PACKET] = handle_c2p_game_test_request_packet,
    [0xC8] = handle_c2p_not_implemented_packet, //PYRPC
    [OPEN_SIGN_PACKET] = handle_c2p_open_sign_packet,
    [PLAYER_TOGGLE_CRAFTER_SLOT_REQUEST_PACKET] = handle_c2p_player_toggle_crafter_slot_request_packet,//2
    [SET_PLAYER_INVENTORY_OPTIONS_PACKET] = handle_c2p_set_player_inventory_options_packet,//3
    [SERVERBOUND_LOADING_SCREEN_PACKET] = handle_c2p_serverbound_loading_screen_packet,//8
    [SERVERBOUND_DIAGNOSTICS_PACKET] = handle_c2p_serverbound_diagnostics_packet,//b
    [CLIENT_CAMERA_AIM_ASSIST_PACKET] = handle_c2p_client_camera_aim_assist_packet,//1
    [CLIENT_MOVEMENT_PREDICTION_SYNC_PACKET] = handle_c2p_client_movement_prediction_sync_packet,//2
    [UPDATE_CLIENT_OPTIONS_PACKET] = handle_c2p_update_client_options_packet,//3
    [SERVERBOUND_PACK_SETTING_CHANGE_PACKET] = handle_c2p_serverbound_pack_setting_change_packet,//9
};

void handle_c2p_no_functionality_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
}
void handle_c2p_not_implemented_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
}
void handle_c2p_forward_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
}
void handle_c2p_login_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    const login_packet_t login_packet = read_login_packet_t(packet, player_data->protocol_version);
    printf("LOGIN_PACKET\n");
    printf("%d\n", login_packet.protocol_version);
    const cJSON *auth = cJSON_ParseWithLength((char *)login_packet.auth_info_json, login_packet.auth_info_json_size);
    auto const type = cJSON_GetNumberValue(cJSON_GetObjectItem(auth, "AuthenticationType"));
    unsigned char *current_public_key = nullptr;
    pck_packet_t *respond = pck_create(1);
    if (type == 0) {
        bool trust = true;
        auto const cert = cJSON_GetStringValue(cJSON_GetObjectItem(auth, "Certificate"));
        auto const token = cJSON_GetStringValue(cJSON_GetObjectItem(auth, "Token"));
        // const jwt_data_t openid_token = jwt_decode_segments(token, strlen(token));
        // debug_byte_buffer((uint8_t *)token, strlen(token));
        printf("%s\n", token);
        const cJSON *chain = cJSON_GetObjectItem(cJSON_Parse(cert), "chain");
        auto const jwt0_raw = cJSON_GetStringValue(cJSON_GetArrayItem(chain, 0));
        auto const jwt1_raw = cJSON_GetStringValue(cJSON_GetArrayItem(chain, 1));
        auto const jwt2_raw = cJSON_GetStringValue(cJSON_GetArrayItem(chain, 2));
        const jwt_data_t jwt0 = jwt_decode_segments(jwt0_raw, strlen(jwt0_raw));
        const jwt_data_t jwt1 = jwt_decode_segments(jwt1_raw, strlen(jwt1_raw));
        const jwt_data_t jwt2 = jwt_decode_segments(jwt2_raw, strlen(jwt2_raw));
        trust &= phd_check_jwt_data(&jwt0, &current_public_key, 0);
        trust &= phd_check_jwt_data(&jwt1, &current_public_key, 1);
        trust &= phd_check_jwt_data(&jwt2, &current_public_key, 2);
        const jwt_data_t jwt3 = jwt_decode_segments((char *)login_packet.client_data_jwt, login_packet.client_data_jwt_size);
        size_t decoded_len;
        auto const payload_decoded = (char *) b64url_decode_with_alloc((const uint8_t *) jwt3.raw_jwt.value + jwt3.part1_end + 1, jwt3.part2_end - (jwt3.part1_end + 1), &decoded_len);
        cJSON *payload_doc = cJSON_ParseWithLength(payload_decoded, decoded_len);
        for (int i = 0; i < cJSON_GetArraySize(payload_doc); i++) {
            printf("%s\n", cJSON_Print(cJSON_GetArrayItem(payload_doc, i)));
        }
        trust &= phd_check_jwt_data(&jwt3, &current_public_key, 3);
        if (!trust) {
            goto login_FAIL;
        }
    } else {
        goto login_FAIL;
    }
    setup_encryption(&current_public_key, 120, player_data->encrypted_block);
    phd_send_encryption_request(player_data->encrypted_block);
    const server_to_client_handshake_packet_t server_to_client_handshake_packet = {
        .jwt = player_data->encrypted_block->shared_secret,
        .jwt_size = player_data->encrypted_block->shared_secret_size
    };
    pck_write_var_int(respond, SERVER_TO_CLIENT_HANDSHAKE_PACKET);
    write_server_to_client_handshake_packet_t(respond, server_to_client_handshake_packet, player_data->protocol_version);
    push_packet_to_queue(respond, player_data);
    return;
login_FAIL:
    disconnect_packet_t disconnect_packet = {
        .reason = 0,
    };
    constexpr char lol[] = "invalid login data";
    disconnect_packet.message_size = strlen(lol);
    disconnect_packet.message = malloc(disconnect_packet.message_size);
    memcpy(disconnect_packet.message, lol, disconnect_packet.message_size);
    pck_write_var_int(respond, DISCONNECT_PACKET);
    write_disconnect_packet_t(respond, disconnect_packet, player_data->protocol_version);
    free(disconnect_packet.message);
    debug_byte_buffer(respond->stream.buffer, respond->stream.size);
    push_packet_to_queue(respond, player_data);
}
void handle_c2p_client_to_server_handshake_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    printf("CLIENT_TO_SERVER_HANDSHAKE_PACKET\n");
    // pck_packet_t *respond = pck_create(5);
    // pck_write_var_int(respond, PLAY_STATUS_PACKET);
    // pck_write_int32(respond, PLAY_STATUS_LOGIN_SUCCESS);
    // push_packet_to_queue(respond, player_data);
    pck_packet_t *respond = pck_create(1);
    disconnect_packet_t disconnect_packet = {
        .message_size = 24000000,
        .reason = 0,
    };
    disconnect_packet.message = malloc(disconnect_packet.message_size);
    for (unsigned int i = 0; i < disconnect_packet.message_size; i++) {
        disconnect_packet.message[i] = '@' + (i % 32);
    }
    // constexpr char lol[] = "that works";
    // disconnect_packet.message_size = strlen(lol);
    // disconnect_packet.message = malloc(disconnect_packet.message_size);
    // memcpy(disconnect_packet.message, lol, disconnect_packet.message_size);
    pck_write_var_int(respond, DISCONNECT_PACKET);
    write_disconnect_packet_t(respond, disconnect_packet, player_data->protocol_version);
    free(disconnect_packet.message);
    // debug_byte_buffer(respond->stream.buffer, respond->stream.size);
    push_packet_to_queue(respond, player_data);
    // pck_packet_t *resource_packs_info = pck_create(1);
    // pck_write_var_int(resource_packs_info, RESOURCE_PACKS_INFO_PACKET);
    // resource_packs_info_packet_t resource_packs_info_data = {};
    // write_resource_packs_info_packet_t(resource_packs_info, resource_packs_info_data);
    // push_packet_to_queue(resource_packs_info, player_data);
}
void handle_c2p_resource_pack_client_response_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_text_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_move_player_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_actor_event_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_inventory_transaction_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_mob_equipment_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_mob_armor_equipment_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_interact_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_block_pick_request_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_actor_pick_request_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_player_action_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_set_actor_data_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_set_actor_motion_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_set_actor_link_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_animate_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_respawn_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_container_close_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_player_hotbar_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_gui_data_pick_item_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_block_actor_data_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_set_difficulty_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_set_player_game_type_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_simple_event_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_map_info_request_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_request_chunk_radius_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_show_credits_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_command_request_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_command_block_update_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_resource_pack_chunk_request_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_structure_block_update_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_purchase_receipt_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_player_skin_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_sub_client_login_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_book_edit_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_npc_request_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_modal_form_response_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_server_settings_response_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_set_default_game_type_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_network_stack_latency_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_level_sound_event_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_lectern_update_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_client_cache_status_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_map_create_locked_copy_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_structure_template_data_request_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_client_cache_blob_status_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_emote_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_multiplayer_settings_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_settings_command_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_player_auth_input_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_item_stack_request_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_emote_list_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_position_tracking_d_b_client_request_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_debug_info_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_packet_violation_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_create_photo_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_sub_chunk_request_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_script_message_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_change_mob_property_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_request_ability_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_request_permissions_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_editor_network_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_request_network_settings_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    printf("REQUEST_NETWORK_SETTINGS_PACKET %d\n", read_network_settings_packet(packet).protocol_version);
    pck_packet_t *net = pck_create(12);
    pck_write_var_int(net, NETWORK_SETTINGS_PACKET);
    write_network_settings_packet_t(net, (network_settings_packet_t) {
        .compression_threshold = 1,
        .compression_algorithm = COMPRESSION_SNAPPY
    }, player_data->protocol_version);
    push_packet_to_queue(net, player_data);
    player_data->compression_type = COMPRESSION_SNAPPY;
}
void handle_c2p_game_test_request_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_open_sign_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_player_toggle_crafter_slot_request_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_set_player_inventory_options_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_serverbound_loading_screen_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_serverbound_diagnostics_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_client_camera_aim_assist_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_client_movement_prediction_sync_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_update_client_options_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}
void handle_c2p_serverbound_pack_setting_change_packet(pck_packet_t *packet, bedrock_player_data_t* player_data) {
    
}

void decode_games_packets(pck_packet_t* packet, bedrock_player_data_t* player_data) {
    const uint32_t header = pck_read_var_int(packet);
    const uint16_t packet_id = header & PACKET_PID_MASK;
    const uint8_t sender_sub_id = (header >> PACKET_SENDER_SUB_CLIENT_ID_SHIFT) & PACKET_SUB_CLIENT_ID_MASK;
    const uint8_t recipient_sub_id = (header >> PACKET_RECIPIENT_SUB_CLIENT_ID_SHIFT) & PACKET_SUB_CLIENT_ID_MASK;
    printf("packet_id: %u (", packet_id);
    print_uint32_base2_debug(packet_id, true);
    printf(") sender_sub_id: %u ", sender_sub_id);
    printf("recipient_sub_id %u\n", recipient_sub_id);
    if (!is_valid_c2p_packet(packet_id, player_data->game_state))
        return;
    if (dispatch_table[packet_id] == nullptr) return;
    dispatch_table[packet_id](packet, player_data);
    debug_byte_buffer(packet->stream.buffer + packet->cursor, packet->stream.size - packet->cursor);
}

void decode_batches_packet(const binary_stream_t batch, bedrock_player_data_t* player_data) {
    pck_packet_t raw_packet = {
        .stream.buffer = batch.buffer + 1,
        .stream.size = batch.size - 1,
    };
    if (player_data->game_state >= GAME_ENCRYPTION && player_data->game_state != GAME_DISCONNECTED && player_data->encrypted_block->enabled) {
        uint8_t* out_buffer;
        size_t out_size;
        if (decrypt_packet_buffer(raw_packet.stream.buffer, raw_packet.stream.size, &out_buffer, &out_size, player_data->encrypted_block)) {
            raw_packet.stream.buffer = out_buffer;
            raw_packet.stream.size = out_size;
        }
    }
    if (player_data->game_state != GAME_NO_COMPRESSION) {
        debug_byte_buffer(raw_packet.stream.buffer + 6000, 300);
        const int8_t type = pck_read_int8(&raw_packet);
        uint8_t* out_buffer;
        size_t out_size;
        if (type == COMPRESSION_SNAPPY) {
            snappy_decompress_buffer(raw_packet.stream.buffer + raw_packet.cursor, raw_packet.stream.size - raw_packet.cursor, &out_buffer, &out_size);
            raw_packet.stream.buffer = out_buffer;
            raw_packet.stream.size = out_size;
            raw_packet.cursor = 0;
        }else if (type == COMPRESSION_ZLIB) {
            printf("uhh\n");
        }
    }
    while (pck_left_over(&raw_packet) > 0) {
        const int32_t size = (int32_t) pck_read_var_int(&raw_packet);
        pck_packet_t packet = {.stream = (binary_stream_t) {
            .buffer = raw_packet.stream.buffer + raw_packet.cursor,
            .size = (size_t) size
        }};
        decode_games_packets(&packet, player_data);
        pck_cursor_skip(&raw_packet, size);
    }
    free(batch.buffer);
}

void encode_batches_packets(bedrock_player_data_t* player_data) {
    if (player_data->packets_queue_size == 0)
        return;
    pck_packet_t *packets = pck_create(0);
    for (size_t i = 0; i < player_data->packets_queue_size; ++i) {
        const binary_stream_t packet = player_data->packets_queue[i];
        PCK_REALLOC(packets, packet.size + io_var_int_length(packet.size));
        // printf("size: %ld %ld\n", packet.size, packets->stream.size);
        pck_write_var_int(packets, packet.size);
        memcpy(packets->stream.buffer + packets->cursor, packet.buffer, packet.size);
        packets->cursor += packet.size;
        free(packet.buffer);
    }
    packets->stream.size = packets->cursor;
    packets->cursor = 0;
    free(player_data->packets_queue);
    player_data->packets_queue = (binary_stream_t *) malloc(0);
    player_data->packets_queue_size = 0;
    if (player_data->game_state == GAME_COMPRESSION) {
        binary_stream_t output_buffer = {
            .size = 2 + packets->stream.size
        };
        output_buffer.buffer = malloc(output_buffer.size);
        io_write_int8(output_buffer.buffer, (int8_t) 0xFE);
        size_t compressed_output_length = 0;
        if (player_data->compression_type == COMPRESSION_SNAPPY) {
            io_write_int8(output_buffer.buffer + 1, COMPRESSION_SNAPPY);
            if (snappy_compress((const char*) packets->stream.buffer, packets->stream.size, (char *)(output_buffer.buffer + 2), &compressed_output_length) == SNAPPY_BUFFER_TOO_SMALL) {
                io_write_int8(output_buffer.buffer + 1, (int8_t) 0xFF);
                memcpy(output_buffer.buffer + 2, packets->stream.buffer, packets->stream.size);
                output_buffer.size = packets->stream.size + 2;
                goto FALLBACK;
            }
            if (snappy_validate_compressed_buffer((char *)(output_buffer.buffer + 2), compressed_output_length) != SNAPPY_OK) {
                printf("snappy_validate_compressed_buffer failed\n");
                free(output_buffer.buffer);
                return;
            }
        }else if (player_data->compression_type == COMPRESSION_ZLIB) {
            io_write_int8(output_buffer.buffer + 1, COMPRESSION_ZLIB);
            //TODO: ZLIB
        }else {
            io_write_int8(output_buffer.buffer + 1, (int8_t) 0xFF);
            memcpy(output_buffer.buffer + 2, packets->stream.buffer, packets->stream.size);
            output_buffer.size = packets->stream.size + 2;
        }
        output_buffer.size = compressed_output_length + 2;
        FALLBACK:
        free(packets->stream.buffer);
        push_batch_packets_queue_p2c(player_data, output_buffer);
    } else if (player_data->game_state != GAME_NO_COMPRESSION && player_data->game_state >= GAME_ENCRYPTION && player_data->encrypted_block->enabled) {
        uint8_t *compress_buffer = malloc(1 + snappy_max_compressed_length(packets->stream.size));
        io_write_int8(compress_buffer, (int8_t) player_data->compression_type);
        size_t compressed_output_length = 0;
        if (snappy_compress((const char*) packets->stream.buffer, packets->stream.size, (char *)(compress_buffer + 1), &compressed_output_length) == SNAPPY_BUFFER_TOO_SMALL) {
            io_write_int8(compress_buffer, (int8_t) 0xFF);
            memcpy(compress_buffer + 1, packets->stream.buffer, packets->stream.size);
            compressed_output_length = packets->stream.size + 1;
            goto FALLBACK1;
        }
        if (snappy_validate_compressed_buffer((char *)(compress_buffer + 1), compressed_output_length) != SNAPPY_OK) {
            printf("snappy_validate_compressed_buffer failed\n");
            free(compress_buffer);
            return;
        }
        FALLBACK1:
        free(packets->stream.buffer);
        uint8_t *encrypt_buffer;
        size_t encrypt_buffer_length = 0;
        encrypt_packet_buffer(compress_buffer, compressed_output_length + 1, &encrypt_buffer, &encrypt_buffer_length, player_data->encrypted_block);
        free(compress_buffer);
        const binary_stream_t output_buffer = {
            .buffer = malloc(encrypt_buffer_length + 1),
            .size = encrypt_buffer_length + 1
        };
        io_write_int8(output_buffer.buffer, (int8_t) 0xFE);
        memcpy(output_buffer.buffer + 1, encrypt_buffer, encrypt_buffer_length);
        free(encrypt_buffer);
        push_batch_packets_queue_p2c(player_data, output_buffer);
    } else {
        const binary_stream_t output_buffer = {
            .buffer = (uint8_t *) malloc(1 + packets->stream.size),
            .size = 1 + packets->stream.size
        };
        io_write_int8(output_buffer.buffer, (int8_t) 0xFE);
        memcpy(output_buffer.buffer + 1, packets->stream.buffer, packets->stream.size);
        free(packets->stream.buffer);
        push_batch_packets_queue_p2c(player_data, output_buffer);
    }
    if (player_data->compression_type == COMPRESSION_SNAPPY && player_data->game_state == GAME_NO_COMPRESSION) {
        player_data->game_state = GAME_COMPRESSION;
    }
    if (player_data->encrypted_block->enabled && player_data->game_state == GAME_COMPRESSION) {
        player_data->game_state = GAME_ENCRYPTION;
    }
}

void* player_packet_precessing_thread(void *arg) {
    auto const player_data = (bedrock_player_data_t*) arg;
    int64_t last_tick_time = get_current_time_ms();
    uint64_t server_tick = 0;
    printf("player_packet_precessing_thread start\n");
    while (1) {
        constexpr int64_t TARGET_INTERVAL_MS = 50;
        const int64_t current_time = get_current_time_ms();
        const int64_t delta = current_time - last_tick_time;
        last_tick_time = current_time;
        if (delta > TARGET_INTERVAL_MS) {
            server_tick += (delta / TARGET_INTERVAL_MS) + 1;
        } else {
            server_tick++;
        }
        // ????????????????????????????????????????????????????????
        const binary_stream_t test = get_batch_packets_queue_c2p(player_data);
        if (test.size > 0) {
            if (test.buffer[0] == 0xFE) {
                decode_batches_packet(test, player_data);
            } else if (test.buffer[0] == 0x15) {
                free(test.buffer);
                break;
            }
        }
        //read packet from client
        //read packet from server
        //cleanup entity id in server packet
        //process all the packet (chunk, block, player flags, ack, all interact)
        //run simulation??
        //update client state??
        //
        //
        //
        //
        //
        //repacking all the packet (chunk, block, player flags, ack, all interact)
        //inject proper movement???
        //packing all the batches
        //sent packet to server
        encode_batches_packets(player_data);
        const int64_t next_tick_due = last_tick_time + TARGET_INTERVAL_MS;
        const int64_t sleep_time_ms = next_tick_due - get_current_time_ms();
        if (sleep_time_ms > 0) {
            // printf("%lld\n", sleep_time_ms);
            // usleep(sleep_time_ms * 1000);
        }
        //TODO: check ack timeout
    }
    //TODO: free all the pointers
    return NULL;
}