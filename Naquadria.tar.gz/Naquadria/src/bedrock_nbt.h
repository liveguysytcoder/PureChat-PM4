//
// Created by zeen on 9/20/25.
//

#ifndef BEDROCK_NBT_H
#define BEDROCK_NBT_H

#include "bedrock_net_serializer.h"
#include <stdint.h>

#define END_TAG 0
#define BYTE_TAG 1
#define SHORT_TAG 2
#define INT_TAG 3
#define LONG_TAG 4
#define FLOAT_TAG 5
#define DOUBLE_TAG 6
#define BYTE_ARRAY_TAG 7
#define STRING_TAG 8
#define LIST_TAG 9
#define COMPOUND_TAG 10
#define INT_ARRAY_TAG 11
#define LONG_ARRAY_TAG 12

#define E_BIG_ENDIAN 0
#define E_LITTLE_ENDIAN 1
#define E_NETWORK_ENDIAN 2

union _nbt_multi;
typedef union _nbt_multi nbt_multi_t;

typedef struct {
	int8_t *data;
	int32_t size;
} nbt_byte_array_t;

typedef struct {
	int32_t *data;
	int32_t size;
} nbt_int_array_t;

typedef struct {
	int64_t *data;
	int32_t size;
} nbt_long_array_t;

typedef struct {
	int8_t tag_id;
	int32_t size;
	nbt_multi_t *data;
} nbt_list_t;

typedef struct {
	size_t size;
	int8_t *tag_ids;
	char **names;
	nbt_multi_t *data;
} nbt_compound_t;

union _nbt_multi {
	int8_t byte_tag;
	int16_t short_tag;
	int32_t int_tag;
	int64_t long_tag;
	float float_tag;
	double double_tag;
	nbt_byte_array_t byte_array_tag;
	char *string_tag;
	nbt_list_t list_tag;
	nbt_int_array_t int_array_tag;
	nbt_long_array_t long_array_tag;
	nbt_compound_t compound_tag;
};

typedef struct {
	char *name;
	int8_t tag_id;
	nbt_multi_t data;
} nbt_named_t;

int8_t nbt_read_byte_tag(pck_packet_t* packet);

int16_t nbt_read_short_tag(pck_packet_t* packet, uint8_t endianness);

int32_t nbt_read_int_tag(pck_packet_t* packet, uint8_t endianness);

int64_t nbt_read_long_tag(pck_packet_t* packet, uint8_t endianness);

float nbt_read_float_tag(pck_packet_t* packet, uint8_t endianness);

double nbt_read_double_tag(pck_packet_t* packet, uint8_t endianness);

nbt_byte_array_t nbt_read_byte_array_tag(pck_packet_t* packet, uint8_t endianness);

char *nbt_read_string_tag(pck_packet_t* packet, uint8_t endianness);

nbt_multi_t nbt_read_multi_tag(pck_packet_t* packet, int8_t tag_id, uint8_t endianness);

nbt_list_t nbt_read_list_tag(pck_packet_t* packet, uint8_t endianness);

nbt_compound_t nbt_read_compound_tag(pck_packet_t* packet, uint8_t endianness);

nbt_int_array_t nbt_read_int_array_tag(pck_packet_t* packet, uint8_t endianness);

nbt_long_array_t nbt_read_long_array_tag(pck_packet_t* packet, uint8_t endianness);

nbt_named_t nbt_read_named_tag(pck_packet_t* packet, uint8_t endianness);

void nbt_write_byte_tag(pck_packet_t* packet, int8_t value);

void nbt_write_short_tag(pck_packet_t* packet, int16_t value, uint8_t endianness);

void nbt_write_int_tag(pck_packet_t* packet, int32_t value, uint8_t endianness);

void nbt_write_long_tag(pck_packet_t* packet, int64_t value, uint8_t endianness);

void nbt_write_float_tag(pck_packet_t* packet, float value, uint8_t endianness);

void nbt_write_double_tag(pck_packet_t* packet, double value, uint8_t endianness);

void nbt_write_byte_array_tag(pck_packet_t* packet, nbt_byte_array_t value, uint8_t endianness);

void nbt_write_string_tag(pck_packet_t* packet, const char *value, uint8_t endianness);

void nbt_write_multi_tag(pck_packet_t* packet, nbt_multi_t value, int8_t tag_id, uint8_t endianness);

void nbt_write_list_tag(pck_packet_t* packet, nbt_list_t value, uint8_t endianness);

void nbt_write_compound_tag(pck_packet_t* packet, nbt_compound_t value, uint8_t endianness);

void nbt_write_int_array_tag(pck_packet_t* packet, nbt_int_array_t value, uint8_t endianness);

void nbt_write_long_array_tag(pck_packet_t* packet, nbt_long_array_t value, uint8_t endianness);

void nbt_write_named_tag(pck_packet_t* packet, nbt_named_t value, uint8_t endianness);

void destroy_nbt_list(nbt_list_t value);

void destroy_nbt_compound(nbt_compound_t value);

void destroy_nbt_named(nbt_named_t value);
#endif //BEDROCK_NBT_H
